package com.controlcenter.app.ui

import android.app.ActivityOptions
import android.content.Context
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.controlcenter.app.MediaListener
import com.controlcenter.app.NotifItem
import com.controlcenter.app.NotifStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * This app's own notification panel (pull down on the left half of the top edge).
 * Big clock, then one rounded card per notification: app icon, title, text and up to two action buttons.
 * Tap a card to open it, swipe it sideways to dismiss it, "Clear all" removes every dismissable one.
 */
@Composable
fun NotificationPanelApp(
    onOpenSettings: () -> Unit,
    onClose: () -> Unit,
    insetTop: Dp,
    insetBottom: Dp,
    active: Boolean,
    blurBehind: Boolean
) {
    val ctx = LocalContext.current
    val th = rememberCCTheme(blurBehind)
    val prefs = remember { ctx.getSharedPreferences("cc", Context.MODE_PRIVATE) }

    // read again every time the panel is opened
    val hide = remember(active) { prefs.getBoolean("n_hide", false) }
    val h24 = remember(active) { prefs.getBoolean("clock24", android.text.format.DateFormat.is24HourFormat(ctx)) }
    val showDate = remember(active) { prefs.getBoolean("n_date", true) }
    val hasAccess = remember(active) { MediaListener.hasAccess(ctx) }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) {
        if (active) MediaListener.refreshNow()
        while (active) {
            now = System.currentTimeMillis()
            delay(10_000)
        }
    }

    val list = NotifStore.items
    val timeFmt = remember(h24) { SimpleDateFormat(if (h24) "HH:mm" else "h:mm", Locale.getDefault()) }
    val dateFmt = remember { SimpleDateFormat("EEE, d MMM", Locale.getDefault()) }

    val closeMod = Modifier
        .pointerInput(Unit) { detectTapGestures { onClose() } }
        .pointerInput(Unit) {
            var acc = 0f
            detectVerticalDragGestures(
                onDragStart = { acc = 0f },
                onDragEnd = { if (acc < -size.height * 0.08f) onClose() },
                onDragCancel = { acc = 0f }
            ) { _, dy -> acc += dy }
        }

    CompositionLocalProvider(LocalCC provides th) {
        Box(Modifier.fillMaxSize().then(closeMod)) {
            CCWallpaper(th, true)
            Column(Modifier.fillMaxSize().padding(top = insetTop + 12.dp, bottom = insetBottom)) {

                /* clock, date, Clear all */
                Row(
                    Modifier.fillMaxWidth().padding(start = 24.dp, end = 18.dp, top = 6.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            timeFmt.format(Date(now)), color = th.fg, fontSize = 54.sp,
                            fontWeight = FontWeight.Light, maxLines = 1
                        )
                        if (showDate) Text(
                            dateFmt.format(Date(now)), color = th.fgSub, fontSize = 15.sp,
                            fontWeight = FontWeight.Medium, maxLines = 1
                        )
                    }
                    if (list.any { it.clearable }) {
                        Pill("Clear all", th) { MediaListener.instance?.cancelAllNotifications() }
                    }
                }

                /* the notifications */
                when {
                    !hasAccess -> Column(
                        Modifier.weight(1f).fillMaxWidth().padding(horizontal = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "Allow Notification access to see your notifications here.",
                            color = th.fgSub, fontSize = 15.sp, textAlign = TextAlign.Center
                        )
                        Box(Modifier.padding(top = 14.dp)) { Pill("Open settings", th) { onOpenSettings() } }
                    }
                    list.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No notifications", color = th.fgSub, fontSize = 15.sp)
                    }
                    else -> LazyColumn(
                        Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(list, key = { it.key }) { n ->
                            NotifCard(n, th, hide, now, onClose)
                        }
                    }
                }

                /* handle at the bottom closes the panel */
                Box(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
                        .semantics { contentDescription = "Close notification panel" },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(width = 110.dp, height = 20.dp), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(width = 36.dp, height = 4.dp)
                                .background(th.fg.copy(alpha = 0.45f), RoundedCornerShape(2.dp))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NotifCard(n: NotifItem, th: CCTheme, hide: Boolean, now: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    var wPx by remember { mutableFloatStateOf(1f) }

    val title = if (hide) n.app else n.title.ifBlank { n.app }
    val text = if (hide) "Content hidden" else n.text

    fun send(pi: android.app.PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val o = ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                pi.send(ctx, 0, null, null, null, null, o.toBundle())
            } else {
                pi.send()
            }
        } catch (_: Exception) {
        }
    }

    Box(
        Modifier.fillMaxWidth()
            .onSizeChanged { wPx = it.width.toFloat().coerceAtLeast(1f) }
            .graphicsLayer {
                translationX = off.value
                alpha = 1f - (abs(off.value) / wPx).coerceIn(0f, 1f) * 0.85f
            }
            .pointerInput(n.key, n.clearable) {
                if (n.clearable) detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (abs(off.value) > wPx * 0.35f) {
                                off.animateTo(if (off.value > 0) wPx else -wPx, tween(140))
                                MediaListener.instance?.cancelNotification(n.key)
                            } else {
                                off.animateTo(0f, spring())
                            }
                        }
                    },
                    onDragCancel = { scope.launch { off.animateTo(0f, spring()) } }
                ) { change, dx ->
                    change.consume()
                    scope.launch { off.snapTo(off.value + dx) }
                }
            }
            .clip(RoundedCornerShape(22.dp))
            .background(th.card)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                n.content?.let { send(it) }
                if (n.autoCancel && n.clearable) MediaListener.instance?.cancelNotification(n.key)
                onClose()
            }
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AppIcon(n, th)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    title, color = th.fg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (text.isNotBlank()) Text(
                    text, color = th.fgSub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                if (n.actions.size > 1) {
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        n.actions.forEach { a ->
                            Pill(a.title.ifBlank { "Open" }, th) { runAction(a.intent, { p -> send(p) }, onClose) }
                        }
                    }
                }
            }
            if (n.actions.size == 1) {
                val a = n.actions[0]
                Pill(a.title.ifBlank { "Open" }, th) { runAction(a.intent, { p -> send(p) }, onClose) }
            } else if (!n.ongoing) {
                Text(ago(now, n.time), color = th.fgSub, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

/** Sends the action. Closes the panel when the action opens an app (Android 12+ can tell), otherwise leaves it open. */
private fun runAction(pi: android.app.PendingIntent, send: (android.app.PendingIntent) -> Unit, onClose: () -> Unit) {
    send(pi)
    val keepOpen = Build.VERSION.SDK_INT >= 31 && try { !pi.isActivity } catch (_: Throwable) { false }
    if (!keepOpen) onClose()
}

@Composable
private fun AppIcon(n: NotifItem, th: CCTheme) {
    val icon = n.icon
    if (icon != null) {
        Image(
            bitmap = icon, contentDescription = n.app,
            modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
        )
    } else {
        Box(Modifier.size(38.dp).background(th.pill, CircleShape), contentAlignment = Alignment.Center) {
            Text(n.app.take(1).uppercase(), color = th.fg, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Pill(text: String, th: CCTheme, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(th.pill)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = th.fg, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

private fun ago(now: Long, t: Long): String {
    val m = ((now - t) / 60_000L).coerceAtLeast(0)
    return when {
        m < 1 -> "now"
        m < 60 -> "${m}m"
        m < 24 * 60 -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
        else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t))
    }
}
