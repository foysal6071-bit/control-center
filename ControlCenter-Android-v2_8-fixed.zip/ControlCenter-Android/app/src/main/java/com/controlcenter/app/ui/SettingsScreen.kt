package com.controlcenter.app.ui

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.controlcenter.app.MediaListener
import com.controlcenter.app.OverlayService
import com.controlcenter.app.Shell
import com.controlcenter.app.StatusBarService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val BG = Color(0xFF0D1015)
private val CARD = Color(0xFF1A1F2A)
private val DIM = Color(0xB3FFFFFF)
private val OK = Color(0xFF34C759)
private val INFO = Color(0xFF7DB4FF)

/** Home screen of the app: every setting in one place. */
@Composable
fun SettingsScreen(onOpenControlCenter: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val prefs = remember { ctx.getSharedPreferences("cc", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val pkg = ctx.packageName

    var overlayOn by remember { mutableStateOf(prefs.getBoolean("overlay_on", false) && Settings.canDrawOverlays(ctx)) }
    var split by remember { mutableStateOf(prefs.getBoolean("split", true)) }
    // the full lock and the split pull-down exclude each other (the left half has to open the phone's own panel)
    var lockOn by remember { mutableStateOf(prefs.getBoolean("lock_stock", false) && !prefs.getBoolean("split", true)) }
    var msg by remember { mutableStateOf("") }
    var pendingOverlay by remember { mutableStateOf(false) }
    var resumeTick by remember { mutableIntStateOf(0) }
    var triggerH by remember { mutableIntStateOf(prefs.getInt("trigger_h", 1)) }
    var triggerSide by remember { mutableIntStateOf(prefs.getInt("trigger_side", 0)) }
    var notifOwn by remember { mutableStateOf(prefs.getBoolean("notif_own", true)) }
    var themeMode by remember { mutableIntStateOf(prefs.getInt("theme_mode", 0)) }
    var uiStyle by remember { mutableIntStateOf(prefs.getInt("ui_style", 0)) }
    var accent by remember { mutableIntStateOf(prefs.getInt("accent", 0)) }
    var corner by remember { mutableIntStateOf(prefs.getInt("corner", 1)) }
    var bgStyle by remember { mutableIntStateOf(prefs.getInt("bg_style", 0)) }
    var blurAmt by remember { mutableFloatStateOf(prefs.getInt("blur_amt", Look.DEF_BLUR).toFloat()) }
    var dimAmt by remember { mutableFloatStateOf(prefs.getInt("dim", Look.DEF_DIM).toFloat()) }
    var longPress by remember { mutableIntStateOf(prefs.getInt("long_press", 0)) }
    // custom status bar: off by default
    var statusOn by remember { mutableStateOf(prefs.getBoolean("cs_on", false) && Settings.canDrawOverlays(ctx)) }
    var csBg by remember { mutableIntStateOf(prefs.getInt("cs_bg", 0)) }
    var page by remember { mutableStateOf(Pg.Home) }
    BackHandler(enabled = page != Pg.Home) { page = Pg.Home }
    val blurSupported = remember {
        Build.VERSION.SDK_INT >= 31 && try { activity.windowManager.isCrossWindowBlurEnabled } catch (_: Throwable) { false }
    }
    /** a theme / blur setting changed: the pull-down panels are built again with the new look */
    fun lookChanged() { OverlayService.rebuildLook() }

    DisposableEffect(activity) {
        Shell.evaluate()
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                Shell.evaluate()
                resumeTick++
            }
        }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }

    /* permission states, re-read every time the screen comes back to the front or something changes */
    var permTick by remember { mutableIntStateOf(0) }
    val overlayPerm = remember(resumeTick, permTick) { Settings.canDrawOverlays(ctx) }
    val notifPerm = remember(resumeTick, permTick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val writePerm = remember(resumeTick, permTick) { Settings.System.canWrite(ctx) }
    val dndPerm = remember(resumeTick, permTick) {
        try { ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted } catch (_: Exception) { false }
    }
    val listenerOn = remember(resumeTick, permTick) { MediaListener.hasAccess(ctx) }
    val battPerm = remember(resumeTick, permTick) {
        try { ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(pkg) } catch (_: Exception) { false }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permTick++
        if (!granted) {
            // Android will not ask again: send the user to the app's notification page
            ctx.startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
            )
        }
    }

    fun grantNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (Shell.ready) scope.launch {
                Shell.exec("pm grant $pkg android.permission.POST_NOTIFICATIONS")
                delay(300); permTick++
            } else notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg))
        }
    }

    /** Notification access: one tap with Shizuku, otherwise the system screen (its own page for this app on Android 11+). */
    fun grantListener() {
        scope.launch {
            if (Shell.ready) {
                Shell.exec("cmd notification allow_listener ${MediaListener.component(ctx).flattenToString()}")
                delay(500); permTick++
                return@launch
            }
            msg = "Turn on Control Center in the list. If it is greyed out: App info → ⋮ → Allow restricted settings."
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    ctx.startActivity(
                        Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
                            Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                            MediaListener.component(ctx).flattenToString()
                        )
                    )
                } else {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            } catch (_: Exception) {
                try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (_: Exception) {}
            }
        }
    }

    fun restartOverlayIfOn() {
        if (overlayOn) {
            OverlayService.stop(ctx)
            OverlayService.start(ctx)
        }
    }

    fun setOverlay(on: Boolean) {
        scope.launch {
            if (on) {
                if (!Settings.canDrawOverlays(ctx) && Shell.ready) {
                    Shell.exec("appops set $pkg SYSTEM_ALERT_WINDOW allow")
                    delay(400)
                }
                if (!Settings.canDrawOverlays(ctx)) {
                    msg = "Allow “Display over other apps”. The switch turns on by itself when you come back."
                    pendingOverlay = true
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
                    return@launch
                }
                pendingOverlay = false
                permTick++
                if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) grantNotifications()
                prefs.edit().putBoolean("overlay_on", true).apply()
                overlayOn = true
                OverlayService.start(ctx)
                msg = "Turned on. Pull down from the very top edge of the screen."
            } else {
                // switch the lock off first so the phone is never left without a pull-down
                if (lockOn) {
                    Shell.setStatusBarLocked(false)
                    lockOn = false
                    prefs.edit().putBoolean("lock_stock", false).apply()
                }
                pendingOverlay = false
                prefs.edit().putBoolean("overlay_on", false).apply()
                overlayOn = false
                OverlayService.stop(ctx)
                msg = ""
            }
        }
    }

    // back from the system permission screen: finish what the user started
    LaunchedEffect(resumeTick) {
        if (pendingOverlay && Settings.canDrawOverlays(ctx)) setOverlay(true)
    }

    /** Split pull-down: right half = this Control Center, left half = the phone's own notification panel. */
    fun setSplit(on: Boolean) {
        split = on
        prefs.edit().putBoolean("split", on).apply()
        if (on && lockOn) {
            // the full lock would also block the left half, so it is released
            lockOn = false
            prefs.edit().putBoolean("lock_stock", false).apply()
            scope.launch { Shell.setStatusBarLocked(false) }
        }
        restartOverlayIfOn()
        msg = if (on) "Right half opens Control Center, left half opens the phone’s notification panel." else ""
    }

    fun setLock(on: Boolean) {
        scope.launch {
            val ok = Shell.setStatusBarLocked(on)
            if (ok) {
                lockOn = on
                prefs.edit().putBoolean("lock_stock", on).apply()
                msg = if (on) "The phone’s own notification panel and Control Center are now locked."
                else "The phone’s own pull-down is back."
            } else {
                msg = "Couldn’t change the lock on this phone. Is Shizuku running?"
            }
        }
    }

    /** Custom status bar on / off. Needs Shizuku (it hides the phone's own status bar) and "Display over other apps". */
    fun setStatusBar(on: Boolean) {
        scope.launch {
            if (on) {
                if (!Shell.ready) {
                    msg = "Connect Shizuku first. It is needed to hide the phone’s own status bar."
                    return@launch
                }
                if (!Settings.canDrawOverlays(ctx)) {
                    Shell.exec("appops set $pkg SYSTEM_ALERT_WINDOW allow")
                    delay(400)
                    permTick++
                }
                if (!Settings.canDrawOverlays(ctx)) {
                    msg = "Allow “Display over other apps” under Permissions, then try again."
                    return@launch
                }
                // mobile network type / signal for the bar
                Shell.exec("pm grant $pkg android.permission.READ_PHONE_STATE")
                if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) grantNotifications()
                prefs.edit().putBoolean("cs_on", true).apply()
                statusOn = true
                StatusBarService.start(ctx)
                msg = "Custom status bar is on. If anything looks wrong, tap “Restore phone’s status bar” at the top of Settings."
            } else {
                prefs.edit().putBoolean("cs_on", false).apply()
                statusOn = false
                StatusBarService.stop(ctx)
                Shell.setStatusBarHidden(false)
                msg = "Custom status bar is off. The phone’s own status bar is back."
            }
        }
    }

    /** One tap back to the phone's own status bar and Control Center: everything this app changes is switched off. */
    fun restorePhoneBars() {
        scope.launch {
            prefs.edit()
                .putBoolean("cs_on", false)
                .putBoolean("overlay_on", false)
                .putBoolean("lock_stock", false)
                .apply()
            statusOn = false
            overlayOn = false
            lockOn = false
            pendingOverlay = false
            StatusBarService.stop(ctx)
            OverlayService.stop(ctx)
            if (Shell.ready) {
                val a = Shell.setStatusBarHidden(false)
                val b = Shell.setStatusBarLocked(false)
                msg = if (a && b) "Done. The phone’s own status bar and Control Center are back."
                else "Couldn’t restore everything. Try again, or restart Shizuku."
            } else {
                msg = "Custom bar and pull-down are off. Shizuku is not running, so the phone’s own bar comes back by itself."
            }
        }
    }

    val tileCount = remember(page) { Tiles.all.count { Tiles.isOn(ctx, it) } }
    val permsOk = listOf(overlayPerm, notifPerm, listenerOn, writePerm, dndPerm, battPerm).count { it }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {

            /* top bar: title on the home page, back arrow + title on every other page */
            if (page == Pg.Home) {
                Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 6.dp)) {
                    Text("Control Center", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("Settings", color = DIM, fontSize = 13.sp)
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(44.dp).clickable { page = Pg.Home },
                        contentAlignment = Alignment.Center
                    ) { Text("‹", color = Color.White, fontSize = 30.sp) }
                    Text(page.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (msg.isNotEmpty()) Text(msg, color = INFO, fontSize = 13.sp)

                when (page) {

                    /* ================= HOME: one row per group ================= */
                    Pg.Home -> {
                        Button(
                            onClick = { restorePhoneBars() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E), contentColor = Color.White)
                        ) { Text("Restore phone’s status bar & Control Center") }
                        Button(onClick = onOpenControlCenter, modifier = Modifier.fillMaxWidth()) { Text("Open Control Center") }
                        NavRow("🔌", "Shizuku", when (Shell.state) {
                            Shell.State.Ready -> "Connected"
                            Shell.State.Connecting -> "Connecting…"
                            Shell.State.NoPermission -> "Not allowed yet"
                            Shell.State.NotRunning -> "Not running"
                        }) { page = Pg.Shizuku }
                        NavRow("👆", "Pull-down", (if (overlayOn) "On" else "Off") + " · " +
                            (if (split) "split left / right" else "Control Center only")) { page = Pg.Pull }
                        NavRow("📶", "Status bar", if (statusOn) "On · custom bar shown" else "Off · phone’s own bar") { page = Pg.Status }
                        NavRow("🔔", "Notification panel",
                            if (!listenerOn) "Needs Notification access"
                            else if (split && notifOwn) "Own panel on (left half)" else "Own panel off") { page = Pg.Notif }
                        NavRow("🎨", "Theme", listOf("Dark", "Light", "System")[themeMode.coerceIn(0, 2)] + " · " +
                            Look.accentNames[accent.coerceIn(0, Look.accentNames.size - 1)]) { page = Pg.Theme }
                        NavRow("🌫️", "Blur & background",
                            if (bgStyle == 0) "Blurred screen · ${blurAmt.toInt()}%" else "Gradient wallpaper") { page = Pg.Blur }
                        NavRow("▦", "Tiles", "$tileCount of ${Tiles.MAX} shown") { page = Pg.Tiles }
                        NavRow("⚙️", "Behavior", "Vibration, clock, long-press") { page = Pg.Behavior }
                        NavRow("🔐", "Permissions", "$permsOk of 6 allowed") { page = Pg.Perms }
                        NavRow("ℹ️", "Help & About", "Setup guide · version") { page = Pg.Help }
                        Button(onClick = onOpenControlCenter, modifier = Modifier.fillMaxWidth()) { Text("Open Control Center") }
                    }

                    /* ================= SHIZUKU ================= */
                    Pg.Shizuku -> Card("Shizuku") {
                        val (text, ok) = when (Shell.state) {
                            Shell.State.Ready -> "Connected ✓  Wi-Fi, Mobile data, Airplane, Bluetooth, Hotspot, Focus (DND), Rotation, Brightness and Screenshot now work through Shizuku." to true
                            Shell.State.Connecting -> "Connecting to Shizuku…" to false
                            Shell.State.NoPermission ->
                                (if (Shell.deniedForever) "Permission was denied before. Open the Shizuku app → Authorized apps and allow Control Center."
                                else "Shizuku is running, but this app has not been allowed yet.") to false
                            Shell.State.NotRunning -> "Shizuku is not running. Open the Shizuku app and press Start (wireless debugging or root)." to false
                        }
                        Text(text, color = if (ok) OK else DIM, fontSize = 14.sp)
                        when (Shell.state) {
                            Shell.State.NoPermission -> if (!Shell.deniedForever) {
                                Button(onClick = { Shell.requestPermission() }) { Text("Allow") }
                            } else {
                                Button(onClick = { if (!Shell.launchShizukuApp(ctx)) msg = "Shizuku is not installed." }) { Text("Open Shizuku") }
                            }
                            Shell.State.NotRunning ->
                                Button(onClick = { if (!Shell.launchShizukuApp(ctx)) msg = "Shizuku is not installed." }) { Text("Open Shizuku") }
                            else -> {}
                        }
                        Text("Shizuku is optional. Without it, the controls open the matching system screen instead.", color = DIM, fontSize = 12.sp)
                    }

                    /* ================= PULL-DOWN ================= */
                    Pg.Pull -> {
                        Card("Pull-down") {
                            SwitchRow(
                                "Open Control Center from the top edge",
                                "Pull down from the top of the screen and it opens over any app.",
                                overlayOn, true
                            ) { setOverlay(it) }
                            if (!overlayPerm && !overlayOn) {
                                Text("Needs “Display over other apps”. It is granted automatically when Shizuku is connected.", color = DIM, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { if (!OverlayService.openNow()) msg = "Turn on “Open Control Center from the top edge” first." },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Test Control Center") }
                            OutlinedButton(
                                onClick = { if (!OverlayService.openNotifNow()) msg = "Turn on “Open Control Center from the top edge” first." },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Test notification panel") }
                        }

                        Card("Layout") {
                            Choice(listOf("Split: left / right", "Control Center only"), if (split) 0 else 1) { setSplit(it == 0) }
                            Text(
                                if (split) "Pull down on the right half of the top edge for Control Center, on the left half for notifications."
                                else "The whole top edge (or the area chosen below) opens Control Center. The phone’s own notification panel stays as it is.",
                                color = DIM, fontSize = 12.sp
                            )
                            if (split) {
                                SwitchRow(
                                    "Use this app’s notification panel",
                                    "The left half opens the notification panel of this app instead of the phone’s own one.",
                                    notifOwn, true
                                ) {
                                    notifOwn = it
                                    prefs.edit().putBoolean("notif_own", it).apply()
                                    restartOverlayIfOn()
                                }
                            }
                            Text(
                                if (split && Shell.ready) "Shizuku is connected: while your finger is on the top edge the phone’s own pull-down is held back, so only the panel of this app opens."
                                else if (split) "Without Shizuku only thin strips at the top edge catch the swipe, and the phone’s own panel may also start to open under them. Connect Shizuku for a clean swipe."
                                else if (Shell.ready) "Shizuku is connected: the swipe is detected from the touch screen itself. Turn on the lock below so the phone’s own panel does not open."
                                else "Without Shizuku only a thin strip at the top edge catches the swipe. Connect Shizuku for a swipe that always works.",
                                color = DIM, fontSize = 12.sp
                            )
                        }

                        Card("Trigger") {
                            Text("Trigger height", color = Color.White, fontSize = 14.sp)
                            Choice(listOf("Small", "Normal", "Large"), triggerH) {
                                triggerH = it; prefs.edit().putInt("trigger_h", it).apply(); restartOverlayIfOn()
                            }
                            if (!split) {
                                Text("Trigger area", color = Color.White, fontSize = 14.sp)
                                Choice(listOf("Full width", "Left half", "Right half"), triggerSide) {
                                    triggerSide = it; prefs.edit().putInt("trigger_side", it).apply(); restartOverlayIfOn()
                                }
                            }
                            PrefSwitch(prefs, "boot_start", true, "Start after reboot", "Turns the pull-down back on when the phone starts.")
                        }

                        if (!split) Card("Lock the phone’s own pull-down") {
                            SwitchRow(
                                "Lock notification panel and stock Control Center",
                                "While on, only this Control Center opens when you pull down.",
                                lockOn, Shell.ready && overlayOn
                            ) { setLock(it) }
                            if (!overlayOn) Text("Turn on “Open Control Center from the top edge” first.", color = DIM, fontSize = 12.sp)
                            else if (!Shell.ready) Text("Needs Shizuku to be connected.", color = DIM, fontSize = 12.sp)
                            Text(
                                "The lock is released when the phone restarts or Shizuku stops, and the app puts it back when Shizuku reconnects. " +
                                    "If you get stuck, open this app and switch it off.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                    }

                    /* ================= STATUS BAR ================= */
                    Pg.Status -> {
                        Card("Custom status bar") {
                            SwitchRow(
                                "Show custom status bar",
                                "Hides the phone’s own status bar (through Shizuku) and draws this one at the top: time, notification icons, network speed, alarm, VoLTE, signal and battery.",
                                statusOn, true
                            ) { setStatusBar(it) }
                            if (Shell.state != Shell.State.Ready) {
                                Text("Needs Shizuku to be connected.", color = INFO, fontSize = 12.sp)
                            }
                            Text(
                                "Off by default. The phone’s own status bar comes back on the lock screen, when Shizuku stops, " +
                                    "and with “Restore phone’s status bar & Control Center” at the top of Settings.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                        Card("What to show") {
                            PrefSwitch(prefs, "cs_speed", true, "Network speed", "Live download + upload speed.") { StatusBarService.reload() }
                            PrefSwitch(prefs, "cs_notif", true, "Notification icons", "Needs Notification access (see Notification panel).") { StatusBarService.reload() }
                            PrefSwitch(prefs, "cs_volte", true, "VoLTE badge", "Shown while the phone is on 4G (LTE).") { StatusBarService.reload() }
                        }
                        Card("Background") {
                            Choice(listOf("Black", "Transparent"), csBg) {
                                csBg = it; prefs.edit().putInt("cs_bg", it).apply(); StatusBarService.reload()
                            }
                            Text("Black keeps the icons readable on every app. The clock follows “24-hour clock” under Behavior. In landscape the phone’s own status bar is shown; in portrait this one comes back.", color = DIM, fontSize = 12.sp)
                        }
                    }

                    /* ================= NOTIFICATION PANEL ================= */
                    Pg.Notif -> {
                        Card("Access") {
                            PermRow(
                                "Notification access",
                                "Needed to show your notifications in this app’s panel. They are only kept in memory and never saved or sent anywhere.",
                                listenerOn
                            ) { grantListener() }
                            if (!split) Text("The panel opens from the left half of the top edge. Turn on “Split” under Pull-down first.", color = INFO, fontSize = 12.sp)
                            else if (!notifOwn) Text("“Use this app’s notification panel” is off under Pull-down.", color = INFO, fontSize = 12.sp)
                            OutlinedButton(
                                onClick = { if (!OverlayService.openNotifNow()) msg = "Turn on “Open Control Center from the top edge” first." },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Open notification panel") }
                        }
                        Card("What to show") {
                            PrefSwitch(prefs, "n_ongoing", true, "Ongoing notifications", "Timers, recorders, calls and other running things.") { MediaListener.refreshNow() }
                            PrefSwitch(prefs, "n_media", false, "Music players", "The player notifications of YouTube, Spotify… (the Now Playing tile already controls music).") { MediaListener.refreshNow() }
                            PrefSwitch(prefs, "n_hide", false, "Hide content", "Show only the app name, not the title and text.")
                            PrefSwitch(prefs, "n_date", true, "Date under the clock", "")
                        }
                        Card("How it works") {
                            Text(
                                "Tap a notification to open it. Swipe it left or right to dismiss it. “Clear all” removes every notification that can be dismissed. " +
                                    "Swipe up or tap the empty space to close the panel.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                    }

                    /* ================= THEME ================= */
                    Pg.Theme -> {
                        Card("Style") {
                            Choice(listOf("iOS", "MIUI", "HyperOS"), uiStyle) {
                                uiStyle = it; prefs.edit().putInt("ui_style", it).apply(); lookChanged()
                            }
                            Text(
                                when (uiStyle) {
                                    1 -> "Title with settings / edit buttons, wide tiles, round buttons and wide sliders (no music tile)."
                                    2 -> "Glass look: pill Wi-Fi / Mobile data, music tile, round sliders and round buttons with names."
                                    else -> "Square tiles, music tile and two tall sliders."
                                },
                                color = DIM, fontSize = 12.sp
                            )
                        }
                        Card("Mode") {
                            Choice(listOf("Dark", "Light", "System"), themeMode) {
                                themeMode = it; prefs.edit().putInt("theme_mode", it).apply(); lookChanged()
                            }
                            Text("System follows the dark mode of the phone.", color = DIM, fontSize = 12.sp)
                        }
                        Card("Accent colour") {
                            Text("Colour of the tiles that are switched on.", color = DIM, fontSize = 12.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Look.accents.forEachIndexed { i, c ->
                                    val sel = i == accent
                                    Box(
                                        Modifier.size(36.dp)
                                            .background(c ?: Color(0xFFF3F5F9), CircleShape)
                                            .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color(0x44FFFFFF), CircleShape)
                                            .clickable {
                                                accent = i; prefs.edit().putInt("accent", i).apply(); lookChanged()
                                            },
                                        contentAlignment = Alignment.Center
                                    ) { if (sel) Text("✓", color = if (c == null) Color(0xFF1B1D22) else Color.White, fontSize = 16.sp) }
                                }
                            }
                            Text(Look.accentNames[accent.coerceIn(0, Look.accentNames.size - 1)], color = Color.White, fontSize = 13.sp)
                        }
                        if (uiStyle == 0) Card("Tile shape") {
                            Choice(listOf("Soft", "Rounded", "Circle"), corner) {
                                corner = it; prefs.edit().putInt("corner", it).apply(); lookChanged()
                            }
                        }
                        Text("Changes apply the next time you pull the panel down. Use “Test” under Pull-down to see them.", color = DIM, fontSize = 12.sp)
                    }

                    /* ================= BLUR & BACKGROUND ================= */
                    Pg.Blur -> {
                        Card("Background") {
                            Choice(listOf("Blurred screen", "Gradient"), bgStyle) {
                                bgStyle = it; prefs.edit().putInt("bg_style", it).apply(); lookChanged()
                            }
                            Text(
                                if (bgStyle == 0) "The app you pulled down over stays visible behind the panel, blurred."
                                else "A soft coloured gradient is drawn behind the panel.",
                                color = DIM, fontSize = 12.sp
                            )
                            if (bgStyle == 0 && !blurSupported) Text(
                                "This phone (or its battery saver / developer setting) does not allow blur behind windows right now, so the gradient is used instead. Needs Android 12 or newer.",
                                color = INFO, fontSize = 12.sp
                            )
                        }
                        Card("Blur strength") {
                            SliderRow(
                                "Blur", "${blurAmt.toInt()}%", blurAmt, bgStyle == 0 && blurSupported,
                                { blurAmt = it },
                                { prefs.edit().putInt("blur_amt", blurAmt.toInt()).apply(); lookChanged() }
                            )
                        }
                        Card("Dimming") {
                            SliderRow(
                                "Tint over the background", "${dimAmt.toInt()}%", dimAmt, true,
                                { dimAmt = it },
                                { prefs.edit().putInt("dim", dimAmt.toInt()).apply(); lookChanged() }
                            )
                            Text("Dark theme darkens the background, light theme brightens it.", color = DIM, fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                blurAmt = Look.DEF_BLUR.toFloat(); dimAmt = Look.DEF_DIM.toFloat(); bgStyle = 0
                                prefs.edit().putInt("blur_amt", Look.DEF_BLUR).putInt("dim", Look.DEF_DIM).putInt("bg_style", 0).apply()
                                lookChanged()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Reset to default") }
                        Text("The same blur and tint are used for the Control Center and the notification panel.", color = DIM, fontSize = 12.sp)
                    }

                    /* ================= TILES ================= */
                    Pg.Tiles -> Card("Tiles") {
                        val state = remember {
                            mutableStateMapOf<String, Boolean>().apply { Tiles.all.forEach { put(it.id, Tiles.isOn(ctx, it)) } }
                        }
                        val count = state.values.count { it }
                        Text("Choose what the grid shows ($count of ${Tiles.MAX}). You can also tap Edit in the Control Center itself to remove, add and drag tiles.", color = DIM, fontSize = 12.sp)
                        Tiles.all.forEach { d ->
                            val on = state[d.id] == true
                            SwitchRow(d.label, "", on, on || count < Tiles.MAX) {
                                state[d.id] = it
                                Tiles.setOn(ctx, d.id, it)
                                lookChanged()
                            }
                        }
                        Text("Wi-Fi, Mobile data, brightness, volume and the music player are always shown.", color = DIM, fontSize = 12.sp)
                    }

                    /* ================= BEHAVIOR ================= */
                    Pg.Behavior -> {
                        Card("Touch") {
                            PrefSwitch(prefs, "haptic", true, "Vibrate on tap", "")
                            PrefSwitch(prefs, "hints", true, "Hint messages", "Show short messages like “Wi-Fi is on” at the top.")
                        }
                        Card("Tap and hold on Wi-Fi / Mobile data") {
                            Choice(listOf("Internet panel", "Full settings"), longPress) {
                                longPress = it; prefs.edit().putInt("long_press", it).apply()
                            }
                            Text(
                                if (longPress == 0) "Opens the small floating Internet panel (Wi-Fi networks and mobile data) over the app you are in."
                                else "Opens the full Wi-Fi / network screen of the Settings app.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                        Card("Clock") {
                            PrefSwitch(
                                prefs, "clock24", android.text.format.DateFormat.is24HourFormat(ctx),
                                "24-hour clock", "Used by the clock in the notification panel."
                            )
                        }
                    }

                    /* ================= PERMISSIONS ================= */
                    Pg.Perms -> Card("Permissions") {
                        PermRow("Display over other apps", "Needed for the pull-down panels.", overlayPerm) {
                            scope.launch {
                                if (Shell.ready) {
                                    Shell.exec("appops set $pkg SYSTEM_ALERT_WINDOW allow"); delay(300); permTick++
                                } else ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
                            }
                        }
                        PermRow("Notifications", "Shows the “on” notification and the timer alert.", notifPerm) { grantNotifications() }
                        PermRow(
                            "Notification access",
                            "Shows your notifications in the notification panel and lets the Now Playing tile control the music of any app. Nothing is saved or sent anywhere.",
                            listenerOn
                        ) { grantListener() }
                        PermRow("Modify system settings", "Makes the brightness slider smooth (it writes the setting directly). Given automatically when Shizuku is connected.", writePerm) {
                            scope.launch {
                                if (Shell.ready) {
                                    Shell.exec("appops set $pkg WRITE_SETTINGS allow"); delay(300); permTick++
                                } else ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$pkg")))
                            }
                        }
                        PermRow("Do Not Disturb access", "Lets the Focus tile switch Do Not Disturb without Shizuku.", dndPerm) {
                            scope.launch {
                                if (Shell.ready) {
                                    Shell.exec("cmd notification allow_dnd $pkg"); delay(300); permTick++
                                } else ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                            }
                        }
                        PermRow("Unrestricted battery", "Stops the system from closing the pull-down trigger in the background.", battPerm) {
                            scope.launch {
                                if (Shell.ready) {
                                    Shell.exec("cmd deviceidle whitelist +$pkg"); delay(300); permTick++
                                } else ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            }
                        }
                    }

                    /* ================= HELP & ABOUT ================= */
                    Pg.Help -> {
                        Card("How to set up") {
                            Text(
                                "1. Install Shizuku and start it, then allow Control Center inside Shizuku.\n" +
                                    "2. Allow “Display over other apps” and “Notification access” (one tap each when Shizuku is connected).\n" +
                                    "3. Turn on “Open Control Center from the top edge” under Pull-down.\n" +
                                    "4. Leave the layout on “Split”: pull down on the right half for Control Center, on the left half for notifications.\n" +
                                    "5. Tap and hold Wi-Fi or Mobile data for the floating Internet panel.",
                                color = DIM, fontSize = 13.sp
                            )
                        }
                        Card("About") {
                            val ver = remember {
                                try { ctx.packageManager.getPackageInfo(pkg, 0).versionName ?: "" } catch (_: Exception) { "" }
                            }
                            Text("Control Center $ver", color = Color.White, fontSize = 14.sp)
                            Text("iOS-style Control Center for Android. MIT license.", color = DIM, fontSize = 12.sp)
                        }
                        DeveloperCard("Foysal", "foysal.8575@gmail.com")
                    }
                }
                Box(Modifier.padding(8.dp))
            }
        }
    }
}

private enum class Pg(val title: String) {
    Home("Settings"),
    Shizuku("Shizuku"),
    Pull("Pull-down"),
    Status("Status bar"),
    Notif("Notification panel"),
    Theme("Theme"),
    Blur("Blur & background"),
    Tiles("Tiles"),
    Behavior("Behavior"),
    Perms("Permissions"),
    Help("Help & About")
}

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(CARD, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

/** Who made the app: round initial, role, name and a tappable e-mail address (opens the mail app). */
@Composable
private fun DeveloperCard(name: String, email: String) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier.fillMaxWidth().background(CARD, shape).border(1.dp, Color(0x14FFFFFF), shape)
            .clickable {
                try {
                    ctx.startActivity(
                        Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email"))
                            .putExtra(Intent.EXTRA_SUBJECT, "Control Center")
                    )
                } catch (_: Exception) {
                }
            }
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(Modifier.size(60.dp).background(Color(0xFF4B3BF0), CircleShape), contentAlignment = Alignment.Center) {
            Text(name.take(1).uppercase(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Developer", color = DIM, fontSize = 13.sp)
            Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(email, color = Color(0xFF9A90FF), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** A row of the settings home: icon, title, short summary and an arrow. */
@Composable
private fun NavRow(icon: String, title: String, summary: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(CARD, RoundedCornerShape(16.dp)).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.size(38.dp).background(Color(0x1FFFFFFF), CircleShape), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 18.sp, textAlign = TextAlign.Center)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(summary, color = DIM, fontSize = 12.sp, maxLines = 1)
        }
        Text("›", color = DIM, fontSize = 22.sp)
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            if (sub.isNotEmpty()) Text(sub, color = DIM, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

/** A switch stored in the shared preferences. [onChange] runs after it was saved. */
@Composable
private fun PrefSwitch(
    prefs: SharedPreferences, key: String, def: Boolean, title: String, sub: String,
    onChange: (Boolean) -> Unit = {}
) {
    var on by remember { mutableStateOf(prefs.getBoolean(key, def)) }
    SwitchRow(title, sub, on, true) {
        on = it
        prefs.edit().putBoolean(key, it).apply()
        onChange(it)
    }
}

/** A slider with a title and the current value. [onDone] runs when the finger is lifted. */
@Composable
private fun SliderRow(
    title: String, valueText: String, value: Float, enabled: Boolean,
    onChange: (Float) -> Unit, onDone: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = if (enabled) Color.White else DIM, fontSize = 14.sp)
            Text(valueText, color = DIM, fontSize = 14.sp)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = 0f..100f, enabled = enabled,
            onValueChangeFinished = onDone
        )
    }
}

@Composable
private fun PermRow(title: String, sub: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(sub, color = DIM, fontSize = 12.sp)
        }
        if (granted) Text("Allowed ✓", color = OK, fontSize = 13.sp)
        else OutlinedButton(onClick = onGrant) { Text("Allow") }
    }
}

/** Small segmented choice: the selected option is filled. */
@Composable
private fun Choice(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            val m = Modifier.weight(1f)
            if (i == selected) Button(onClick = { onSelect(i) }, modifier = m, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) { Text(label, fontSize = 12.sp, maxLines = 1) }
            else OutlinedButton(onClick = { onSelect(i) }, modifier = m, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) { Text(label, fontSize = 12.sp, maxLines = 1) }
        }
    }
}
