package com.controlcenter.app

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap

/**
 * "Notification access". It does two things:
 *  - Android hands the app the active media sessions, so the Now Playing tile can show and control the music
 *    of any app (YouTube, Spotify, ...).
 *  - The notifications are shown in this app's own notification panel (pull down on the left half). They are
 *    only held in memory while the phone runs; nothing is saved or sent anywhere.
 * While it is bound, Android also keeps the app process alive, and the pull-down trigger is put back if it
 * was stopped.
 */
class MediaListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        NotifStore.refresh(this)
        val p = getSharedPreferences("cc", Context.MODE_PRIVATE)
        if (p.getBoolean("overlay_on", false) && !OverlayService.running && Settings.canDrawOverlays(this)) {
            try {
                OverlayService.start(this)
            } catch (_: Exception) {
            }
        }
        if (p.getBoolean("cs_on", false) && !StatusBarService.running && Settings.canDrawOverlays(this)) {
            try {
                StatusBarService.start(this)
            } catch (_: Exception) {
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance === this) instance = null
        NotifStore.clear()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        NotifStore.refresh(this)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        NotifStore.refresh(this)
    }

    companion object {
        @Volatile
        var instance: MediaListener? = null
            private set

        fun component(ctx: Context) = ComponentName(ctx, MediaListener::class.java)

        fun hasAccess(ctx: Context): Boolean = try {
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        } catch (_: Exception) {
            false
        }

        /** Reads the notifications again (after a setting changed or the panel opened). */
        fun refreshNow() {
            instance?.let { NotifStore.refresh(it) }
        }
    }
}

class NotifAction(val title: String, val intent: PendingIntent)

class NotifItem(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val ongoing: Boolean,
    val clearable: Boolean,
    val autoCancel: Boolean,
    val icon: ImageBitmap?,
    val content: PendingIntent?,
    val actions: List<NotifAction>
)

/** The notifications shown in the notification panel. Compose reads [items]; only the listener writes it. */
object NotifStore {

    var items by mutableStateOf<List<NotifItem>>(emptyList())
        private set

    private val icons = HashMap<String, ImageBitmap?>()

    /** Small silhouettes of the apps that have a notification (newest first) for the custom status bar. */
    var statusIcons by mutableStateOf<List<ImageBitmap>>(emptyList())
        private set

    fun clear() {
        items = emptyList()
        statusIcons = emptyList()
    }

    private fun iconFor(ctx: Context, pkg: String): ImageBitmap? {
        if (icons.containsKey(pkg)) return icons[pkg]
        val b = try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (_: Throwable) {
            null
        }
        icons[pkg] = b
        return b
    }

    private fun labelFor(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Throwable) {
        pkg.substringAfterLast('.')
    }

    fun refresh(s: NotificationListenerService) {
        val prefs = s.getSharedPreferences("cc", Context.MODE_PRIVATE)
        val showOngoing = prefs.getBoolean("n_ongoing", true)
        val showMedia = prefs.getBoolean("n_media", false)
        val arr: Array<StatusBarNotification> = try {
            s.activeNotifications ?: emptyArray()
        } catch (_: Throwable) {
            return
        }
        val out = ArrayList<NotifItem>()
        for (sbn in arr) {
            try {
                val n = sbn.notification ?: continue
                if (sbn.packageName == s.packageName) continue
                if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
                val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
                if (ongoing && !showOngoing) continue
                val ex = n.extras
                if (!showMedia && ex.containsKey(Notification.EXTRA_MEDIA_SESSION)) continue
                val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
                    ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: ex.getCharSequence(Notification.EXTRA_SUB_TEXT))?.toString().orEmpty()
                if (title.isBlank() && text.isBlank()) continue
                val acts = ArrayList<NotifAction>()
                n.actions?.forEach { a ->
                    val pi = a.actionIntent
                    val ri = a.remoteInputs
                    if (pi != null && (ri == null || ri.isEmpty()) && acts.size < 2) {
                        acts.add(NotifAction(a.title?.toString().orEmpty(), pi))
                    }
                }
                out.add(
                    NotifItem(
                        key = sbn.key,
                        pkg = sbn.packageName,
                        app = labelFor(s, sbn.packageName),
                        title = title,
                        text = text,
                        time = sbn.postTime,
                        ongoing = ongoing,
                        clearable = sbn.isClearable,
                        autoCancel = (n.flags and Notification.FLAG_AUTO_CANCEL) != 0,
                        icon = iconFor(s, sbn.packageName),
                        content = n.contentIntent,
                        actions = acts
                    )
                )
            } catch (_: Throwable) {
            }
        }
        // ongoing ones (timers, recorders, calls) first, then newest first
        out.sortWith(compareByDescending<NotifItem> { it.ongoing }.thenByDescending { it.time })
        items = out

        // one small icon per app for the custom status bar
        val small = LinkedHashMap<String, ImageBitmap>()
        for (sbn in arr.sortedByDescending { it.postTime }) {
            try {
                val n = sbn.notification ?: continue
                if (sbn.packageName == s.packageName) continue
                if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
                if (small.containsKey(sbn.packageName)) continue
                val d = n.smallIcon?.loadDrawable(s) ?: continue
                small[sbn.packageName] = d.toBitmap(64, 64).asImageBitmap()
                if (small.size >= 6) break
            } catch (_: Throwable) {
            }
        }
        statusIcons = small.values.toList()
    }
}
