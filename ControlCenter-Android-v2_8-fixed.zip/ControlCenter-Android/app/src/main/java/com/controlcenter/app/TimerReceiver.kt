package com.controlcenter.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat

/**
 * Rings the timer even when the Control Center is closed. The countdown used to run only while the
 * panel was on screen, so a timer started and then closed never finished.
 */
class TimerReceiver : BroadcastReceiver() {

    override fun onReceive(c: Context, i: Intent) {
        val prefs = c.getSharedPreferences("cc", Context.MODE_PRIVATE)
        // already finished (or cancelled) inside the app
        if (prefs.getLong("timerEnd", 0L) == 0L) return
        prefs.edit().putLong("timerEnd", 0L).apply()

        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("cc_timer", "Timer", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val open = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(c, "cc_timer")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Timer finished")
                .setContentText("Your Control Center timer is done.")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(open)
                .build()
            nm.notify(2, n)
        } catch (_: Exception) {
        }

        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                c.getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                c.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200), -1))
        } catch (_: Exception) {
        }

        val pending = goAsync()
        Thread {
            try {
                val tg = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                repeat(3) {
                    tg.startTone(ToneGenerator.TONE_PROP_BEEP, 250)
                    Thread.sleep(450)
                }
                tg.release()
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        private fun pi(c: Context): PendingIntent = PendingIntent.getBroadcast(
            c, 7, Intent(c, TimerReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        /** Exact alarm that also fires in Doze; needs no special permission. */
        fun schedule(c: Context, at: Long) {
            try {
                val am = c.getSystemService(AlarmManager::class.java)
                val show = PendingIntent.getActivity(
                    c, 8, Intent(c, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c))
            } catch (_: Exception) {
            }
        }

        fun cancel(c: Context) {
            try {
                c.getSystemService(AlarmManager::class.java).cancel(pi(c))
            } catch (_: Exception) {
            }
        }
    }
}
