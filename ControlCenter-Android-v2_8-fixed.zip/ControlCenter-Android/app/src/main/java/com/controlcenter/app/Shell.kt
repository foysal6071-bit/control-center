package com.controlcenter.app

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/**
 * The one door to Shizuku. Every toggle in the app calls [exec]; the pull-down lock calls
 * [setStatusBarLocked]. Compose can observe [state].
 */
object Shell {

    enum class State { NotRunning, NoPermission, Connecting, Ready }

    var state by mutableStateOf(State.NotRunning)
        private set

    /** True when the user pressed "Deny and don't ask again" - the permission must then be given inside Shizuku. */
    var deniedForever by mutableStateOf(false)
        private set

    val ready: Boolean get() = state == State.Ready && svc != null

    private const val REQ = 4601
    private var svc: IUserService? = null
    private lateinit var app: Application
    private val main = Handler(Looper.getMainLooper())
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(a: Application) {
        app = a
        Shizuku.addBinderReceivedListenerSticky { main.post { evaluate() } }
        Shizuku.addBinderDeadListener {
            main.post {
                svc = null
                pullWatching = false
                state = State.NotRunning
            }
        }
        Shizuku.addRequestPermissionResultListener { _, _ -> main.post { evaluate() } }
    }

    /** Re-checks Shizuku (running? permission? service bound?). Cheap, call it on resume. */
    fun evaluate() {
        try {
            if (!Shizuku.pingBinder()) {
                svc = null
                state = State.NotRunning
                return
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                state = State.NoPermission
                return
            }
            if (svc != null) state = State.Ready
            else if (state != State.Connecting) bind()
        } catch (_: Throwable) {
            state = State.NotRunning
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                deniedForever = true
                return
            }
            Shizuku.requestPermission(REQ)
        } catch (_: Throwable) {
        }
    }

    fun launchShizukuApp(ctx: Context): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api") ?: return false
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder == null || !binder.pingBinder()) return
            svc = IUserService.Stub.asInterface(binder)
            state = State.Ready
            onReady()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            pullWatching = false
            state = if (try { Shizuku.pingBinder() } catch (_: Throwable) { false }) State.Connecting else State.NotRunning
        }
    }

    private fun bind() {
        state = State.Connecting
        try {
            val ver = PackageInfoCompat.getLongVersionCode(app.packageManager.getPackageInfo(app.packageName, 0)).toInt()
            val args = Shizuku.UserServiceArgs(ComponentName(app.packageName, ShellService::class.java.name))
                .processNameSuffix("shell")
                .daemon(true)
                .version(ver)
                .tag("controlcenter-shell")
            Shizuku.bindUserService(args, conn)
        } catch (_: Throwable) {
            state = State.NotRunning
        }
    }

    /** Once connected, put back the pull-down lock and the touch watcher the user had switched on. */
    private fun onReady() {
        val p = app.getSharedPreferences("cc", Context.MODE_PRIVATE)
        // split mode never keeps the phone's own pull-down locked: the watcher holds it back only while a finger is on the top edge
        val split = p.getBoolean("split", true)
        if (!split && p.getBoolean("lock_stock", false) && p.getBoolean("overlay_on", false)) {
            io.launch { setStatusBarLocked(true) }
        }
        pullCfg?.let { c -> watchIo.launch { startWatch(c) } }
        // custom status bar: hide the phone's own bar again; when it is off, clear anything left over from an earlier run
        if (p.getBoolean("cs_on", false)) StatusBarService.onShizukuReady()
        else io.launch { setStatusBarHidden(false) }
    }

    /* ---------- pull-down touch watcher (runs in the Shizuku process, replaces the accessibility service) ---------- */

    class PullCfg(
        val w: Int, val h: Int, val rotation: Int, val topPx: Int, val dragPx: Int, val side: Int,
        val autoLock: Boolean = false
    )

    // start / stop of the watcher must run one after the other, in the order they were asked for
    private val watchIo = CoroutineScope(SupervisorJob() + Executors.newSingleThreadExecutor().asCoroutineDispatcher())

    @Volatile private var pullCfg: PullCfg? = null
    @Volatile private var pullCb: ((Int) -> Unit)? = null
    @Volatile private var pullWatching = false
    val pulling: Boolean get() = pullWatching

    private val pullStub = object : IPullListener.Stub() {
        override fun onPull(half: Int) {
            main.post { pullCb?.invoke(half) }
        }
    }

    private fun startWatch(c: PullCfg) {
        val s = svc ?: return
        pullWatching = try {
            s.startPullWatch(pullStub, c.w, c.h, c.rotation, c.topPx, c.dragPx, c.side, c.autoLock)
        } catch (_: Throwable) {
            false
        }
    }

    /** Starts watching for the swipe-down gesture. Safe to call before Shizuku is ready: it starts when it connects. */
    fun watchPull(cfg: PullCfg, onPull: (Int) -> Unit) {
        pullCfg = cfg
        pullCb = onPull
        if (svc != null) watchIo.launch { startWatch(cfg) }
    }

    fun setPullRotation(r: Int) {
        val c = pullCfg ?: return
        pullCfg = PullCfg(c.w, c.h, r, c.topPx, c.dragPx, c.side, c.autoLock)
        val s = svc ?: return
        watchIo.launch { try { s.setPullRotation(r) } catch (_: Throwable) {} }
    }

    fun unwatchPull() {
        pullCfg = null
        pullCb = null
        pullWatching = false
        val s = svc ?: return
        watchIo.launch { try { s.stopPullWatch() } catch (_: Throwable) {} }
    }

    /** Runs a shell command as the shell user. Returns exit code and output. */
    suspend fun exec(cmd: String): Pair<Int, String> = withContext(Dispatchers.IO) {
        val s = svc ?: return@withContext -1 to "Shizuku not ready"
        try {
            val raw = s.exec(cmd)
            val i = raw.indexOf('\n')
            if (i < 0) -1 to raw else (raw.substring(0, i).trim().toIntOrNull() ?: -1) to raw.substring(i + 1)
        } catch (t: Throwable) {
            if (t is android.os.DeadObjectException) {
                svc = null
                main.post { evaluate() }
            }
            -1 to (t.message ?: "error")
        }
    }

    /** Locks / unlocks the phone's own notification panel and quick settings. */
    suspend fun setStatusBarLocked(locked: Boolean): Boolean = withContext(Dispatchers.IO) {
        val s = svc ?: return@withContext false
        try {
            s.setStatusBarLocked(locked)
        } catch (_: Throwable) {
            false
        }
    }

    /** Hides / shows the clock and icons of the phone's own status bar (the custom status bar is drawn instead). */
    suspend fun setStatusBarHidden(hidden: Boolean): Boolean = withContext(Dispatchers.IO) {
        val s = svc ?: return@withContext false
        try {
            s.setStatusBarHidden(hidden)
        } catch (_: Throwable) {
            false
        }
    }
}
