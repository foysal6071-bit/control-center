package com.aerocontrolcenter.app;

// Called from the Shizuku shell process when a swipe-down from the top edge is seen.
// half = 1 when the swipe started on the left half of the screen, 2 when it started on the right half.
oneway interface IPullListener {
    void onPull(int half) = 1;
    // A finger started at any screen edge and moved inward (used in landscape to show the hidden bars for 2 s).
    void onEdge() = 2;
    // A finger touched down inside the navigation bar area (used to close the open panel).
    void onNavTap() = 3;
}
