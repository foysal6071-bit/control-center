# Control Center (Kotlin + Jetpack Compose)

iOS-style Control Center as a native Android app. This is the Kotlin / Jetpack Compose
version of the web project `control-center`. The same 214 x 465 unit layout, the same
colours and the same SVG icon paths are used, but the controls now talk to real Android APIs.

## English

1. Create a repository and upload every file (including the hidden `.github` folder).
2. Push to `main`. The *Build APK* workflow runs `gradle assembleDebug`.
3. Open the run, download the **control-center-apk** artifact, unzip and install `app-debug.apk`.
4. Push a tag like `v1.0` to also publish the APK under **Releases**.

Local build: open the folder in Android Studio (Koala or newer) and press Run.

## Shizuku (v2)

All toggles now run through **Shizuku** (adb-shell level privileges). Without Shizuku the app falls back to opening the matching system screen, as before.

| Control | With Shizuku |
| --- | --- |
| Airplane | `cmd connectivity airplane-mode enable/disable` |
| Wi-Fi | `svc wifi enable/disable` |
| Mobile data | `svc data enable/disable` |
| Bluetooth | `cmd bluetooth_manager enable/disable` (fallback `svc bluetooth`) |
| Hotspot | `cmd connectivity start-tethering wifi` (ROM dependent, falls back to the tethering screen) |
| Focus | real Do Not Disturb: `cmd notification set_dnd on/off` |
| Orientation lock | real auto-rotate setting |
| Brightness | real system brightness (manual mode) |
| Volume, Flashlight | work without Shizuku |

Settings (gear icon, top left of the Control Center):

1. **Shizuku** - status and permission button.
2. **Top-edge pull-down** - starts a small foreground service with an invisible strip at the very top edge. Pull down on it and this Control Center opens over any app. The "display over other apps" permission is granted automatically through Shizuku.
3. **System pull-down lock** - Shizuku calls `IStatusBarService.disable` (`DISABLE_EXPAND`, `DISABLE2_QUICK_SETTINGS`, `DISABLE2_NOTIFICATION_SHADE`) so the phone's own notification panel and control center do not open. The lock lives in the Shizuku user-service process: it is released when Shizuku stops or the phone restarts, and re-applied when Shizuku connects again. Switching the overlay off also releases it.

Setup order: install Shizuku, start it, open this app, Settings, allow Shizuku, switch on the overlay, then the lock.

## Settings home (v2.1)

Opening the app shows all settings (the app is in English): Shizuku status, the pull-down switch (trigger height / area, start after reboot), the stock pull-down lock, tile chooser (up to 16 tiles), preferences (24-hour clock, hint messages, vibrate on tap), a permissions page (overlay, notifications, modify system settings, Do Not Disturb access, battery) and a short setup guide. Tap **Open Control Center** to see the panel.

Without Shizuku: brightness and rotation lock work with the *Modify system settings* permission, Focus works with *Do Not Disturb access*.

## v2.3: no accessibility service, smoother panel

The pull-down now needs only three things: **Display over other apps**, **Notification access** and **Shizuku**. The accessibility service is gone.

| What | How it works now |
| --- | --- |
| Pull-down gesture | With Shizuku, the Shizuku process reads the touch screen with `getevent` and reports a swipe-down that starts in the top edge. This works even where the phone's status bar is above every overlay. Turn on the lock so the phone's own panel does not open under the same swipe (the app also sends `cmd statusbar collapse`). Without Shizuku only the thin top strip is used. |
| Notification access | `MediaListener` gives the app the active media sessions: the **Now Playing** tile shows and controls the music of any app (play / pause / next / previous). Notifications are never read or saved. One tap with Shizuku (`cmd notification allow_listener`). |
| Display over other apps | The panel and the fallback strip. Granted by Shizuku (`appops set ... SYSTEM_ALERT_WINDOW allow`). |

Smoothness changes:

- Brightness slider writes the system setting directly (the app gives itself *Modify system settings* through Shizuku) instead of starting a shell process for every move. Only the latest value is written; old ones are skipped.
- Volume only talks to the system when the step changes, and the slider ignores the system's volume broadcast while the finger is on it.
- Sliders are drawn from lambdas, so a drag no longer recomposes the whole panel. The wallpaper is cached in its own layer.
- The panel is built once in the background and only shown / hidden, so the first pull-down is no longer slow. One shared entrance animation replaces 25 separate spring animations.

## v2.4: split pull-down (right = Control Center, left = notification panel)

The top edge is now split in two halves:

| Pull down on | Opens |
| --- | --- |
| **Right half** | this Control Center |
| **Left half** | the phone's own notification panel |

How it works:

- The touch watcher only reacts to swipes that start in the right half.
- While a finger that started in the right half is on the screen, the phone's own pull-down is held back (status bar disable flags, set and released by the Shizuku process). The moment the finger lifts, it is released again, so the left half always opens the phone's own panel.
- If the phone's own panel still starts to open under a right-half swipe, the app closes it (`cmd statusbar collapse`) and shows the Control Center, as before.
- Without Shizuku only the right half gets the thin top strip; the left half is left to the phone.
- **Split pull-down** is on by default (Settings, Pull-down card). While it is on, the full lock ("Lock notification panel and stock Control Center") is not used and is switched off, because it would also block the left half. Turn Split pull-down off to get the old behaviour (Trigger area + full lock) back.
- Removed tiles: Internet panel, Camera, Code scanner and Calculator are no longer in the grid or in the tile chooser.
- The version code went up (6) so Shizuku restarts its user service with the new interface. After installing, open the app once with Shizuku running.

## v2.5: own notification panel, themes, blur, grouped settings

| What | How it works now |
| --- | --- |
| **Notification panel** | Pull down on the **left half** of the top edge: this app's own panel opens (big clock, one rounded card per notification with app icon, title, text and up to two action buttons such as *Stop*). Tap = open, swipe sideways = dismiss, *Clear all*. Needs **Notification access**. Notifications are only held in memory. Turn it off under Settings > Pull-down > "Use this app's notification panel" to get the phone's own panel back on the left half. |
| **Settings** | The settings home is a list of groups: Shizuku, Pull-down, Notification panel, Theme, Blur & background, Tiles, Behavior, Permissions, Help & About. Each opens its own page. |
| **Theme** | Dark / Light / follow system, accent colour for tiles that are on, tile shape. |
| **Blur & background** | Blurred screen (real window blur on Android 12+, falls back to the gradient if the phone does not allow it) or gradient, blur strength, tint. Same look for the Control Center and the notification panel. |
| **Mobile data** | Fixed the button jumping back to *On*: the state is now read from the data SIM's own switch (`mobile_data<subId>`), the system's answer is ignored while the change is on its way, and the switch tries `svc data`, `cmd phone data` and `settings put global mobile_data` one after the other. |
| **Tap and hold Wi-Fi / Mobile data** | Opens the floating *Internet* panel of Android (`Settings.Panel.ACTION_INTERNET_CONNECTIVITY`) over the current app, not the full Settings. Settings > Behavior can change it to the full screen. |
| More | 24-hour clock, date under the clock, hide notification content, show / hide ongoing and music notifications, "Test notification panel" button. |

Notes: the version code is 7, so Shizuku restarts its user service with the new listener interface: open the app once with Shizuku running after installing. The swipe listener now reports which half the swipe started on. `QUERY_ALL_PACKAGES` is used only to read the name and icon of the apps that post notifications.

## Other controls

| Control | Behaviour |
| --- | --- |
| Status bar battery, Wi-Fi, mobile data, airplane | Live state |
| Share | System share sheet |
| Mirror, Output | Open the matching Android settings screen |
| Timer | Countdown with beep and vibration |
| Now Playing | Music of any app (needs Notification access). Without it: tap play to pick audio files inside the app |

## Files

```
app/src/main/java/com/controlcenter/app/
  MainActivity.kt          entry point
  Controller.kt            all device logic and state
  Shell.kt / ShellService.kt  Shizuku bridge and the privileged shell process
  OverlayService.kt        overlay panel (built once, shown / hidden) + fallback strip
  MediaListener.kt         Notification access (media sessions + the notifications for the panel)
  BootReceiver.kt          restarts the overlay after reboot
  ui/SettingsScreen.kt     Settings (home list + one page per group)
  ui/NotificationPanel.kt  the app's own notification panel
  ui/Look.kt               theme, blur tint, wallpaper, tap / hold helper
  ui/ControlCenterScreen.kt  layout (grid of 214 x 465 units), sheets
  ui/Icons.kt              SVG path icons drawn with Compose Canvas
  ui/Calc.kt               calculator logic
.github/workflows/build-apk.yml   APK build
```

## License

MIT


## v2.6 changes

- **Edit inside the panel**: tap **Edit** in the Control Center (no need to open the app). Every tile gets a small minus at its top right to remove it, hold a tile and drag it to move it, and the tiles that are off are listed below with a plus to add them back. **Settings** and **Done** buttons are shown in edit mode.
- The tile order is saved (`tile_order`); Settings > Tiles still works and keeps the order.
- The navigation bar is no longer a solid black bar while the panel is open.

- **Developer card** (Foysal) in Settings > Help & About; tap the e-mail to write to the developer.
- **Release build**: the workflow now builds a signed release APK when the signing secrets exist (see "Making a release" below); a running timer is set again after a reboot; app data is no longer copied by Android backup.

## Making a release

1. Make a keystore once (keep it safe, never commit it):
   `keytool -genkeypair -v -keystore release.jks -alias cc -keyalg RSA -keysize 2048 -validity 10000`
2. In the GitHub repo, Settings > Secrets and variables > Actions, add: `KEYSTORE_BASE64` (output of `base64 -w0 release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
3. Raise `versionCode` / `versionName` in `app/build.gradle.kts`, then push a tag: `git tag v2.6 && git push origin v2.6`.
4. The signed APK appears under the repo's Releases. Always sign updates with the same keystore, or Android will refuse to update the installed app.

Local build: put `storeFile`, `storePassword`, `keyAlias`, `keyPassword` into `keystore.properties` and run `gradle assembleRelease`.

## v2.7 changes

- **Two new Control Center styles** (Settings > Theme > Style): **MIUI** (title with settings and edit buttons, wide tiles, round buttons, wide brightness / volume sliders) and **HyperOS** (glass look, pill Wi-Fi / Mobile data, music tile, round sliders, round buttons with names, date). The iOS style stays the default. Tile editing (minus, hold and drag, add) works in all three.
- **Transparent navigation bar**: the panels now live in a real window (Dialog) with a transparent navigation bar and no contrast scrim, instead of a bare overlay view that left a black bar.
- Default tile order starts with Bluetooth and Flashlight (they are the two wide tiles in the MIUI style). Saved orders are kept.

## Custom status bar (v2.8)

Settings → **Status bar**: draws a custom status bar (time, notification icons, network speed, alarm, VoLTE, Wi-Fi, mobile signal, battery pill) and hides the phone's own one through Shizuku. It is **off by default**.

- The button at the very top of Settings, **Restore phone's status bar & Control Center**, switches the custom bar and the pull-down off and gives the phone's own status bar and Control Center back.
- The phone's own bar is also given back on the lock screen, while the screen is off, and when Shizuku stops.
