package com.controlcenter.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.controlcenter.app.NotifStore
import com.controlcenter.app.StatusData

private val WHITE = Color.White
private val DIM = Color(0x55FFFFFF)
private val SAVER = Color(0xFFF5A623)
private val GREEN = Color(0xFF34C759)
private val RED = Color(0xFFFF453A)

/**
 * The custom status bar: time and notification icons on the left; network speed, alarm, VoLTE, Wi-Fi, mobile
 * signal and a battery pill with the percentage on the right. Nothing is drawn until the phone's own bar is hidden.
 */
@Composable
fun StatusBarContent(d: StatusData) {
    if (!d.active || d.panel) return

    Box(Modifier.fillMaxSize().background(if (d.black) Color.Black else Color.Transparent)) {
        Row(
            Modifier.fillMaxSize().padding(start = d.padStart.dp, end = d.padEnd.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            /* ---------- left: clock + notification icons ---------- */
            Text(d.time, color = WHITE, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
            if (d.showNotif) {
                val icons = NotifStore.statusIcons
                if (icons.isNotEmpty()) {
                    Spacer(Modifier.width(6.dp))
                    icons.take(3).forEach {
                        Image(
                            bitmap = it, contentDescription = null,
                            colorFilter = ColorFilter.tint(WHITE),
                            modifier = Modifier.padding(horizontal = 2.dp).size(15.dp)
                        )
                    }
                    if (icons.size > 3) Text("···", color = WHITE, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }

            Spacer(Modifier.weight(1f))

            /* ---------- right: status icons ---------- */
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (d.showSpeed) {
                    Column(Modifier.widthIn(min = 28.dp), horizontalAlignment = Alignment.End) {
                        Text(d.speed, color = WHITE, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp, maxLines = 1, softWrap = false)
                        Text(d.speedUnit, color = WHITE, fontSize = 8.sp, fontWeight = FontWeight.Medium, lineHeight = 9.sp, maxLines = 1, softWrap = false)
                    }
                }
                if (d.alarm) AlarmIcon()
                if (d.showVolte && d.volte && d.netType.isNotEmpty()) VolteBadge()
                if (d.wifiLevel >= 0) WifiIcon(d.wifiLevel)
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (d.netType.isNotEmpty()) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d.netType, color = WHITE, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp, maxLines = 1, softWrap = false)
                            Row {
                                SvgIcon(Ic.triUp, 6.dp, if (d.up) WHITE else DIM)
                                SvgIcon(Ic.triDown, 6.dp, if (d.down) WHITE else DIM)
                            }
                        }
                    }
                    SignalBars(d.signal)
                }
                BatteryPill(d.battery, d.charging, d.saver)
            }
        }
    }
}

/** Alarm clock: ring, two hands and the two bells. */
@Composable
private fun AlarmIcon() {
    Canvas(Modifier.size(14.dp)) {
        val w = size.width
        val sw = w * 0.12f
        val c = Offset(w / 2f, w * 0.56f)
        val r = w * 0.34f
        drawCircle(WHITE, r, c, style = Stroke(sw))
        drawLine(WHITE, c, Offset(c.x, c.y - r * 0.6f), sw, StrokeCap.Round)
        drawLine(WHITE, c, Offset(c.x + r * 0.45f, c.y + r * 0.2f), sw, StrokeCap.Round)
        drawCircle(WHITE, w * 0.15f, Offset(w * 0.17f, w * 0.2f))
        drawCircle(WHITE, w * 0.15f, Offset(w * 0.83f, w * 0.2f))
    }
}

/** White "Vo LTE" badge. */
@Composable
private fun VolteBadge() {
    Box(
        Modifier.background(WHITE, RoundedCornerShape(3.dp)).padding(horizontal = 3.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Vo", color = Color.Black, fontSize = 6.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 6.sp, maxLines = 1)
            Text("LTE", color = Color.Black, fontSize = 6.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 6.sp, maxLines = 1)
        }
    }
}

/** Wi-Fi fan: a dot and three arcs, lit by signal level 0..4. */
@Composable
private fun WifiIcon(level: Int) {
    Canvas(Modifier.size(16.dp)) {
        val w = size.width
        val sw = w * 0.11f
        val cx = w / 2f
        val cy = w * 0.9f
        val lit = (level * 3 + 3) / 4
        drawCircle(WHITE, w * 0.08f, Offset(cx, cy))
        for (i in 1..3) {
            val r = w * (0.22f * i + 0.05f)
            drawArc(
                color = if (i <= lit) WHITE else DIM,
                startAngle = 225f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - r, cy - r), size = Size(r * 2f, r * 2f),
                style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
    }
}

/** Four bars that grow in height; the first [level] are lit. */
@Composable
private fun SignalBars(level: Int) {
    Row(
        Modifier.height(13.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(1.5.dp)
    ) {
        for (i in 1..4) {
            Box(
                Modifier.width(3.dp).height((3f + i * 2.5f).dp)
                    .background(if (i <= level) WHITE else DIM, RoundedCornerShape(1.dp))
            )
        }
    }
}

/** Battery pill with the percentage inside: green while charging, orange in battery saver, red when low. */
@Composable
private fun BatteryPill(level: Int, charging: Boolean, saver: Boolean) {
    val fill = when {
        charging -> GREEN
        saver -> SAVER
        level <= 15 -> RED
        else -> WHITE
    }
    val text = if (fill == WHITE) Color.Black else Color.White
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(24.dp).height(13.dp).clip(RoundedCornerShape(4.dp)).background(DIM)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(level.coerceIn(0, 100) / 100f).background(fill))
            Text(
                level.toString(), color = text, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
                lineHeight = 10.sp, maxLines = 1, softWrap = false, modifier = Modifier.align(Alignment.Center)
            )
        }
        Box(Modifier.width(2.dp).height(5.dp).background(DIM, RoundedCornerShape(topEnd = 1.dp, bottomEnd = 1.dp)))
    }
}
