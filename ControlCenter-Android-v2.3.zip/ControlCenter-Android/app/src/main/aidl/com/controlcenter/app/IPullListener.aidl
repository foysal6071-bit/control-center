package com.controlcenter.app;

// Called from the Shizuku shell process when a swipe-down from the top edge is seen.
oneway interface IPullListener {
    void onPull() = 1;
}
