package com.controlcenter.app;

import com.controlcenter.app.IPullListener;

interface IUserService {
    // Transaction id reserved by Shizuku for "destroy" (must be 16777114).
    void destroy() = 16777114;

    // Runs a shell command as the shell user. Returns "<exit code>\n<output>".
    String exec(String cmd) = 1;

    // Locks / unlocks the phone's own notification panel and quick settings pull-down.
    boolean setStatusBarLocked(boolean locked) = 2;

    // Watches the touch screen (getevent) and calls listener.onPull() when a finger that started in the
    // top edge area moves down. w/h = natural (portrait) display size in px, rotation = Surface.ROTATION_*,
    // side = 0 full width, 1 left half, 2 right half. Returns false if no touch screen was found.
    boolean startPullWatch(IPullListener listener, int w, int h, int rotation, int topPx, int dragPx, int side) = 3;

    void setPullRotation(int rotation) = 4;

    void stopPullWatch() = 5;
}
