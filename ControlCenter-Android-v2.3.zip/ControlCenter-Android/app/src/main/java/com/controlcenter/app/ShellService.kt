package com.controlcenter.app

import android.os.Binder
import android.os.IBinder
import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku "user service" process, which has the privileges of the adb shell.
 * Everything that a normal app cannot do (Wi-Fi, data, airplane, Bluetooth, DND, status bar lock)
 * is done from here.
 */
class ShellService : IUserService.Stub() {

    /** Status bar disable flags stay active as long as this token (= this process) is alive. */
    private val token: IBinder = Binder()

    override fun destroy() {
        stopPullWatch()
        exitProcess(0)
    }

    /* ---------- pull-down watcher: reads the raw touch screen events (no accessibility service) ---------- */

    @Volatile private var watchProc: Process? = null
    @Volatile private var watchGen = 0
    @Volatile private var rotation = 0

    private class Touch(val path: String, val maxX: Int, val maxY: Int)

    /** Finds the touch screen with `getevent -pl` (the device with multi-touch X/Y axes and INPUT_PROP_DIRECT). */
    private fun findTouch(): Touch? {
        val out = try {
            val p = ProcessBuilder("getevent", "-pl").redirectErrorStream(true).start()
            val text = p.inputStream.bufferedReader().readText()
            p.waitFor()
            text
        } catch (_: Throwable) {
            return null
        }
        val maxRe = Regex("max\\s+(-?\\d+)")
        var best: Touch? = null
        var bestDirect = false
        var path: String? = null
        var mx = 0
        var my = 0
        var direct = false
        fun flush() {
            val pth = path ?: return
            if (mx <= 0 || my <= 0) return
            val cand = Touch(pth, mx, my)
            val b = best
            val better = b == null ||
                (direct && !bestDirect) ||
                (direct == bestDirect && mx.toLong() * my > b.maxX.toLong() * b.maxY)
            if (better) {
                best = cand
                bestDirect = direct
            }
        }
        for (raw in out.lineSequence()) {
            val t = raw.trim()
            if (t.startsWith("add device")) {
                flush()
                path = t.substringAfter(':', "").trim().ifEmpty { null }
                mx = 0; my = 0; direct = false
            } else if (t.contains("ABS_MT_POSITION_X")) {
                mx = maxRe.find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            } else if (t.contains("ABS_MT_POSITION_Y")) {
                my = maxRe.find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            } else if (t.contains("INPUT_PROP_DIRECT")) {
                direct = true
            }
        }
        flush()
        return best
    }

    override fun startPullWatch(
        listener: IPullListener, w: Int, h: Int, rotation: Int, topPx: Int, dragPx: Int, side: Int
    ): Boolean {
        stopPullWatch()
        val touch = findTouch() ?: return false
        val proc = try {
            ProcessBuilder("getevent", "-l", touch.path).redirectErrorStream(true).start()
        } catch (_: Throwable) {
            return false
        }
        this.rotation = rotation
        watchProc = proc
        val gen = ++watchGen
        Thread {
            try {
                watchLoop(proc, gen, touch, listener, w, h, topPx, dragPx, side)
            } catch (_: Throwable) {
            } finally {
                try { proc.destroy() } catch (_: Throwable) {}
            }
        }.apply { isDaemon = true; name = "pull-watch"; start() }
        return true
    }

    override fun setPullRotation(rotation: Int) {
        this.rotation = rotation
    }

    override fun stopPullWatch() {
        watchGen++
        try { watchProc?.destroy() } catch (_: Throwable) {}
        watchProc = null
    }

    private fun watchLoop(
        proc: Process, gen: Int, touch: Touch, listener: IPullListener,
        w: Int, h: Int, topPx: Int, dragPx: Int, side: Int
    ) {
        val n = 10
        val trackId = LongArray(n) { -1L }       // -1 = finger up
        val rawX = FloatArray(n) { -1f }
        val rawY = FloatArray(n) { -1f }
        val fresh = BooleanArray(n)
        val armed = BooleanArray(n)
        val fired = BooleanArray(n)
        val startX = FloatArray(n)
        val startY = FloatArray(n)
        var slot = 0

        fun reset(i: Int) {
            trackId[i] = -1L; rawX[i] = -1f; rawY[i] = -1f
            fresh[i] = false; armed[i] = false; fired[i] = false
        }

        fun evaluate(i: Int): Boolean {
            if (trackId[i] < 0 || rawX[i] < 0 || rawY[i] < 0) return false
            // natural panel position in px
            val px = rawX[i] / touch.maxX * w
            val py = rawY[i] / touch.maxY * h
            // rotate into the current screen orientation
            val sx: Float
            val sy: Float
            val sw: Float
            when (rotation) {
                1 -> { sx = py; sy = w - px; sw = h.toFloat() }
                2 -> { sx = w - px; sy = h - py; sw = w.toFloat() }
                3 -> { sx = h - py; sy = px; sw = h.toFloat() }
                else -> { sx = px; sy = py; sw = w.toFloat() }
            }
            if (fresh[i]) {
                fresh[i] = false
                startX[i] = sx
                startY[i] = sy
                val inSide = when (side) { 1 -> sx < sw / 2f; 2 -> sx >= sw / 2f; else -> true }
                armed[i] = sy <= topPx && inSide
                return false
            }
            if (armed[i] && !fired[i]) {
                val dy = sy - startY[i]
                val dx = Math.abs(sx - startX[i])
                if (dy >= dragPx && dy > dx) {
                    fired[i] = true
                    return true
                }
            }
            return false
        }

        proc.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (gen != watchGen) break
                val tok = line.trim().split(Regex("\\s+"))
                val k = tok.indexOfFirst { it.startsWith("EV_") }
                if (k < 0 || tok.size < k + 3) continue
                val type = tok[k]
                val code = tok[k + 1]
                val value = tok[k + 2]
                when (type) {
                    "EV_ABS" -> when (code) {
                        "ABS_MT_SLOT" -> slot = (value.toIntOrNull(16) ?: 0).coerceIn(0, n - 1)
                        "ABS_MT_TRACKING_ID" -> {
                            val id = value.toLongOrNull(16) ?: -1L
                            if (id == 0xFFFFFFFFL) reset(slot)
                            else if (id != trackId[slot]) {
                                reset(slot)
                                trackId[slot] = id
                                fresh[slot] = true
                            }
                        }
                        "ABS_MT_POSITION_X" -> rawX[slot] = (value.toLongOrNull(16) ?: -1L).toFloat()
                        "ABS_MT_POSITION_Y" -> rawY[slot] = (value.toLongOrNull(16) ?: -1L).toFloat()
                    }
                    "EV_KEY" -> if (code == "BTN_TOUCH" && value == "UP") for (i in 0 until n) reset(i)
                    "EV_SYN" -> if (code == "SYN_REPORT") {
                        var hit = false
                        for (i in 0 until n) if (evaluate(i)) hit = true
                        if (hit) {
                            try {
                                listener.onPull()
                            } catch (_: Throwable) {
                                return   // the app is gone: stop watching
                            }
                        }
                    }
                }
            }
        }
    }

    override fun exec(cmd: String): String {
        return try {
            val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
            val killer = Thread {
                try {
                    Thread.sleep(20_000)
                    p.destroyForcibly()
                } catch (_: InterruptedException) {
                }
            }.apply { isDaemon = true; start() }
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            killer.interrupt()
            "$code\n$out"
        } catch (t: Throwable) {
            "-1\n${t.message}"
        }
    }

    override fun setStatusBarLocked(locked: Boolean): Boolean {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "statusbar") as IBinder
            val stub = Class.forName("com.android.internal.statusbar.IStatusBarService\$Stub")
            val svc = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!

            // StatusBarManager.DISABLE_EXPAND  = 0x00010000
            // StatusBarManager.DISABLE2_QUICK_SETTINGS = 1, DISABLE2_NOTIFICATION_SHADE = 1 shl 2
            val what = if (locked) 0x00010000 else 0
            val what2 = if (locked) (1 or 4) else 0

            val ok1 = call(svc, "disable", what)
            call(svc, "disable2", what2)
            ok1
        } catch (t: Throwable) {
            false
        }
    }

    private fun call(svc: Any, name: String, what: Int): Boolean {
        val c = svc.javaClass
        val int = Int::class.javaPrimitiveType
        try {
            c.getMethod(name, int, IBinder::class.java, String::class.java).invoke(svc, what, token, "com.android.shell")
            return true
        } catch (_: NoSuchMethodException) {
        } catch (_: Throwable) {
            return false
        }
        // newer Android versions only have the "ForUser" variants
        return try {
            c.getMethod(name + "ForUser", int, IBinder::class.java, String::class.java, int)
                .invoke(svc, what, token, "com.android.shell", 0)
            true
        } catch (_: Throwable) {
            false
        }
    }
}
