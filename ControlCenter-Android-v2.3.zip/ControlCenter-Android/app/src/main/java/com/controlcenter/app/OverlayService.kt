package com.controlcenter.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import android.view.animation.DecelerateInterpolator
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.controlcenter.app.ui.ControlCenterApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Opens this app's Control Center as an overlay on top of every app when you pull down from the top.
 *
 *  - With Shizuku the raw touch screen events are watched (see ShellService), so the swipe is seen even
 *    where the phone's own status bar sits above every overlay. No accessibility service is used.
 *  - Without Shizuku a thin invisible strip over the top edge catches the swipe (works where the phone
 *    lets an overlay sit on the status bar).
 *
 * The panel window is built once, in the background, and only shown / hidden afterwards, so pulling down
 * does not have to build the whole screen at that moment (this is what made it lag before).
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val owner = ViewOwner()
    private var strip: View? = null
    private var panel: PanelFrame? = null
    private var panelView: ComposeView? = null
    private var panelRotation = -1
    private var panelShown = false
    private val panelActive = mutableStateOf(false)
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val r = rotation()
            if (r == lastRotation) return
            lastRotation = r
            Shell.setPullRotation(r)
            rebuildStrip()
        }
    }
    private var lastRotation = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // startForegroundService() requires startForeground() right away, even if we stop again below
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WindowManager::class.java)
        owner.resume()
        addStrip()
        instance = this
        running = true
        lastRotation = rotation()
        try {
            getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, main)
        } catch (_: Exception) {
        }
        startTouchWatch()
        // build the panel in the background so the first pull-down is instant
        main.postDelayed({ if (instance === this) ensurePanel() }, 600)
        // after a restart: put the lock of the phone's own pull-down back (no-op if Shizuku is not ready yet)
        if (getSharedPreferences("cc", Context.MODE_PRIVATE).getBoolean("lock_stock", false)) {
            scope.launch { Shell.setStatusBarLocked(true) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        instance = null
        main.removeCallbacksAndMessages(null)
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener) } catch (_: Exception) {}
        Shell.unwatchPull()
        try { destroyPanel() } catch (_: Exception) {}
        try { strip?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        strip = null
        owner.destroy()
        // Never leave the phone without any pull-down: when the trigger is gone, unlock the stock one.
        scope.launch { Shell.setStatusBarLocked(false) }
        super.onDestroy()
    }

    /* ---------- foreground notification ---------- */

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("cc_overlay", "Control Center", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_SETTINGS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, "cc_overlay")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Control Center is on")
            .setContentText("Pull down from the top of the screen · tap for settings")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    /* ---------- trigger ---------- */

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun systemDimen(name: String, fallbackDp: Float): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(fallbackDp).toInt()
    }

    private fun rotation(): Int = try {
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
    } catch (_: Exception) {
        Surface.ROTATION_0
    }

    /** Height of the trigger area in px, from the "Trigger height" setting. */
    private fun triggerHeight(): Int {
        val prefs = getSharedPreferences("cc", Context.MODE_PRIVATE)
        val base = systemDimen("status_bar_height", 26f).coerceAtLeast(dp(20f).toInt())
        return when (prefs.getInt("trigger_h", 1)) {
            0 -> dp(16f).toInt()
            2 -> dp(44f).toInt()
            else -> base
        }
    }

    /** Shizuku: watch the touch screen itself. Starts by itself as soon as Shizuku is connected. */
    private fun startTouchWatch() {
        val prefs = getSharedPreferences("cc", Context.MODE_PRIVATE)
        val d = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        d?.getRealMetrics(dm)
        val rot = rotation()
        val land = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270
        val w = if (land) dm.heightPixels else dm.widthPixels
        val h = if (land) dm.widthPixels else dm.heightPixels
        if (w <= 0 || h <= 0) return
        // the touch starts a little lower than the very first pixel, so allow some room
        val top = (triggerHeight() * 1.25f).toInt()
        Shell.watchPull(
            Shell.PullCfg(w, h, rot, top, dp(20f).toInt(), prefs.getInt("trigger_side", 0))
        ) { onPull() }
    }

    private fun onPull() {
        if (instance !== this) return
        val kg = getSystemService(KeyguardManager::class.java)
        if (kg != null && kg.isKeyguardLocked) return
        if (panelShown) return
        // if the phone's own panel started to open under the same swipe, close it
        if (Shell.ready) scope.launch { Shell.exec("cmd statusbar collapse") }
        showPanel()
    }

    /** Without Shizuku: a thin invisible strip over the top edge. */
    private fun addStrip() {
        val prefs = getSharedPreferences("cc", Context.MODE_PRIVATE)
        val h = triggerHeight()
        val side = prefs.getInt("trigger_side", 0) // 0 = full width, 1 = left half, 2 = right half
        val v = object : View(this) {
            private var downY = 0f
            private var fired = false
            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downY = e.rawY; fired = false }
                    MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - downY > dp(22f)) {
                        fired = true
                        showPanel()
                    }
                }
                return true
            }
        }
        val lp = WindowManager.LayoutParams(
            if (side == 0) ViewGroup.LayoutParams.MATCH_PARENT else resources.displayMetrics.widthPixels / 2, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or (if (side == 2) Gravity.END else Gravity.START) }
        wm.addView(v, lp)
        strip = v
    }

    private fun rebuildStrip() {
        try { strip?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        strip = null
        try { addStrip() } catch (_: Exception) {}
    }

    /* ---------- the Control Center panel ---------- */

    /** Builds the panel window once. It stays attached but hidden (GONE) until it is needed. */
    private fun ensurePanel() {
        if (panel != null) return
        val themed = ContextThemeWrapper(this, R.style.Theme_ControlCenter)
        val top = systemDimen("status_bar_height", 26f)
        val bottom = systemDimen("navigation_bar_height", 0f)
        val density = resources.displayMetrics.density

        val root = PanelFrame(themed) { hidePanel(true) }
        val cv = ComposeView(themed)
        cv.setContent {
            ControlCenterApp(
                onOpenSettings = {
                    startActivity(
                        Intent(this, MainActivity::class.java)
                            .putExtra(MainActivity.EXTRA_SETTINGS, true)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    hidePanel(true)
                },
                onClose = { hidePanel(true) },
                insetTop = androidx.compose.ui.unit.Dp(top / density),
                insetBottom = androidx.compose.ui.unit.Dp(bottom / density),
                active = panelActive.value
            )
        }
        root.addView(cv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setViewTreeLifecycleOwner(owner)
        root.setViewTreeSavedStateRegistryOwner(owner)
        root.setViewTreeViewModelStoreOwner(owner)
        root.visibility = View.GONE

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(root, lp)
        } catch (_: Exception) {
            return
        }
        panel = root
        panelView = cv
        panelRotation = rotation()
    }

    private fun destroyPanel() {
        val p = panel ?: return
        val cv = panelView
        panel = null
        panelView = null
        panelShown = false
        panelActive.value = false
        p.animate().cancel()
        try { cv?.disposeComposition() } catch (_: Exception) {}
        try { wm.removeViewImmediate(p) } catch (_: Exception) {}
    }

    private fun showPanel() {
        if (panelShown || instance !== this) return
        // the screen was rotated since the panel was built: the insets are different, build it again
        if (panel != null && panelRotation != rotation()) destroyPanel()
        ensurePanel()
        val p = panel ?: return
        panelShown = true
        p.animate().cancel()
        p.alpha = 0f
        p.translationY = -resources.displayMetrics.heightPixels * 0.18f
        p.arm()
        panelActive.value = true
        p.visibility = View.VISIBLE
        p.isFocusable = true
        p.isFocusableInTouchMode = true
        p.requestFocus()
        p.animate().alpha(1f).translationY(0f).setDuration(240)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    private fun hidePanel(animated: Boolean) {
        val p = panel ?: return
        if (!panelShown) return
        panelShown = false
        p.animate().cancel()
        fun finish() {
            panelActive.value = false
            p.visibility = View.GONE
            p.alpha = 1f
            p.translationY = 0f
        }
        if (animated) {
            p.animate().alpha(0f).translationY(-p.height * 0.12f).setDuration(150)
                .setInterpolator(DecelerateInterpolator()).withEndAction { finish() }.start()
        } else {
            finish()
        }
    }

    /** Window root: Back key and losing focus (Home, Recents, another window) close the panel. */
    private class PanelFrame(ctx: Context, val close: () -> Unit) : FrameLayout(ctx) {
        private var hadFocus = false

        /** Called every time the panel is shown: losing focus only closes it after it had focus once. */
        fun arm() { hadFocus = false }

        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) close()
                return true
            }
            return super.dispatchKeyEvent(e)
        }

        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus) hadFocus = true
            else if (hadFocus) close()
        }
    }

    /** Lifecycle / saved state / view model owner that a ComposeView needs outside an Activity. */
    private class ViewOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = store

        init {
            controller.performAttach()
            controller.performRestore(null)
            registry.currentState = Lifecycle.State.CREATED
        }

        fun resume() {
            registry.currentState = Lifecycle.State.RESUMED
        }

        fun destroy() {
            registry.currentState = Lifecycle.State.DESTROYED
            store.clear()
        }
    }

    companion object {
        @Volatile
        var running = false
            private set

        /** The live service (null while the pull-down is off). */
        @Volatile
        var instance: OverlayService? = null
            private set

        /** Opens the panel right now (used by the Test button). Main thread only. */
        fun openNow(): Boolean {
            val s = instance ?: return false
            s.showPanel()
            return true
        }

        fun start(ctx: Context) {
            androidx.core.content.ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
