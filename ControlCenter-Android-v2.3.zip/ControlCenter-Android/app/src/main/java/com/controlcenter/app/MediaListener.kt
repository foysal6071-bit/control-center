package com.controlcenter.app

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * "Notification access". The app never reads or stores notifications. Having this access is what lets
 * Android hand the app the active media sessions, so the Now Playing tile can show and control the music
 * of any app (YouTube, Spotify, ...). While it is bound, Android also keeps the app process alive, and
 * the pull-down trigger is put back if it was stopped.
 */
class MediaListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        val p = getSharedPreferences("cc", Context.MODE_PRIVATE)
        if (p.getBoolean("overlay_on", false) && !OverlayService.running && Settings.canDrawOverlays(this)) {
            try {
                OverlayService.start(this)
            } catch (_: Exception) {
            }
        }
    }

    companion object {
        fun component(ctx: Context) = ComponentName(ctx, MediaListener::class.java)

        fun hasAccess(ctx: Context): Boolean = try {
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        } catch (_: Exception) {
            false
        }
    }
}
