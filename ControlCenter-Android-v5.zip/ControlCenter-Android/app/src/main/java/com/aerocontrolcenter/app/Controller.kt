package com.aerocontrolcenter.app

import android.app.Activity
import android.app.NotificationManager
import android.app.UiModeManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContentResolver
import android.content.ContextWrapper
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.database.ContentObserver
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * All real device behaviour lives here. Where Android does not let an app change a system
 * setting (airplane mode, Wi-Fi, hotspot, ...), the control opens the matching system screen
 * instead of faking a result.
 */
class Controller(private val ctx: Context, private val scope: CoroutineScope) {

    private val activity: Activity? = ctx.findActivity()
    private val prefs = ctx.getSharedPreferences("cc", Context.MODE_PRIVATE)
    private val cm = ctx.getSystemService(ConnectivityManager::class.java)
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val camMgr = ctx.getSystemService(CameraManager::class.java)
    private val wifiMgr = ctx.applicationContext.getSystemService(WifiManager::class.java)

    /* ---------- observable state ---------- */
    var airplane by mutableStateOf(false)
    var online by mutableStateOf(false)
    var wifi by mutableStateOf(false)
    var cell by mutableStateOf(false)

    /** Real on/off state of the switches (Wi-Fi radio, mobile data, hotspot) - read live, changed through Shizuku. */
    var wifiOn by mutableStateOf(false)
    var dataOn by mutableStateOf(false)
    var hotspot by mutableStateOf(false)
    var bluetooth by mutableStateOf(false)
    var batteryLevel by mutableFloatStateOf(1f)
    var charging by mutableStateOf(false)
    var torch by mutableStateOf(false)
    var locked by mutableStateOf(false)
    var focus by mutableStateOf(false)
    var locationOn by mutableStateOf(false)
    var nfcOn by mutableStateOf(false)
    var darkOn by mutableStateOf(false)
    var saverOn by mutableStateOf(false)
    var syncOn by mutableStateOf(false)
    var brightness by mutableFloatStateOf(if (Shell.ready || canWriteSettings()) systemBrightness() else prefs.getFloat("brightness", systemBrightness()))
    var volume by mutableFloatStateOf(0.5f)

    var toastText by mutableStateOf("")
    var toastTick by mutableIntStateOf(0)

    /** What the Now Playing tile shows: the music of any app (needs Notification access) or the files picked in the app. */
    var nowPlaying by mutableStateOf("Not Playing")
        private set
    var playing by mutableStateOf(false)
        private set
    private var localTitle = "Not Playing"
    private var localPlaying = false
    var onPickAudio: () -> Unit = {}

    /** Called after a system screen / another app was opened (the overlay panel closes itself then). */
    var onLaunched: () -> Unit = {}

    var qrResult by mutableStateOf<String?>(null)

    var timerMin by mutableIntStateOf(prefs.getInt("timerMin", 5))
    var timerEnd by mutableLongStateOf(prefs.getLong("timerEnd", 0L))
    var timerNow by mutableLongStateOf(System.currentTimeMillis())
    val timerRunning: Boolean get() = timerEnd > 0L

    /* ---------- toast (muted while Focus is on) ---------- */
    fun say(msg: String, force: Boolean = false) {
        if (!force && (focus || !prefs.getBoolean("hints", true))) return
        toastText = msg
        toastTick++
    }

    /* ---------- lifecycle ---------- */
    private var torchId: String? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var torchCb: CameraManager.TorchCallback? = null
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val intent = i ?: return
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> readBattery(intent)
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> readAirplane()
                BluetoothAdapter.ACTION_STATE_CHANGED -> readBluetooth()
                WifiManager.WIFI_STATE_CHANGED_ACTION -> readWifi()
                "android.media.VOLUME_CHANGED_ACTION" -> readVolume()
            }
        }
    }

    private val settingsObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            readAirplane(); readData(); readZen(); readRotation()
        }
    }

    private val resumeObserver = LifecycleEventObserver { _, e ->
        if (e == Lifecycle.Event.ON_RESUME) refresh()
    }

    fun start() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction("android.media.VOLUME_CHANGED_ACTION")
        }
        try {
            ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        } catch (_: Exception) {
        }
        try {
            ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { readBattery(it) }
        } catch (_: Exception) {
        }

        try {
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) = updateNet(cm.getNetworkCapabilities(network))
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = updateNet(caps)
                override fun onLost(network: Network) = updateNet(null)
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
            updateNet(cm.getNetworkCapabilities(cm.activeNetwork))
        } catch (_: Exception) {
        }

        try {
            val id = camMgr.cameraIdList.firstOrNull { cid ->
                val c = camMgr.getCameraCharacteristics(cid)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            torchId = id
            val tcb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) torch = enabled
                }
            }
            camMgr.registerTorchCallback(tcb, null)
            torchCb = tcb
        } catch (_: Exception) {
        }

        try {
            val cr = ctx.contentResolver
            cr.registerContentObserver(Settings.Global.getUriFor("mobile_data"), false, settingsObserver)
            val sub = dataSubId()
            if (sub >= 0) cr.registerContentObserver(Settings.Global.getUriFor("mobile_data$sub"), false, settingsObserver)
            cr.registerContentObserver(Settings.Global.getUriFor("zen_mode"), false, settingsObserver)
            cr.registerContentObserver(Settings.Global.getUriFor(Settings.Global.AIRPLANE_MODE_ON), false, settingsObserver)
            cr.registerContentObserver(Settings.System.getUriFor(Settings.System.ACCELEROMETER_ROTATION), false, settingsObserver)
        } catch (_: Exception) {
        }

        (activity as? LifecycleOwner)?.lifecycle?.addObserver(resumeObserver)
        refresh()
        if (!Shell.ready && !canWriteSettings() && prefs.contains("brightness")) applyBrightness()
        startWorkers()
        registerSessions()
        // With Shizuku the app gives itself "Modify system settings": brightness is then written directly (fast).
        if (Shell.ready && !writeOk) scope.launch {
            Shell.exec("appops set ${ctx.packageName} WRITE_SETTINGS allow")
            delay(300)
            writeOk = canWriteSettings()
        }
    }

    fun stop() {
        stopWorkers()
        unregisterSessions()
        (activity as? LifecycleOwner)?.lifecycle?.removeObserver(resumeObserver)
        try { if (registered) ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
        try { ctx.contentResolver.unregisterContentObserver(settingsObserver) } catch (_: Exception) {}
        registered = false
        try { netCb?.let { cm.unregisterNetworkCallback(it) } } catch (_: Exception) {}
        netCb = null
        try { torchCb?.let { camMgr.unregisterTorchCallback(it) } } catch (_: Exception) {}
        torchCb = null
    }

    /** Final clean-up when the screen is gone for good (the panel only calls [stop] while it is hidden). */
    fun release() {
        releasePlayer()
    }

    fun refresh() {
        writeOk = canWriteSettings()
        registerSessions()
        readAirplane(); readBluetooth(); readVolume()
        readWifi(); readData(); readZen(); readRotation(); readSystemBrightness(); readExtras()
        try { updateNet(cm.getNetworkCapabilities(cm.activeNetwork)) } catch (_: Exception) {}
    }

    /* ---------- live state readers ---------- */
    private fun updateNet(caps: NetworkCapabilities?) {
        online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        cell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    }

    private fun readWifi() {
        wifiOn = try { wifiMgr?.isWifiEnabled == true } catch (_: Exception) { false }
    }

    /** While a change is on its way the answer of the system is not trusted yet (it still shows the old value). */
    @Volatile private var dataHoldUntil = 0L

    private fun readData() {
        if (System.currentTimeMillis() < dataHoldUntil) return
        dataOn = realDataState()
    }

    /** Id of the SIM that is used for mobile data (-1 if unknown). */
    private fun dataSubId(): Int = try {
        val id = SubscriptionManager.getDefaultDataSubscriptionId()
        if (id >= 0 && id != Int.MAX_VALUE) id else -1
    } catch (_: Throwable) {
        -1
    }

    /**
     * The real on/off state of mobile data. Phones with two SIMs keep one switch per SIM ("mobile_data<id>"),
     * so that key of the data SIM is read first; the plain "mobile_data" is only the fallback. Reading only the
     * plain key is what made the button jump back to "On" after it had been switched off.
     */
    private fun realDataState(): Boolean = try {
        val cr = ctx.contentResolver
        var v = -1
        val sub = dataSubId()
        if (sub >= 0) v = Settings.Global.getInt(cr, "mobile_data$sub", -1)
        if (v < 0) v = Settings.Global.getInt(cr, "mobile_data", -1)
        if (v < 0) v = Settings.Global.getInt(cr, "mobile_data1", 0)
        v == 1
    } catch (_: Exception) {
        false
    }

    /** With Shizuku the Focus button is the real Do Not Disturb switch. */
    private fun readZen() {
        if (Shell.ready) {
            focus = try { Settings.Global.getInt(ctx.contentResolver, "zen_mode", 0) != 0 } catch (_: Exception) { focus }
        } else if (hasDndAccess()) {
            val f = notifMgr?.currentInterruptionFilter ?: return
            focus = f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        }
    }

    private val notifMgr: NotificationManager? get() = ctx.getSystemService(NotificationManager::class.java)
    private fun hasDndAccess(): Boolean = try { notifMgr?.isNotificationPolicyAccessGranted == true } catch (_: Exception) { false }
    private fun canWriteSettings(): Boolean = try { Settings.System.canWrite(ctx) } catch (_: Exception) { false }

    /** With Shizuku the lock button is the real auto-rotate switch of the phone. */
    private fun readRotation() {
        if (!Shell.ready && !canWriteSettings()) return
        locked = try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        } catch (_: Exception) {
            locked
        }
    }

    private var lastBrightSet = 0L
    private fun readSystemBrightness() {
        if (!Shell.ready && !canWriteSettings()) return
        if (brightDragging || System.currentTimeMillis() - lastBrightSet < 1500) return
        brightness = systemBrightness()
    }

    private fun readBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (lvl >= 0 && scale > 0) batteryLevel = lvl / scale.toFloat()
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    /** Location, NFC, dark mode, data saver and auto-sync (the extra tiles that can be added in Edit). */
    private fun readExtras() {
        locationOn = try {
            Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.LOCATION_MODE, 0) != 0
        } catch (_: Throwable) { false }
        nfcOn = try { NfcAdapter.getDefaultAdapter(ctx)?.isEnabled == true } catch (_: Throwable) { false }
        darkOn = try {
            ctx.getSystemService(UiModeManager::class.java)?.nightMode == UiModeManager.MODE_NIGHT_YES
        } catch (_: Throwable) { false }
        saverOn = try {
            cm.restrictBackgroundStatus != ConnectivityManager.RESTRICT_BACKGROUND_STATUS_DISABLED
        } catch (_: Throwable) { false }
        syncOn = try { ContentResolver.getMasterSyncAutomatically() } catch (_: Throwable) { false }
    }

    private fun readAirplane() {
        airplane = try {
            Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        } catch (_: Exception) {
            false
        }
    }

    private fun readBluetooth() {
        bluetooth = try {
            ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        } catch (_: Exception) {
            false
        }
    }

    private fun readVolume() {
        // while the finger is on the slider (or just left it) the slider is the truth, not the system broadcast
        if (volDragging || System.currentTimeMillis() - lastVolSet < 500) return
        val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (mx > 0) volume = audio.getStreamVolume(AudioManager.STREAM_MUSIC) / mx.toFloat()
    }

    /* ---------- opening system screens ---------- */
    private fun launch(intent: Intent) {
        try {
            val a = activity
            if (a != null) a.startActivity(intent)
            else ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onLaunched()
        } catch (_: Exception) {
            say("This isn’t available on your device.", true)
        }
    }

    private fun openSettings(action: String) = launch(Intent(action))

    /** Like [launch] but tells the caller whether the screen could be opened (no message is shown). */
    private fun tryLaunch(intent: Intent): Boolean = try {
        val a = activity
        if (a != null) a.startActivity(intent)
        else ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        onLaunched()
        true
    } catch (_: Exception) {
        false
    }

    /* ---------- toggles: real switches through Shizuku, system screen as a fallback ---------- */

    private fun put(ns: String, key: String, value: String) =
        "cmd settings put $ns $key $value || settings put $ns $key $value"

    /**
     * Flips a switch with a shell command. The button changes at once; if the command fails the
     * old state comes back. Without Shizuku the [fallback] (the matching system screen) runs.
     */
    private fun toggleVia(
        cur: Boolean, set: (Boolean) -> Unit, label: String,
        cmdOn: String, cmdOff: String, fallback: () -> Unit
    ) {
        if (!Shell.ready) {
            fallback()
            return
        }
        val want = !cur
        set(want)
        say("$label is ${if (want) "on" else "off"}")
        scope.launch {
            val (code, _) = Shell.exec(if (want) cmdOn else cmdOff)
            if (code != 0) {
                set(cur)
                say("Couldn’t change $label", true)
            }
            delay(800)
            refresh()
        }
    }

    fun tapAirplane() = toggleVia(
        airplane, { airplane = it }, "airplane mode",
        "cmd connectivity airplane-mode enable || (settings put global airplane_mode_on 1; am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true)",
        "cmd connectivity airplane-mode disable || (settings put global airplane_mode_on 0; am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false)"
    ) { openSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }

    fun tapWifi() = toggleVia(
        wifiOn, { wifiOn = it }, "Wi-Fi", "svc wifi enable", "svc wifi disable"
    ) {
        openSettings(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS)
    }

    /**
     * Mobile data. The button changes at once and the answer of the system is ignored while the change is on its
     * way. Then the real state is checked; if it did not change, the next way of switching is tried
     * (svc -> cmd phone -> settings). The button only goes back when none of them worked.
     */
    fun tapCell() {
        if (!Shell.ready) {
            openSettings(Settings.ACTION_DATA_ROAMING_SETTINGS)
            return
        }
        val want = !dataOn
        dataOn = want
        dataHoldUntil = System.currentTimeMillis() + 15_000
        say("Mobile data is ${if (want) "on" else "off"}")
        scope.launch {
            val word = if (want) "enable" else "disable"
            val tries = listOf(
                "svc data $word",
                "cmd phone data $word",
                put("global", "mobile_data", if (want) "1" else "0")
            )
            var ok = false
            for (c in tries) {
                Shell.exec(c)
                if (waitData(want)) { ok = true; break }
            }
            dataHoldUntil = 0L
            dataOn = realDataState()
            if (!ok) say("Couldn’t change mobile data", true)
            delay(600)
            if (System.currentTimeMillis() >= dataHoldUntil) dataOn = realDataState()
        }
    }

    /** Waits up to about 2.5 seconds until mobile data really has the wanted state. */
    private suspend fun waitData(want: Boolean): Boolean {
        repeat(10) {
            delay(250)
            if (realDataState() == want) return true
        }
        return false
    }

    fun tapBluetooth() = toggleVia(
        bluetooth, { bluetooth = it }, "Bluetooth",
        "cmd bluetooth_manager enable || svc bluetooth enable",
        "cmd bluetooth_manager disable || svc bluetooth disable"
    ) { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }

    /** Hotspot: depends on the ROM. If the shell command is refused, the tethering screen opens. */
    fun tapHotspot() {
        if (!Shell.ready) {
            openSettings(Settings.ACTION_WIRELESS_SETTINGS)
            return
        }
        val want = !hotspot
        hotspot = want
        scope.launch {
            val (code, _) = Shell.exec(
                if (want) "cmd connectivity start-tethering wifi" else "cmd connectivity stop-tethering wifi"
            )
            if (code != 0) {
                hotspot = !want
                openSettings(Settings.ACTION_WIRELESS_SETTINGS)
            }
        }
    }

    fun tapInternet() = openSettings(
        if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
    )

    /**
     * Tap and hold on Wi-Fi or Mobile data: the small floating "Internet" panel of Android (Wi-Fi networks and
     * mobile data in one bottom sheet over the app you are in), not the full Settings app. Settings > Behavior
     * can switch this to the full Wi-Fi / network settings.
     */
    fun longPressInternet() {
        val full = prefs.getInt("long_press", 0) == 1
        if (!full && Build.VERSION.SDK_INT >= 29) {
            if (tryLaunch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))) return
        }
        openSettings(Settings.ACTION_WIRELESS_SETTINGS)
    }

    fun tapMirror() = openSettings(Settings.ACTION_CAST_SETTINGS)

    /* extra tiles: real switch through Shizuku, the matching system screen otherwise */
    fun tapLocation() = toggleVia(
        locationOn, { locationOn = it }, "Location",
        "cmd location set-location-enabled true || settings put secure location_mode 3",
        "cmd location set-location-enabled false || settings put secure location_mode 0"
    ) { openSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS) }

    fun tapNfc() = toggleVia(
        nfcOn, { nfcOn = it }, "NFC", "svc nfc enable", "svc nfc disable"
    ) { openSettings(Settings.ACTION_NFC_SETTINGS) }

    fun tapDark() = toggleVia(
        darkOn, { darkOn = it }, "Dark mode", "cmd uimode night yes", "cmd uimode night no"
    ) { openSettings(Settings.ACTION_DISPLAY_SETTINGS) }

    fun tapDataSaver() = toggleVia(
        saverOn, { saverOn = it }, "Data saver",
        "cmd netpolicy set restrict-background true", "cmd netpolicy set restrict-background false"
    ) { launch(Intent("android.settings.DATA_USAGE_SETTINGS")) }

    /** Auto-sync works without Shizuku (WRITE_SYNC_SETTINGS); the sync screen opens if the system refuses. */
    fun tapSync() {
        val want = !syncOn
        try {
            ContentResolver.setMasterSyncAutomatically(want)
            syncOn = want
            say("Auto-sync is ${if (want) "on" else "off"}")
        } catch (_: Exception) {
            openSettings(Settings.ACTION_SYNC_SETTINGS)
        }
    }

    fun openSystemSettings() = openSettings(Settings.ACTION_SETTINGS)
    fun tapAirplay() = openSettings(
        if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_VOLUME else Settings.ACTION_CAST_SETTINGS
    )

    fun share() {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Aero Control Center")
        launch(Intent.createChooser(i, null))
    }

    fun openCamera() = launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))

    /** Battery saver: opens the system battery saver screen. */
    fun tapBatterySaver() = openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS)

    /** Screenshot: needs Shizuku (sends the screenshot key after the panel has closed). */
    fun screenshot() {
        if (!Shell.ready) {
            say("Turn on Shizuku in Settings to take screenshots", true)
            return
        }
        onLaunched()
        scope.launch {
            delay(700)
            val (code, _) = Shell.exec("input keyevent 120")
            if (code != 0) say("Couldn’t take a screenshot", true)
        }
    }

    /** Bell button: mutes / restores the media volume. */
    private var volumeBeforeMute = 0.5f
    fun toggleMute() {
        if (volume > 0f) {
            volumeBeforeMute = volume
            changeVolume(0f)
            say("Silent mode on")
        } else {
            changeVolume(volumeBeforeMute.coerceAtLeast(0.2f))
            say("Silent mode off")
        }
    }

    fun refreshApp() {
        say("Refreshing…", true)
        refresh()
        scope.launch {
            delay(350)
            activity?.recreate()
        }
    }

    /* ---------- focus ---------- */
    fun toggleFocus() {
        if (Shell.ready) {
            val want = !focus
            focus = want
            scope.launch {
                val (code, _) = Shell.exec("cmd notification set_dnd ${if (want) "on" else "off"}")
                if (code != 0) {
                    focus = !want
                    say("Couldn’t change Do Not Disturb", true)
                }
                delay(600)
                readZen()
            }
            return
        }
        val nm = notifMgr
        if (nm != null && hasDndAccess()) {
            val want = !focus
            focus = want
            nm.setInterruptionFilter(
                if (want) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            say(if (want) "Focus on" else "Focus off", true)
            return
        }
        say("Allow “Do Not Disturb access” to use Focus", true)
        openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
    }

    /* ---------- orientation lock ---------- */
    fun toggleLock() {
        if (Shell.ready) {
            val want = !locked
            locked = want
            scope.launch {
                val (code, _) = Shell.exec(put("system", "accelerometer_rotation", if (want) "0" else "1"))
                if (code != 0) {
                    locked = !want
                    say("Couldn’t change rotation lock", true)
                }
            }
            return
        }
        if (canWriteSettings()) {
            val want = !locked
            locked = want
            try {
                Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (want) 0 else 1)
            } catch (_: Exception) {
                locked = !want
                say("Couldn’t change rotation lock", true)
            }
            return
        }
        val a = activity
        if (a == null) {
            say("Allow “Modify system settings” (or turn on Shizuku) in Settings to lock rotation", true)
            return
        }
        locked = !locked
        a.requestedOrientation =
            if (locked) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        say(if (locked) "Orientation locked" else "Orientation lock off")
    }

    /* ---------- flashlight ---------- */
    fun toggleTorch() {
        val id = torchId
        if (id == null) {
            say("This device has no flashlight.")
            return
        }
        try {
            camMgr.setTorchMode(id, !torch)
        } catch (_: Exception) {
            say("Flashlight isn’t available right now.")
        }
    }

    /* ---------- sliders ---------- */
    private fun systemBrightness(): Float = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (_: Exception) {
        0.5f
    }

    private fun applyBrightness() {
        activity?.window?.let { w ->
            val lp = w.attributes
            lp.screenBrightness = brightness.coerceIn(0.02f, 1f)
            w.attributes = lp
        }
    }

    /*
     * Smooth sliders. A slider move only changes a number and drops it into a "latest value wins" channel; a
     * background worker writes it. Nothing waits for the system, and old values are skipped instead of queued.
     * Brightness: written straight into the system settings (no shell process per move).
     */
    @Volatile private var writeOk = canWriteSettings()
    @Volatile private var autoBrightOff = false
    private var brightDragging = false
    private var volDragging = false
    private var lastVolSet = 0L
    private var lastVolIdx = -1
    private var volMax = 0

    private val brightCh = Channel<Int>(Channel.CONFLATED)
    private val volCh = Channel<Int>(Channel.CONFLATED)
    private var brightJob: Job? = null
    private var volJob: Job? = null

    private fun startWorkers() {
        if (brightJob?.isActive != true) brightJob = scope.launch(Dispatchers.IO) {
            for (v in brightCh) writeBrightness(v)
        }
        if (volJob?.isActive != true) volJob = scope.launch(Dispatchers.IO) {
            for (i in volCh) {
                try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, i, 0) } catch (_: Exception) {}
            }
        }
    }

    private fun stopWorkers() {
        brightJob?.cancel(); brightJob = null
        volJob?.cancel(); volJob = null
    }

    private suspend fun writeBrightness(v: Int) {
        if (writeOk) {
            try {
                val cr = ctx.contentResolver
                if (!autoBrightOff) {
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    autoBrightOff = true
                }
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v)
                return
            } catch (_: Exception) {
                writeOk = false
            }
        }
        if (Shell.ready) {
            val pre = if (!autoBrightOff) {
                autoBrightOff = true
                "settings put system screen_brightness_mode 0; "
            } else ""
            Shell.exec(pre + "settings put system screen_brightness $v")
        }
    }

    /** Finger down on the brightness slider. */
    fun brightnessStart() {
        brightDragging = true
        autoBrightOff = false
    }

    fun brightnessEnd() {
        brightDragging = false
        lastBrightSet = System.currentTimeMillis()
    }

    /** With Shizuku or "Modify system settings": the real screen brightness of the phone. Without: only this app's window. */
    fun changeBrightness(p: Float) {
        brightness = p.coerceIn(0f, 1f)
        if (Shell.ready || writeOk) {
            lastBrightSet = System.currentTimeMillis()
            brightCh.trySend((brightness * 255f).roundToInt().coerceIn(1, 255))
            return
        }
        applyBrightness()
        prefs.edit().putFloat("brightness", brightness).apply()
    }

    fun volumeStart() {
        volDragging = true
        lastVolIdx = -1
    }

    fun volumeEnd() {
        volDragging = false
        lastVolSet = System.currentTimeMillis()
    }

    /** Real media volume of the phone. Only talks to the system when the step really changes. */
    fun changeVolume(p: Float) {
        val v = p.coerceIn(0f, 1f)
        volume = v
        if (volMax <= 0) volMax = try { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC) } catch (_: Exception) { 0 }
        val mx = volMax
        if (mx <= 0) return
        val idx = (v * mx).roundToInt().coerceIn(0, mx)
        if (idx == lastVolIdx) return
        lastVolIdx = idx
        lastVolSet = System.currentTimeMillis()
        volCh.trySend(idx)
    }

    /* ---------- QR scanner ---------- */
    fun scanQr() {
        try {
            val options = GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build()
            GmsBarcodeScanning.getClient(ctx, options).startScan()
                .addOnSuccessListener { b ->
                    val v = b.rawValue ?: ""
                    if (activity != null) {
                        qrResult = v
                    } else if (v.startsWith("http://", true) || v.startsWith("https://", true)) {
                        openQrLink(v)
                    } else {
                        copy(v)
                        Toast.makeText(ctx, "Copied: $v", Toast.LENGTH_LONG).show()
                    }
                }
                .addOnFailureListener { say("The code scanner needs Google Play services.", true) }
        } catch (_: Exception) {
            say("The code scanner needs Google Play services.", true)
        }
    }

    fun openQrLink(text: String) {
        if (text.startsWith("http://", true) || text.startsWith("https://", true)) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(text)))
        }
    }

    fun copy(text: String) {
        try {
            ctx.getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("Aero Control Center", text))
            say("Copied", true)
        } catch (_: Exception) {
        }
    }

    /* ---------- timer ---------- */
    fun timerAdjust(d: Int) {
        if (timerRunning) return
        timerMin = (timerMin + d).coerceIn(1, 180)
        prefs.edit().putInt("timerMin", timerMin).apply()
    }

    fun timerToggle() {
        if (timerRunning) {
            timerEnd = 0L
        } else {
            timerNow = System.currentTimeMillis()
            timerEnd = timerNow + timerMin * 60_000L
        }
        prefs.edit().putLong("timerEnd", timerEnd).apply()
        if (timerEnd > 0L) TimerReceiver.schedule(ctx, timerEnd) else TimerReceiver.cancel(ctx)
    }

    fun tickTimer() {
        if (!timerRunning) return
        timerNow = System.currentTimeMillis()
        if (timerNow >= timerEnd) finishTimer()
    }

    private fun finishTimer() {
        // if the background alarm already rang (prefs were cleared by it), do not ring twice
        val alreadyRang = prefs.getLong("timerEnd", 0L) == 0L
        timerEnd = 0L
        prefs.edit().putLong("timerEnd", 0L).apply()
        TimerReceiver.cancel(ctx)
        if (alreadyRang) return
        say("Timer finished", true)
        vibrate()
        scope.launch {
            try {
                val tg = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                repeat(3) {
                    tg.startTone(ToneGenerator.TONE_PROP_BEEP, 250)
                    delay(450)
                }
                tg.release()
            } catch (_: Exception) {
            }
        }
    }

    fun timerText(): String {
        val ms = if (timerRunning) timerEnd - timerNow else timerMin * 60_000L
        val s = max(0, ceil(ms / 1000.0).toInt())
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun vibrate() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200), -1))
        } catch (_: Exception) {
        }
    }

    /* ---------- now playing ---------- */

    /* Music of any other app: Android gives the media sessions to apps that have Notification access. */

    fun hasNotifAccess(): Boolean = MediaListener.hasAccess(ctx)

    private var sessionMgr: MediaSessionManager? = null
    private var extCtl: MediaController? = null
    private var sessionsOn = false

    private val extCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = syncMedia()
        override fun onMetadataChanged(metadata: MediaMetadata?) = syncMedia()
        override fun onSessionDestroyed() {
            pickSession(sessionMgr?.let { safeSessions(it) })
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pickSession(list)
    }

    private fun safeSessions(m: MediaSessionManager): List<MediaController>? = try {
        m.getActiveSessions(MediaListener.component(ctx))
    } catch (_: SecurityException) {
        null
    } catch (_: Exception) {
        null
    }

    private fun registerSessions() {
        if (sessionsOn || !hasNotifAccess()) return
        try {
            val m = ctx.getSystemService(MediaSessionManager::class.java) ?: return
            m.addOnActiveSessionsChangedListener(sessionsListener, MediaListener.component(ctx))
            sessionMgr = m
            sessionsOn = true
            pickSession(safeSessions(m))
        } catch (_: Exception) {
        }
    }

    private fun unregisterSessions() {
        try { sessionMgr?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        try { extCtl?.unregisterCallback(extCb) } catch (_: Exception) {}
        extCtl = null
        sessionMgr = null
        sessionsOn = false
    }

    /** Prefer the session that is playing right now, otherwise the first one. */
    private fun pickSession(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        val old = extCtl
        if (old?.sessionToken != best?.sessionToken) {
            try { old?.unregisterCallback(extCb) } catch (_: Exception) {}
            extCtl = best
            try { best?.registerCallback(extCb) } catch (_: Exception) {}
        }
        syncMedia()
    }

    /** Puts either the other app's music or the local player on the tile. */
    private fun syncMedia() {
        val c = extCtl
        if (c != null) {
            val md = try { c.metadata } catch (_: Exception) { null }
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            nowPlaying = when {
                !title.isNullOrBlank() && !artist.isNullOrBlank() -> "$title – $artist"
                !title.isNullOrBlank() -> title
                else -> "Not Playing"
            }
            val st = try { c.playbackState?.state } catch (_: Exception) { null }
            playing = st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING
        } else {
            nowPlaying = localTitle
            playing = localPlaying
        }
    }

    /* Your own audio files, picked inside the app. */
    private var player: MediaPlayer? = null
    private var tracks: List<Pair<String, Uri>> = emptyList()
    private var index = -1

    private fun displayName(uri: Uri): String {
        val name = try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
        return (name ?: "Track").substringBeforeLast('.')
    }

    fun setTracks(uris: List<Uri>) {
        if (uris.isEmpty()) return
        tracks = uris.map { displayName(it) to it }
        load(0)
    }

    private fun releasePlayer() {
        try { player?.release() } catch (_: Exception) {}
        player = null
        localPlaying = false
        syncMedia()
    }

    private fun load(i: Int) {
        if (tracks.isEmpty()) return
        index = (i + tracks.size) % tracks.size
        val (name, uri) = tracks[index]
        releasePlayer()
        localTitle = name
        syncMedia()
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(ctx, uri)
            mp.setOnPreparedListener { it.start(); localPlaying = true; syncMedia() }
            mp.setOnCompletionListener { if (tracks.size > 1) load(index + 1) else { localPlaying = false; syncMedia() } }
            mp.setOnErrorListener { _, _, _ ->
                localPlaying = false
                syncMedia()
                say("Can’t play this file", true)
                true
            }
            mp.prepareAsync()
            player = mp
        } catch (_: Exception) {
            say("Can’t play this file", true)
        }
    }

    fun togglePlay() {
        val c = extCtl
        if (c != null) {
            try {
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                else c.transportControls.play()
            } catch (_: Exception) {
            }
            return
        }
        val mp = player
        if (mp == null || tracks.isEmpty()) {
            onPickAudio()
            return
        }
        try {
            if (mp.isPlaying) {
                mp.pause(); localPlaying = false
            } else {
                mp.start(); localPlaying = true
            }
            syncMedia()
        } catch (_: Exception) {
        }
    }

    fun prev() {
        val c = extCtl
        if (c != null) {
            try { c.transportControls.skipToPrevious() } catch (_: Exception) {}
            return
        }
        val mp = player
        if (mp == null || tracks.isEmpty()) {
            say("Tap play to choose music"); return
        }
        try {
            if (mp.currentPosition > 3000) mp.seekTo(0) else load(index - 1)
        } catch (_: Exception) {
        }
    }

    fun next() {
        val c = extCtl
        if (c != null) {
            try { c.transportControls.skipToNext() } catch (_: Exception) {}
            return
        }
        if (tracks.isEmpty()) {
            say("Tap play to choose music"); return
        }
        load(index + 1)
    }
}
