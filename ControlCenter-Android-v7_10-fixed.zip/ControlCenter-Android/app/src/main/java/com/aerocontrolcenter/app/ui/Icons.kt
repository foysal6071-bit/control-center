package com.aerocontrolcenter.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp

/** Tiny vector-icon model that reuses the SVG path data of the web version (24 x 24 view box). */
sealed interface El {
    val fill: Boolean
    val sw: Float
    val color: Color?
    val a: Float get() = 1f
}

data class Pa(
    val d: String,
    override val fill: Boolean = false,
    override val sw: Float = 2f,
    override val color: Color? = null,
    override val a: Float = 1f
) : El

data class Ci(
    val cx: Float, val cy: Float, val r: Float,
    override val fill: Boolean = true,
    override val sw: Float = 2f,
    override val color: Color? = null,
    override val a: Float = 1f
) : El

data class Re(
    val x: Float, val y: Float, val w: Float, val h: Float, val rx: Float,
    override val fill: Boolean = true,
    override val sw: Float = 2f,
    override val color: Color? = null,
    override val a: Float = 1f
) : El

@Composable
fun SvgIcon(els: List<El>, dp: Dp, tint: Color, modifier: Modifier = Modifier) {
    val paths = remember(els) {
        els.map { if (it is Pa) PathParser().parsePathString(it.d).toPath() else null }
    }
    Canvas(modifier.size(dp)) {
        val k = this.size.minDimension / 24f
        withTransform({ scale(k, k, Offset.Zero) }) {
            els.forEachIndexed { i, e ->
                val c0 = e.color ?: tint
                val c = if (e.a < 1f) c0.copy(alpha = c0.alpha * e.a) else c0
                val style: DrawStyle =
                    if (e.fill) Fill else Stroke(width = e.sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
                when (e) {
                    is Pa -> drawPath(paths[i]!!, c, style = style)
                    is Ci -> drawCircle(c, radius = e.r, center = Offset(e.cx, e.cy), style = style)
                    is Re -> drawRoundRect(
                        c,
                        topLeft = Offset(e.x, e.y),
                        size = Size(e.w, e.h),
                        cornerRadius = CornerRadius(e.rx, e.rx),
                        style = style
                    )
                }
            }
        }
    }
}

@Composable
fun BatteryIcon(level: Float, charging: Boolean, w: Dp, h: Dp) {
    val bolt = remember { PathParser().parsePathString("M12.4 2.2 8.2 6.6h2.6l-.9 3.2 4.3-4.6h-2.6z").toPath() }
    Canvas(Modifier.size(w, h)) {
        val k = this.size.width / 26f
        withTransform({ scale(k, k, Offset.Zero) }) {
            drawRoundRect(
                Color.White.copy(alpha = 0.5f), Offset(0.6f, 0.6f), Size(21.6f, 10.8f),
                CornerRadius(3.4f, 3.4f), style = Stroke(width = 1f)
            )
            val l = level.coerceIn(0f, 1f)
            val col = when {
                charging -> Color(0xFF34C759)
                l <= 0.2f -> Color(0xFFFF453A)
                else -> Color.White
            }
            drawRoundRect(col, Offset(2f, 2f), Size(maxOf(1.6f, 19.6f * l), 8f), CornerRadius(2f, 2f))
            if (charging) drawPath(bolt, Color(0xFF20242C))
            drawRoundRect(
                Color.White.copy(alpha = 0.5f), Offset(23.4f, 3.8f), Size(2f, 4.4f), CornerRadius(1f, 1f)
            )
        }
    }
}

object Ic {
    private val CUT_CALC = Color(0xFF9A5560)
    private val CUT_CAM = Color(0xFF3A76D6)

    /** Hexagon gear (MIUI settings button) and square with a pencil (MIUI edit button). */
    val hex = listOf<El>(
        Pa("M12 2.8l7.6 4.4v9.6L12 21.2l-7.6-4.4V7.2z"),
        Ci(12f, 12f, 3.2f, fill = false)
    )
    val pencil = listOf<El>(
        Pa("M11 4H6.5A2.5 2.5 0 0 0 4 6.5v11A2.5 2.5 0 0 0 6.5 20h11a2.5 2.5 0 0 0 2.5-2.5V13"),
        Pa("M18.3 3.7l2 2L12 14l-3 1 1-3z")
    )
    val plus = listOf<El>(Pa("M12 4v16M4 12h16"))
    val power = listOf<El>(Pa("M12 3v8M6.8 6.6a8 8 0 1 0 10.4 0"))
    val close = listOf<El>(Pa("M6 6l12 12M18 6L6 18"))
    val gear = listOf<El>(
        Ci(12f, 12f, 3.2f, fill = false),
        Ci(12f, 12f, 6.8f, fill = false),
        Pa("M12 2.6v3M12 18.4v3M2.6 12h3M18.4 12h3M5.4 5.4l2.1 2.1M16.5 16.5l2.1 2.1M18.6 5.4l-2.1 2.1M7.5 16.5l-2.1 2.1")
    )

    // ---- Settings / status-bar icons (replace the old emoji) ----
    val plug = listOf<El>(Pa("M9 2v6M15 2v6M6 8h12v4a6 6 0 0 1-12 0zM12 18v4"))
    val pull = listOf<El>(Pa("M12 4v12M7 11l5 5 5-5M5 20h14"))
    /** Control Center: two toggle switches, one on (knob right, filled) and one off (knob left). */
    val controlCenter = listOf<El>(
        Re(3f, 4.5f, 18f, 7f, 3.5f, fill = true, a = 0.3f),
        Re(3f, 4.5f, 18f, 7f, 3.5f, fill = false, sw = 1.8f),
        Ci(17.5f, 8f, 2.3f),
        Re(3f, 13.5f, 18f, 7f, 3.5f, fill = false, sw = 1.8f),
        Ci(6.5f, 17f, 2.3f)
    )
    val palette = listOf<El>(
        Pa("M12 3a9 9 0 1 0 0 18c1.4 0 2-1 1.6-2.2-.4-1.2.3-2.3 1.6-2.3H17a4 4 0 0 0 4-4C21 6.9 17 3 12 3z"),
        Ci(7.5f, 11f, 1.1f), Ci(10.5f, 7f, 1.1f), Ci(15f, 7.5f, 1.1f)
    )
    val blur = listOf<El>(Pa("M12 3s6 6.2 6 10.5a6 6 0 0 1-12 0C6 9.2 12 3 12 3z"))
    val tiles = listOf<El>(
        Re(4f, 4f, 7f, 7f, 1.6f, fill = false), Re(13f, 4f, 7f, 7f, 1.6f, fill = false),
        Re(4f, 13f, 7f, 7f, 1.6f, fill = false), Re(13f, 13f, 7f, 7f, 1.6f, fill = false)
    )
    val sliders = listOf<El>(
        Pa("M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"),
        Ci(15f, 6f, 2f, fill = false), Ci(9f, 12f, 2f, fill = false), Ci(17f, 18f, 2f, fill = false)
    )
    val shield = listOf<El>(Pa("M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6zM9 12l2.2 2.2L15.5 10"))
    val info = listOf<El>(Ci(12f, 12f, 9f, fill = false), Pa("M12 11v6"), Ci(12f, 7.5f, 1.2f))
    val check = listOf<El>(Pa("M5 12.5l4.5 4.5L19 7.5", sw = 2.6f))
    val chevronRight = listOf<El>(Pa("M9 5l7 7-7 7"))
    val triUp = listOf<El>(Pa("M12 5l7 11H5z", fill = true))
    val triDown = listOf<El>(Pa("M12 19L5 8h14z", fill = true))

    val airplane = listOf<El>(
        Pa("M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z", fill = true)
    )
    val share = listOf<El>(
        Ci(12f, 12f, 3.2f, a = 0.3f),
        Ci(12f, 12f, 1.8f),
        Pa("M8.4 15.6a5.2 5.2 0 1 1 7.2 0M5.4 18.6a9.4 9.4 0 1 1 13.2 0", sw = 1.9f)
    )
    val wifi = listOf<El>(
        Pa("M12 20.4 2.4 9.6a14 14 0 0 1 19.2 0z", fill = true, a = 0.3f),
        Pa("M2.6 9.4a14 14 0 0 1 18.8 0M5.9 12.9a9.4 9.4 0 0 1 12.2 0M9.1 16.2a4.8 4.8 0 0 1 5.8 0", sw = 1.9f),
        Ci(12f, 19.4f, 1.5f)
    )
    val cell = listOf<El>(
        Re(3f, 15f, 3.4f, 5f, 1.2f, a = 0.35f),
        Re(8.2f, 11f, 3.4f, 9f, 1.2f, a = 0.55f),
        Re(13.4f, 7f, 3.4f, 13f, 1.2f, a = 0.8f),
        Re(18.6f, 3f, 3.4f, 17f, 1.2f)
    )
    val bluetooth = listOf<El>(
        Pa("M12 3v18l5.2-4.6-4.6-4.4 4.6-4.4z", fill = true, a = 0.3f),
        Pa("M6.5 7.6 17.2 16.4 12 21V3l5.2 4.6L6.5 16.4", sw = 1.9f)
    )
    val hotspot = listOf<El>(
        Pa("M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1")
    )
    val internet = listOf<El>(
        Ci(12f, 12f, 8.6f, a = 0.25f),
        Ci(12f, 12f, 8.6f, fill = false, sw = 1.8f),
        Pa("M3.6 12h16.8M12 3.4c3 2.6 3 14.6 0 17.2M12 3.4c-3 2.6-3 14.6 0 17.2", sw = 1.6f)
    )

    val music = listOf<El>(
        Pa("M9 17.5V6l10-2v11.5", sw = 1.9f),
        Ci(6.8f, 17.8f, 2.7f), Ci(16.8f, 15.8f, 2.7f),
        Pa("M9 6l10-2v3.5L9 9.5z", fill = true, a = 0.35f)
    )
    val airplay = listOf<El>(
        Pa("M6 17H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-1"),
        Pa("M12 14l5.5 6.5h-11z", fill = true)
    )
    val prev = listOf<El>(Pa("M12.5 6v12l-8-6zM21 6v12l-8-6z", fill = true))
    val next = listOf<El>(Pa("M11.5 6v12l8-6zM3 6v12l8-6z", fill = true))
    val play = listOf<El>(Pa("M7 4v16l13-8z", fill = true))
    val pause = listOf<El>(
        Re(6f, 4f, 4.2f, 16f, 1.2f),
        Re(13.8f, 4f, 4.2f, 16f, 1.2f)
    )

    val lock = listOf<El>(
        Pa("M20 12a8 8 0 1 1-2.4-5.7M18 3.2v3.8h-3.8", sw = 1.9f),
        Re(8.8f, 11.2f, 6.4f, 5.2f, 1.4f, a = 0.35f),
        Re(8.8f, 11.2f, 6.4f, 5.2f, 1.4f, fill = false, sw = 1.6f),
        Pa("M10.3 11.2V10a1.7 1.7 0 0 1 3.4 0v1.2", sw = 1.6f)
    )
    val mirror = listOf<El>(
        Re(3f, 8.5f, 12.5f, 10f, 2.4f, a = 0.3f),
        Re(3f, 8.5f, 12.5f, 10f, 2.4f, fill = false, sw = 1.8f),
        Re(8.5f, 5f, 12.5f, 10f, 2.4f, fill = false, sw = 1.8f)
    )
    val moon = listOf<El>(
        Pa("M20 14.6A8.6 8.6 0 1 1 9.4 4a7.1 7.1 0 0 0 10.6 10.6z", fill = true),
        Ci(17.2f, 5.6f, 1.1f), Ci(20.2f, 9f, 0.8f)
    )
    val chevrons = listOf<El>(Pa("M8 9l4-4 4 4M8 15l4 4 4-4"))

    val brightness = listOf<El>(
        Ci(12f, 12f, 5.6f, a = 0.3f),
        Ci(12f, 12f, 3.2f),
        Pa("M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7", sw = 1.9f)
    )

    /** tier 0 = muted, 1 = one wave, 2 = two waves */
    fun volume(tier: Int): List<El> = buildList<El> {
        add(Pa("M3 9.5v5h4l5 4v-13l-5 4z", fill = true))
        if (tier >= 1) add(Pa("M15.6 9a4 4 0 0 1 0 6"))
        if (tier >= 2) add(Pa("M18.2 6.4a7.6 7.6 0 0 1 0 11.2"))
        if (tier == 0) add(Pa("M15.5 9.5l5 5M20.5 9.5l-5 5"))
    }

    val flash = listOf<El>(
        Pa("M8 2.5h8v3.8L14.5 8v12a1.6 1.6 0 0 1-1.6 1.6h-1.8A1.6 1.6 0 0 1 9.5 20V8L8 6.3z", fill = true),
        Re(11f, 10.6f, 2f, 3.6f, 1f, color = Color(0x993C282D)),
        Pa("M4.5 4.5 3 3M19.5 4.5 21 3M20 9.5h2M2 9.5h2", sw = 1.6f, a = 0.7f)
    )
    val timer = listOf<El>(
        Ci(12f, 13.4f, 7.8f, a = 0.25f),
        Ci(12f, 13.4f, 7.8f, fill = false, sw = 1.9f),
        Pa("M9.6 2.8h4.8M12 13.4V9M18.4 6.4l1.5-1.5", sw = 1.9f)
    )
    val calc = listOf<El>(
        Re(4.2f, 2.5f, 15.6f, 19f, 3.2f, color = Color.White),
        Re(7f, 5f, 10f, 4f, 1.2f, color = CUT_CALC),
        Re(7f, 11f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(10.7f, 11f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(14.4f, 11f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(7f, 14.7f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(10.7f, 14.7f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(14.4f, 14.7f, 2.6f, 6f, 0.8f, color = CUT_CALC),
        Re(7f, 18.4f, 6.3f, 2.4f, 0.8f, color = CUT_CALC)
    )
    val camera = listOf<El>(
        Pa(
            "M4 7.5h3l1.5-2.5h7L17 7.5h3a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H4A1.5 1.5 0 0 1 2.5 18V9A1.5 1.5 0 0 1 4 7.5z",
            fill = true, color = Color.White
        ),
        Ci(12f, 13.2f, 3.6f, color = CUT_CAM)
    )
    val qr = listOf<El>(
        Pa("M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2", sw = 1.9f),
        Re(8f, 8f, 3f, 3f, 0.8f), Re(13f, 8f, 3f, 3f, 0.8f), Re(8f, 13f, 3f, 3f, 0.8f),
        Ci(14.5f, 14.5f, 1.4f, a = 0.7f)
    )

    /* ---- icons for the tile-style layout ---- */
    val cellOff = listOf<El>(
        Re(3f, 15f, 3.2f, 5f, 1f),
        Re(8.4f, 11f, 3.2f, 9f, 1f),
        Re(13.8f, 7f, 3.2f, 13f, 1f),
        Re(19.2f, 3f, 3.2f, 17f, 1f),
        Pa("M3 3l18 18", sw = 2.4f)
    )
    val bell = listOf<El>(
        Pa("M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5z", fill = true, a = 0.3f),
        Pa("M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5zM10 20.5a2 2 0 0 0 4 0", sw = 1.9f)
    )
    val bellOff = listOf<El>(
        Pa("M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5z", fill = true, a = 0.3f),
        Pa("M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5zM10 20.5a2 2 0 0 0 4 0M3.5 3.5l17 17", sw = 1.9f)
    )
    val boltRing = listOf<El>(
        Ci(12f, 12f, 9.6f, a = 0.25f),
        Ci(12f, 12f, 9.6f, fill = false, sw = 1.8f),
        Pa("M13.2 5.8 8.2 12.8h3.4l-.8 5.4 5-7h-3.4z", fill = true)
    )
    val scissors = listOf<El>(
        Ci(6f, 6.4f, 2.7f, a = 0.3f), Ci(6f, 17.6f, 2.7f, a = 0.3f),
        Ci(6f, 6.4f, 2.7f, fill = false, sw = 1.8f), Ci(6f, 17.6f, 2.7f, fill = false, sw = 1.8f),
        Pa("M8 8.2 20 18M8 15.8 20 6", sw = 1.9f)
    )
    val video = listOf<El>(
        Re(3f, 6.5f, 13f, 11f, 2.8f, a = 0.3f),
        Re(3f, 6.5f, 13f, 11f, 2.8f, fill = false, sw = 1.9f),
        Pa("M16 10.6l5-3v8.8l-5-3z", fill = true)
    )
    val cast = listOf<El>(
        Pa("M3 8V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-5", sw = 1.9f),
        Pa("M3 12a9 9 0 0 1 9 9M3 16.5a4.5 4.5 0 0 1 4.5 4.5", sw = 1.9f),
        Ci(3.8f, 20.2f, 1.3f)
    )
    val calcMono = listOf<El>(
        Re(5f, 3f, 14f, 18f, 3f, fill = false),
        Pa("M8.5 7.5h7M8.5 12.5h.01M12 12.5h.01M15.5 12.5h.01M8.5 16.5h.01M12 16.5h.01M15.5 16.5h.01", sw = 2.2f)
    )

    val heart = listOf<El>(
        Pa("M12 20.6s-8.2-5-8.2-11.2A4.6 4.6 0 0 1 12 7a4.6 4.6 0 0 1 8.2 2.4c0 6.2-8.2 11.2-8.2 11.2z", fill = true)
    )
    val waves = listOf<El>(
        Ci(12f, 12f, 1.8f),
        Pa("M8.2 8.2a5.4 5.4 0 0 0 0 7.6M15.8 8.2a5.4 5.4 0 0 1 0 7.6M5.2 5.2a9.6 9.6 0 0 0 0 13.6M18.8 5.2a9.6 9.6 0 0 1 0 13.6")
    )
    val location = listOf<El>(
        Pa("M12 21s-6.6-5.6-6.6-11a6.6 6.6 0 0 1 13.2 0c0 5.4-6.6 11-6.6 11z", fill = true, a = 0.3f),
        Pa("M12 21s-6.6-5.6-6.6-11a6.6 6.6 0 0 1 13.2 0c0 5.4-6.6 11-6.6 11z", sw = 1.9f),
        Ci(12f, 10f, 2.4f)
    )
    val nfc = listOf<El>(
        Pa("M7 7.5a6 6 0 0 1 0 9M11 5a9.5 9.5 0 0 1 0 14M15 2.8a13 13 0 0 1 0 18.4")
    )
    val darkMode = listOf<El>(
        Ci(12f, 12f, 8.6f, fill = false, sw = 1.9f),
        Pa("M12 3.4a8.6 8.6 0 0 1 0 17.2z", fill = true)
    )
    val dataSaver = listOf<El>(
        Pa("M4 14a8 8 0 0 1 16 0z", fill = true, a = 0.3f),
        Pa("M4 14a8 8 0 0 1 16 0M12 14l4-4M5 20h14", sw = 1.9f)
    )
    val sync = listOf<El>(
        Pa("M20 12a8 8 0 0 0-14-5.3L4 9M4 4v5h5M4 12a8 8 0 0 0 14 5.3L20 15M20 20v-5h-5", sw = 1.9f),
        Ci(12f, 12f, 2.2f, a = 0.5f)
    )
}
