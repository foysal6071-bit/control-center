package com.aerocontrolcenter.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Brings the pull-down trigger back after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = i.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val p = c.getSharedPreferences("cc", Context.MODE_PRIVATE)
        // a timer that was running before the reboot: set its alarm again (or drop it if it is over)
        val end = p.getLong("timerEnd", 0L)
        if (end > System.currentTimeMillis()) TimerReceiver.schedule(c, end)
        else if (end > 0L) p.edit().putLong("timerEnd", 0L).apply()
        if (p.getBoolean("overlay_on", false) && p.getBoolean("boot_start", true) && Settings.canDrawOverlays(c)) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))
            } catch (_: Exception) {
            }
        }
        if (p.getBoolean("isl_on", false) && Settings.canDrawOverlays(c)) IslandService.start(c)
        if (p.getBoolean("cs_on", false) && Settings.canDrawOverlays(c)) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, StatusBarService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
