package com.aerocontrolcenter.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aerocontrolcenter.app.NotifStore
import com.aerocontrolcenter.app.StatusData

/** Colour of the icons and text: white on dark apps, near black on light apps (set from [StatusData.dark]). */
private val LocalInk = compositionLocalOf { Color.White }
private val LocalInkInverse = compositionLocalOf { Color.Black }
private val DARK_INK = Color(0xFF16181D)
private val SAVER = Color(0xFFF5A623)
private val GREEN = Color(0xFF34C759)
private val RED = Color(0xFFFF453A)

/**
 * The custom status bar: time and notification icons on the left; network speed, alarm, VoLTE, Wi-Fi, mobile
 * signal and a battery pill with the percentage on the right. Nothing is drawn until the phone's own bar is hidden.
 */
@Composable
fun StatusBarContent(d: StatusData) {
    if (!d.active) return

    // slow ease-in-out fade so the colour glides between white and dark instead of snapping
    val fade = tween<Color>(durationMillis = 300, easing = androidx.compose.animation.core.FastOutSlowInEasing)
    val ink by animateColorAsState(if (d.dark) DARK_INK else Color.White, animationSpec = fade, label = "ink")
    val inverse by animateColorAsState(if (d.dark) Color.White else Color.Black, animationSpec = fade, label = "inverse")
    // a faint soft shadow under white text keeps it crisp on bright wallpapers (dark ink needs none)
    val shade = androidx.compose.ui.graphics.Shadow(
        color = Color.Black.copy(alpha = if (d.dark) 0f else 0.35f),
        offset = Offset(0f, 1f), blurRadius = 3f
    )
    CompositionLocalProvider(LocalInk provides ink, LocalInkInverse provides inverse) {
    androidx.compose.material3.ProvideTextStyle(androidx.compose.ui.text.TextStyle(shadow = shade)) {
    val dim = ink.copy(alpha = 0.33f)
    Box(Modifier.fillMaxSize().background(if (d.black) Color.Black else Color.Transparent)) {
        Row(
            Modifier.fillMaxSize().padding(start = d.padStart.dp, end = d.padEnd.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            /* ---------- left: clock + notification icons ---------- */
            Text(d.time, color = ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
            if (d.showNotif) {
                val icons = NotifStore.statusIcons
                if (icons.isNotEmpty()) {
                    Spacer(Modifier.width(6.dp))
                    icons.take(3).forEach {
                        Image(
                            bitmap = it, contentDescription = null,
                            colorFilter = ColorFilter.tint(ink),
                            modifier = Modifier.padding(horizontal = 2.dp).size(15.dp)
                        )
                    }
                    if (icons.size > 3) Text("···", color = ink, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }

            Spacer(Modifier.weight(1f))

            /* ---------- right: status icons ---------- */
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (d.showSpeed) {
                    Column(Modifier.widthIn(min = 28.dp), horizontalAlignment = Alignment.End) {
                        Text(d.speed, color = ink, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp, maxLines = 1, softWrap = false)
                        Text(d.speedUnit, color = ink, fontSize = 8.sp, fontWeight = FontWeight.SemiBold, lineHeight = 9.sp, maxLines = 1, softWrap = false)
                    }
                }
                if (d.alarm) AlarmIcon()
                if (d.showVolte && d.volte && d.netType.isNotEmpty()) VolteBadge()
                if (d.wifiLevel >= 0) WifiIcon(d.wifiLevel)
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (d.netType.isNotEmpty()) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d.netType, color = ink, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp, maxLines = 1, softWrap = false)
                            Row {
                                SvgIcon(Ic.triUp, 6.dp, if (d.up) ink else dim)
                                SvgIcon(Ic.triDown, 6.dp, if (d.down) ink else dim)
                            }
                        }
                    }
                    SignalBars(d.signal)
                }
                BatteryPill(d.battery, d.charging, d.saver)
            }
        }
    }
    }
    }
}

/** Alarm clock: ring, two hands and the two bells. */
@Composable
private fun AlarmIcon() {
    val ink = LocalInk.current
    Canvas(Modifier.size(14.dp)) {
        val w = size.width
        val sw = w * 0.12f
        val c = Offset(w / 2f, w * 0.56f)
        val r = w * 0.34f
        drawCircle(ink, r, c, style = Stroke(sw))
        drawLine(ink, c, Offset(c.x, c.y - r * 0.6f), sw, StrokeCap.Round)
        drawLine(ink, c, Offset(c.x + r * 0.45f, c.y + r * 0.2f), sw, StrokeCap.Round)
        drawCircle(ink, w * 0.15f, Offset(w * 0.17f, w * 0.2f))
        drawCircle(ink, w * 0.15f, Offset(w * 0.83f, w * 0.2f))
    }
}

/** White "Vo LTE" badge. */
@Composable
private fun VolteBadge() {
    val ink = LocalInk.current
    val inverse = LocalInkInverse.current
    Box(
        Modifier.background(ink, RoundedCornerShape(3.dp)).padding(horizontal = 3.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Vo", color = inverse, fontSize = 6.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 6.sp, maxLines = 1)
            Text("LTE", color = inverse, fontSize = 6.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 6.sp, maxLines = 1)
        }
    }
}

/** Wi-Fi fan: a dot and three arcs, lit by signal level 0..4. */
@Composable
private fun WifiIcon(level: Int) {
    val ink = LocalInk.current
    val dim = ink.copy(alpha = 0.33f)
    Canvas(Modifier.size(16.dp)) {
        val w = size.width
        val sw = w * 0.11f
        val cx = w / 2f
        val cy = w * 0.9f
        val lit = (level * 3 + 3) / 4
        drawCircle(ink, w * 0.08f, Offset(cx, cy))
        for (i in 1..3) {
            val r = w * (0.22f * i + 0.05f)
            drawArc(
                color = if (i <= lit) ink else dim,
                startAngle = 225f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - r, cy - r), size = Size(r * 2f, r * 2f),
                style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
    }
}

/** Four bars that grow in height; the first [level] are lit. */
@Composable
private fun SignalBars(level: Int) {
    val ink = LocalInk.current
    val dim = ink.copy(alpha = 0.33f)
    Row(
        Modifier.height(13.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(1.5.dp)
    ) {
        for (i in 1..4) {
            Box(
                Modifier.width(3.dp).height((3f + i * 2.5f).dp)
                    .background(if (i <= level) ink else dim, RoundedCornerShape(1.dp))
            )
        }
    }
}

/** Battery pill with the percentage inside: green while charging, orange in battery saver, red when low. */
@Composable
private fun BatteryPill(level: Int, charging: Boolean, saver: Boolean) {
    val ink = LocalInk.current
    val inverse = LocalInkInverse.current
    val dim = ink.copy(alpha = 0.33f)
    val fill = when {
        charging -> GREEN
        saver -> SAVER
        level <= 15 -> RED
        else -> ink
    }
    val text = if (fill == ink) inverse else Color.White
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(24.dp).height(13.dp).clip(RoundedCornerShape(4.dp)).background(dim)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(level.coerceIn(0, 100) / 100f).background(fill))
            Text(
                level.toString(), color = text, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
                lineHeight = 10.sp, maxLines = 1, softWrap = false, modifier = Modifier.align(Alignment.Center)
            )
        }
        Box(Modifier.width(2.dp).height(5.dp).background(dim, RoundedCornerShape(topEnd = 1.dp, bottomEnd = 1.dp)))
    }
}
