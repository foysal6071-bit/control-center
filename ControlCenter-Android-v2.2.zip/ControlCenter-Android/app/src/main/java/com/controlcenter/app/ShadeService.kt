package com.controlcenter.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Pull-down helper. On many phones the system status bar sits above any overlay, so a swipe from the
 * very top opens the phone's own notification panel and never reaches our trigger strip. This service
 * notices that panel opening, closes it again and shows our Control Center instead.
 * It only looks at the name of the window that opened; it never reads the screen content.
 */
class ShadeService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var lastFire = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (!pkg.contains("systemui", ignoreCase = true)) return
        if (!looksLikeShade(e)) return
        // only when our pull-down is switched on and the phone is unlocked
        if (OverlayService.instance == null) return
        val kg = getSystemService(KeyguardManager::class.java)
        if (kg != null && kg.isKeyguardLocked) return

        val now = SystemClock.uptimeMillis()
        if (now - lastFire < 900) return
        lastFire = now

        closeStockShade()
        OverlayService.openNow()
    }

    private fun looksLikeShade(e: AccessibilityEvent): Boolean {
        val text = buildString {
            append(e.className ?: "")
            append(' ')
            e.text?.forEach { append(it).append(' ') }
            append(e.contentDescription ?: "")
        }.lowercase()
        return text.contains("notificationshade") || text.contains("notification shade") ||
            text.contains("quick settings") || text.contains("quicksettings") ||
            text.contains("shadewindow")
    }

    private fun closeStockShade() {
        try {
            if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
            else performGlobalAction(GLOBAL_ACTION_BACK)
        } catch (_: Exception) {
        }
        if (Shell.ready) scope.launch { Shell.exec("cmd statusbar collapse") }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
