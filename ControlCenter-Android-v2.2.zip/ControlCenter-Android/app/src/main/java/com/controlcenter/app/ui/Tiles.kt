package com.controlcenter.app.ui

import android.content.Context

/** The square tiles of the Control Center grid. The user chooses which ones are shown in Settings. */
object Tiles {
    /** The grid has room for 4 rows of 4 tiles. */
    const val MAX = 16

    data class Def(val id: String, val label: String, val defaultOn: Boolean)

    val all = listOf(
        Def("bluetooth", "Bluetooth", true),
        Def("airplane", "Airplane mode", true),
        Def("silent", "Silent mode", true),
        Def("torch", "Flashlight", true),
        Def("screenshot", "Screenshot", true),
        Def("battery", "Battery saver", true),
        Def("internet", "Internet panel", true),
        Def("rotation", "Orientation lock", true),
        Def("camera", "Camera", true),
        Def("cast", "Screen cast", true),
        Def("hotspot", "Hotspot", true),
        Def("qr", "Code scanner", true),
        Def("timer", "Timer", true),
        Def("focus", "Focus (Do Not Disturb)", true),
        Def("calc", "Calculator", true),
        Def("share", "Share", false),
        Def("output", "Sound output", false)
    )

    private fun prefs(c: Context) = c.getSharedPreferences("cc", Context.MODE_PRIVATE)

    fun isOn(c: Context, d: Def): Boolean = prefs(c).getBoolean("tile_${d.id}", d.defaultOn)

    fun setOn(c: Context, id: String, on: Boolean) {
        prefs(c).edit().putBoolean("tile_$id", on).apply()
    }

    /** Ids of the tiles to draw, in grid order (at most [MAX]). */
    fun enabled(c: Context): List<String> = all.filter { isOn(c, it) }.take(MAX).map { it.id }
}
