# Control Center (Kotlin + Jetpack Compose)

iOS-style Control Center as a native Android app. This is the Kotlin / Jetpack Compose
version of the web project `control-center`. The same 214 x 465 unit layout, the same
colours and the same SVG icon paths are used, but the controls now talk to real Android APIs.

## বাংলায়: GitHub এ APK বানানোর নিয়ম

১. GitHub এ নতুন repository খুলুন (যেমন `control-center-android`)।
২. এই ফোল্ডারের **সব ফাইল** আপলোড করুন, লুকানো `.github` ফোল্ডারসহ।
   (ফোনে `.github` আপলোড না হলে: **Add file → Create new file**, নামের ঘরে
   `.github/workflows/build-apk.yml` লিখে ফাইলের লেখা পেস্ট করুন।)
৩. `main` ব্রাঞ্চে commit করলেই **Actions** ট্যাবে *Build APK* চলবে (প্রায় ৫–৮ মিনিট)।
৪. কাজ শেষ হলে ওই run খুলুন, নিচে **Artifacts → control-center-apk** ডাউনলোড করুন, জিপ খুলে `app-debug.apk` ইনস্টল করুন।
৫. রিলিজ লিংক চাইলে tag দিন, যেমন `v1.0`: APK নিজে থেকে **Releases** এ চলে আসবে।

## English

1. Create a repository and upload every file (including the hidden `.github` folder).
2. Push to `main`. The *Build APK* workflow runs `gradle assembleDebug`.
3. Open the run, download the **control-center-apk** artifact, unzip and install `app-debug.apk`.
4. Push a tag like `v1.0` to also publish the APK under **Releases**.

Local build: open the folder in Android Studio (Koala or newer) and press Run.

## Shizuku (v2)

All toggles now run through **Shizuku** (adb-shell level privileges). Without Shizuku the app falls back to opening the matching system screen, as before.

| Control | With Shizuku |
| --- | --- |
| Airplane | `cmd connectivity airplane-mode enable/disable` |
| Wi-Fi | `svc wifi enable/disable` |
| Mobile data | `svc data enable/disable` |
| Bluetooth | `cmd bluetooth_manager enable/disable` (fallback `svc bluetooth`) |
| Hotspot | `cmd connectivity start-tethering wifi` (ROM dependent, falls back to the tethering screen) |
| Focus | real Do Not Disturb: `cmd notification set_dnd on/off` |
| Orientation lock | real auto-rotate setting |
| Brightness | real system brightness (manual mode) |
| Volume, Flashlight | work without Shizuku |

Settings (gear icon, top left of the Control Center):

1. **Shizuku** - status and permission button.
2. **উপর থেকে টানলে আমার Control Center** - starts a small foreground service with an invisible strip at the very top edge. Pull down on it and this Control Center opens over any app. The "display over other apps" permission is granted automatically through Shizuku.
3. **ফোনের আসল pull-down লক** - Shizuku calls `IStatusBarService.disable` (`DISABLE_EXPAND`, `DISABLE2_QUICK_SETTINGS`, `DISABLE2_NOTIFICATION_SHADE`) so the phone's own notification panel and control center do not open. The lock lives in the Shizuku user-service process: it is released when Shizuku stops or the phone restarts, and re-applied when Shizuku connects again. Switching the overlay off also releases it.

Setup order: install Shizuku, start it, open this app, Settings, allow Shizuku, switch on the overlay, then the lock.

## Settings home (v2.1)

Opening the app shows all settings (the app is in English): Shizuku status, the pull-down switch (trigger height / area, start after reboot), the stock pull-down lock, tile chooser (up to 16 tiles), preferences (24-hour clock, hint messages, vibrate on tap), a permissions page (overlay, notifications, modify system settings, Do Not Disturb access, battery) and a short setup guide. Tap **Open Control Center** to see the panel.

Without Shizuku: brightness and rotation lock work with the *Modify system settings* permission, Focus works with *Do Not Disturb access*.

## Pull-down helper (v2.2)

On many phones the system status bar sits above overlays, so a swipe from the very top opens the phone's own panel. Turn on the **Pull-down helper** (an accessibility service, Settings → Pull-down Control Center). It notices the stock panel opening, closes it and shows this Control Center. With Shizuku it is enabled in one tap; otherwise turn it on in Accessibility settings (on Android 13+ you may first need App info → ⋮ → Allow restricted settings). The **Test panel** button opens the panel without any swipe.

## Other controls

| Control | Behaviour |
| --- | --- |
| Status bar battery, Wi-Fi, mobile data, airplane | Live state |
| Share | System share sheet |
| Mirror, Output | Open the matching Android settings screen |
| Camera | Opens the phone's camera app |
| Code scanner | Google code scanner (QR), needs Google Play services |
| Timer | Countdown with beep and vibration |
| Calculator | Working calculator |
| Now Playing | Tap play to pick audio files (inside the app, not in the overlay) |

## Files

```
app/src/main/java/com/controlcenter/app/
  MainActivity.kt          entry point
  Controller.kt            all device logic and state
  Shell.kt / ShellService.kt  Shizuku bridge and the privileged shell process
  OverlayService.kt        pull-down strip + overlay panel
  BootReceiver.kt          restarts the overlay after reboot
  ui/SettingsScreen.kt     Settings page
  ui/ControlCenterScreen.kt  layout (grid of 214 x 465 units), sheets
  ui/Icons.kt              SVG path icons drawn with Compose Canvas
  ui/Calc.kt               calculator logic
.github/workflows/build-apk.yml   APK build
```

## License

MIT
