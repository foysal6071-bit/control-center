package com.controlcenter.app.ui

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.controlcenter.app.OverlayService
import com.controlcenter.app.Shell
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val BG = Color(0xFF0D1015)
private val CARD = Color(0xFF1A1F2A)
private val DIM = Color(0xB3FFFFFF)
private val OK = Color(0xFF34C759)
private val INFO = Color(0xFF7DB4FF)

/** Home screen of the app: every setting in one place. */
@Composable
fun SettingsScreen(onOpenControlCenter: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val prefs = remember { ctx.getSharedPreferences("cc", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val pkg = ctx.packageName

    var overlayOn by remember { mutableStateOf(prefs.getBoolean("overlay_on", false) && Settings.canDrawOverlays(ctx)) }
    var lockOn by remember { mutableStateOf(prefs.getBoolean("lock_stock", false)) }
    var msg by remember { mutableStateOf("") }
    var pendingOverlay by remember { mutableStateOf(false) }
    var resumeTick by remember { mutableIntStateOf(0) }
    var triggerH by remember { mutableIntStateOf(prefs.getInt("trigger_h", 1)) }
    var triggerSide by remember { mutableIntStateOf(prefs.getInt("trigger_side", 0)) }

    DisposableEffect(activity) {
        Shell.evaluate()
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                Shell.evaluate()
                resumeTick++
            }
        }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }

    /* permission states, re-read every time the screen comes back to the front or something changes */
    var permTick by remember { mutableIntStateOf(0) }
    val overlayPerm = remember(resumeTick, permTick) { Settings.canDrawOverlays(ctx) }
    val notifPerm = remember(resumeTick, permTick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val writePerm = remember(resumeTick, permTick) { Settings.System.canWrite(ctx) }
    val dndPerm = remember(resumeTick, permTick) {
        try { ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted } catch (_: Exception) { false }
    }
    val battPerm = remember(resumeTick, permTick) {
        try { ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(pkg) } catch (_: Exception) { false }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permTick++
        if (!granted) {
            // Android will not ask again: send the user to the app's notification page
            ctx.startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
            )
        }
    }

    fun grantNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (Shell.ready) scope.launch {
                Shell.exec("pm grant $pkg android.permission.POST_NOTIFICATIONS")
                delay(300); permTick++
            } else notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg))
        }
    }

    fun restartOverlayIfOn() {
        if (overlayOn) {
            OverlayService.stop(ctx)
            OverlayService.start(ctx)
        }
    }

    fun setOverlay(on: Boolean) {
        scope.launch {
            if (on) {
                if (!Settings.canDrawOverlays(ctx) && Shell.ready) {
                    Shell.exec("appops set $pkg SYSTEM_ALERT_WINDOW allow")
                    delay(400)
                }
                if (!Settings.canDrawOverlays(ctx)) {
                    msg = "Allow “Display over other apps”. The switch turns on by itself when you come back."
                    pendingOverlay = true
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
                    return@launch
                }
                pendingOverlay = false
                permTick++
                if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) grantNotifications()
                prefs.edit().putBoolean("overlay_on", true).apply()
                overlayOn = true
                OverlayService.start(ctx)
                msg = "Turned on. Pull down from the very top edge of the screen."
            } else {
                // switch the lock off first so the phone is never left without a pull-down
                if (lockOn) {
                    Shell.setStatusBarLocked(false)
                    lockOn = false
                    prefs.edit().putBoolean("lock_stock", false).apply()
                }
                pendingOverlay = false
                prefs.edit().putBoolean("overlay_on", false).apply()
                overlayOn = false
                OverlayService.stop(ctx)
                msg = ""
            }
        }
    }

    // back from the system permission screen: finish what the user started
    LaunchedEffect(resumeTick) {
        if (pendingOverlay && Settings.canDrawOverlays(ctx)) setOverlay(true)
    }

    fun setLock(on: Boolean) {
        scope.launch {
            val ok = Shell.setStatusBarLocked(on)
            if (ok) {
                lockOn = on
                prefs.edit().putBoolean("lock_stock", on).apply()
                msg = if (on) "The phone’s own notification panel and Control Center are now locked."
                else "The phone’s own pull-down is back."
            } else {
                msg = "Couldn’t change the lock on this phone. Is Shizuku running?"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(
            Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Control Center", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("All settings in one place.", color = DIM, fontSize = 13.sp)

            Button(onClick = onOpenControlCenter, modifier = Modifier.fillMaxWidth()) { Text("Open Control Center") }

            if (msg.isNotEmpty()) Text(msg, color = INFO, fontSize = 13.sp)

            /* ---- Shizuku ---- */
            Card("Shizuku") {
                val (text, ok) = when (Shell.state) {
                    Shell.State.Ready -> "Connected ✓  Wi-Fi, Mobile data, Airplane, Bluetooth, Hotspot, Focus (DND), Rotation, Brightness and Screenshot now work through Shizuku." to true
                    Shell.State.Connecting -> "Connecting to Shizuku…" to false
                    Shell.State.NoPermission ->
                        (if (Shell.deniedForever) "Permission was denied before. Open the Shizuku app → Authorized apps and allow Control Center."
                        else "Shizuku is running, but this app has not been allowed yet.") to false
                    Shell.State.NotRunning -> "Shizuku is not running. Open the Shizuku app and press Start (wireless debugging or root)." to false
                }
                Text(text, color = if (ok) OK else DIM, fontSize = 14.sp)
                when (Shell.state) {
                    Shell.State.NoPermission -> if (!Shell.deniedForever) {
                        Button(onClick = { Shell.requestPermission() }) { Text("Allow") }
                    } else {
                        Button(onClick = { if (!Shell.launchShizukuApp(ctx)) msg = "Shizuku is not installed." }) { Text("Open Shizuku") }
                    }
                    Shell.State.NotRunning ->
                        Button(onClick = { if (!Shell.launchShizukuApp(ctx)) msg = "Shizuku is not installed." }) { Text("Open Shizuku") }
                    else -> {}
                }
                Text("Shizuku is optional. Without it, the controls open the matching system screen instead.", color = DIM, fontSize = 12.sp)
            }

            /* ---- pull-down ---- */
            Card("Pull-down Control Center") {
                SwitchRow(
                    "Open Control Center from the top edge",
                    "Pull down from the top of the screen and it opens over any app.",
                    overlayOn, true
                ) { setOverlay(it) }
                if (!overlayPerm && !overlayOn) {
                    Text("Needs “Display over other apps”. It is granted automatically when Shizuku is connected.", color = DIM, fontSize = 12.sp)
                }

                Text("Trigger height", color = Color.White, fontSize = 14.sp)
                Choice(listOf("Small", "Normal", "Large"), triggerH) {
                    triggerH = it; prefs.edit().putInt("trigger_h", it).apply(); restartOverlayIfOn()
                }
                Text("Trigger area", color = Color.White, fontSize = 14.sp)
                Choice(listOf("Full width", "Left half", "Right half"), triggerSide) {
                    triggerSide = it; prefs.edit().putInt("trigger_side", it).apply(); restartOverlayIfOn()
                }
                PrefSwitch(prefs, "boot_start", true, "Start after reboot", "Turns the pull-down back on when the phone starts.")
            }

            Card("Lock the phone’s own pull-down") {
                SwitchRow(
                    "Lock notification panel and stock Control Center",
                    "While on, only this Control Center opens when you pull down.",
                    lockOn, Shell.ready && overlayOn
                ) { setLock(it) }
                if (!overlayOn) Text("Turn on “Open Control Center from the top edge” first.", color = DIM, fontSize = 12.sp)
                else if (!Shell.ready) Text("Needs Shizuku to be connected.", color = DIM, fontSize = 12.sp)
                Text(
                    "The lock is released when the phone restarts or Shizuku stops, and the app puts it back when Shizuku reconnects. " +
                        "If you get stuck, open this app and switch it off.",
                    color = DIM, fontSize = 12.sp
                )
            }

            /* ---- tiles ---- */
            Card("Tiles") {
                val state = remember {
                    mutableStateMapOf<String, Boolean>().apply { Tiles.all.forEach { put(it.id, Tiles.isOn(ctx, it)) } }
                }
                val count = state.values.count { it }
                Text("Choose what the grid shows ($count of ${Tiles.MAX}).", color = DIM, fontSize = 12.sp)
                Tiles.all.forEach { d ->
                    val on = state[d.id] == true
                    SwitchRow(d.label, "", on, on || count < Tiles.MAX) {
                        state[d.id] = it
                        Tiles.setOn(ctx, d.id, it)
                    }
                }
            }

            /* ---- preferences ---- */
            Card("Preferences") {
                PrefSwitch(prefs, "clock24", false, "24-hour clock", "")
                PrefSwitch(prefs, "hints", true, "Hint messages", "Show short messages like “Wi-Fi is on” at the top.")
                PrefSwitch(prefs, "haptic", true, "Vibrate on tap", "")
            }

            /* ---- permissions ---- */
            Card("Permissions") {
                PermRow("Display over other apps", "Needed for the pull-down panel.", overlayPerm) {
                    scope.launch {
                        if (Shell.ready) {
                            Shell.exec("appops set $pkg SYSTEM_ALERT_WINDOW allow"); delay(300); permTick++
                        } else ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
                    }
                }
                PermRow("Notifications", "Shows the “on” notification and the timer alert.", notifPerm) { grantNotifications() }
                PermRow("Modify system settings", "Lets the brightness slider and rotation lock work without Shizuku.", writePerm) {
                    scope.launch {
                        if (Shell.ready) {
                            Shell.exec("appops set $pkg WRITE_SETTINGS allow"); delay(300); permTick++
                        } else ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$pkg")))
                    }
                }
                PermRow("Do Not Disturb access", "Lets the Focus tile switch Do Not Disturb without Shizuku.", dndPerm) {
                    scope.launch {
                        if (Shell.ready) {
                            Shell.exec("cmd notification allow_dnd $pkg"); delay(300); permTick++
                        } else ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    }
                }
                PermRow("Unrestricted battery", "Stops the system from closing the pull-down trigger in the background.", battPerm) {
                    scope.launch {
                        if (Shell.ready) {
                            Shell.exec("cmd deviceidle whitelist +$pkg"); delay(300); permTick++
                        } else ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                }
            }

            /* ---- help ---- */
            Card("How to set up") {
                Text(
                    "1. Install Shizuku and start it (optional, but gives the most control).\n" +
                        "2. Allow Control Center inside Shizuku.\n" +
                        "3. Turn on “Open Control Center from the top edge”.\n" +
                        "4. Optional: lock the phone’s own pull-down.\n" +
                        "5. Pull down from the very top of the screen.",
                    color = DIM, fontSize = 13.sp
                )
            }

            Card("About") {
                val ver = remember {
                    try { ctx.packageManager.getPackageInfo(pkg, 0).versionName ?: "" } catch (_: Exception) { "" }
                }
                Text("Control Center $ver", color = Color.White, fontSize = 14.sp)
                Text("iOS-style Control Center for Android. MIT license.", color = DIM, fontSize = 12.sp)
            }

            Button(onClick = onOpenControlCenter, modifier = Modifier.fillMaxWidth()) { Text("Open Control Center") }
            Box(Modifier.padding(8.dp))
        }
    }
}

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(CARD, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            if (sub.isNotEmpty()) Text(sub, color = DIM, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

/** A switch stored in the shared preferences. */
@Composable
private fun PrefSwitch(prefs: SharedPreferences, key: String, def: Boolean, title: String, sub: String) {
    var on by remember { mutableStateOf(prefs.getBoolean(key, def)) }
    SwitchRow(title, sub, on, true) {
        on = it
        prefs.edit().putBoolean(key, it).apply()
    }
}

@Composable
private fun PermRow(title: String, sub: String, granted: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(sub, color = DIM, fontSize = 12.sp)
        }
        if (granted) Text("Allowed ✓", color = OK, fontSize = 13.sp)
        else OutlinedButton(onClick = onGrant) { Text("Allow") }
    }
}

/** Small segmented choice: the selected option is filled. */
@Composable
private fun Choice(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            val m = Modifier.weight(1f)
            if (i == selected) Button(onClick = { onSelect(i) }, modifier = m, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) { Text(label, fontSize = 12.sp, maxLines = 1) }
            else OutlinedButton(onClick = { onSelect(i) }, modifier = m, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) { Text(label, fontSize = 12.sp, maxLines = 1) }
        }
    }
}
