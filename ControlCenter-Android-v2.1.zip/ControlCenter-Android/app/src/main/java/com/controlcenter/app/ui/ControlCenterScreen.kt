package com.controlcenter.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.controlcenter.app.Controller
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/* ---------- colours: dark glass tiles on a soft blurred wallpaper ---------- */
private val TILE = Color(0xDB2B2E35)
private val TILE_ON = Color(0xF2F3F5F9)
private val TILE_BAD = Color(0xE0402A30)
private val INK = Color(0xFF1B1D22)
private val RED = Color(0xFFFF453A)
private val RED_ICON = Color(0xFFFF5A5A)
private val EDGE = Color.White.copy(alpha = 0.10f)

private enum class Tone { Off, On, Bad }

/* square tile grid: 4 columns x 4 rows under the sliders */
private const val TW = 41f
private fun colX(i: Int) = 14f + i * (TW + 7.33f)
private fun rowY(r: Int) = 190f + r * 51f


private enum class Page { None, Calc, Timer }

/** One grid unit = u dp. The layout is drawn on a 214 x 465 unit grid, exactly like the web version. */
private fun Modifier.at(u: Dp, x: Float, y: Float, w: Float, h: Float): Modifier =
    this.offset(u * x, u * y).size(u * w, u * h)

@Composable
private fun Dp.spx(): TextUnit = with(LocalDensity.current) { this@spx.toSp() }

@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.92f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "press")
    val haptic = LocalHapticFeedback.current
    val ctx = LocalContext.current
    val hapticOn = remember { ctx.getSharedPreferences("cc", android.content.Context.MODE_PRIVATE).getBoolean("haptic", true) }
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, role = Role.Button) {
            if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

/** Springy staggered entrance, top row first. */
@Composable
private fun Modifier.pop(y: Float): Modifier {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay((y * 1.4f).toLong()); shown = true }
    val sc by animateFloatAsState(if (shown) 1f else 0.85f, spring(dampingRatio = 0.62f, stiffness = 360f), label = "pop")
    val al by animateFloatAsState(if (shown) 1f else 0f, tween(280), label = "popA")
    return this.graphicsLayer { scaleX = sc; scaleY = sc; alpha = al }
}

/**
 * @param onOpenSettings the gear button (top left)
 * @param onClose when not null the screen runs as the pull-down overlay: dim background, closes on
 *   swipe up / tap outside / the handle at the bottom. When null it is the normal full screen app.
 */
@Composable
fun ControlCenterApp(
    onOpenSettings: () -> Unit = {},
    onClose: (() -> Unit)? = null,
    insetTop: Dp = 0.dp,
    insetBottom: Dp = 0.dp
) {
    val overlay = onClose != null
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ctl = remember { Controller(ctx, scope) }

    DisposableEffect(ctl) {
        ctl.start()
        onDispose { ctl.stop() }
    }

    if (!overlay) {
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            ctl.setTracks(uris)
        }
        SideEffect { ctl.onPickAudio = { picker.launch(arrayOf("audio/*")) } }
    } else {
        SideEffect {
            ctl.onPickAudio = { ctl.say("Open the app to choose music", true) }
            ctl.onLaunched = { onClose?.invoke() }
        }
    }

    val tiles = remember { Tiles.enabled(ctx) }
    var page by remember { mutableStateOf(Page.None) }
    var toastVisible by remember { mutableStateOf(false) }

    LaunchedEffect(ctl.toastTick) {
        if (ctl.toastTick > 0) {
            toastVisible = true
            delay(2400)
            toastVisible = false
        }
    }
    LaunchedEffect(ctl.timerEnd) {
        while (ctl.timerEnd > 0L) {
            ctl.tickTimer()
            delay(250)
        }
    }

    var clock by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val h24 = ctx.getSharedPreferences("cc", android.content.Context.MODE_PRIVATE).getBoolean("clock24", false)
        val f = java.text.SimpleDateFormat(if (h24) "EEE, d MMM  •  HH:mm" else "EEE, d MMM  •  h:mm a", java.util.Locale.getDefault())
        while (true) {
            clock = f.format(java.util.Date())
            delay(15_000)
        }
    }

    if (!overlay) {
        BackHandler(enabled = page != Page.None || ctl.qrResult != null) {
            if (ctl.qrResult != null) ctl.qrResult = null else page = Page.None
        }
    }

    /* overlay only: tap outside the grid or swipe up closes the panel */
    val closeMod = if (onClose != null) {
        Modifier
            .pointerInput(Unit) { detectTapGestures { onClose() } }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc < -size.height * 0.08f) onClose() },
                    onDragCancel = { acc = 0f }
                ) { _, dy -> acc += dy }
            }
    } else Modifier

    Box(Modifier.fillMaxSize().then(if (overlay) Modifier else Modifier.background(Color(0xFF0D1015))).then(closeMod)) {
        if (overlay) Box(Modifier.fillMaxSize().alpha(0.97f)) { Wallpaper() } else Wallpaper()
        BoxWithConstraints(
            Modifier.fillMaxSize().then(
                if (overlay) Modifier.padding(top = insetTop, bottom = insetBottom)
                else Modifier.windowInsetsPadding(WindowInsets.systemBars)
            )
        ) {
            val u = minOf(maxWidth / 214f, maxHeight / 465f)
            Box(
                Modifier.width(u * 214f).fillMaxHeight().align(Alignment.TopCenter)
                    .then(if (overlay) Modifier.pointerInput(Unit) { detectTapGestures { } } else Modifier)
            ) {

                /* top bar: clock on the left, live status + battery on the right */
                Text(
                    clock, Modifier.at(u, 16f, 12f, 88f, 12f),
                    color = Color(0xE6FFFFFF), fontSize = (u * 6.6f).spx(), fontWeight = FontWeight.Medium, maxLines = 1
                )
                Ctl(u, 106f, 10f, 16f, 16f, Color.Transparent, Ic.power, 9f, "Refresh", Color(0xB3FFFFFF)) { ctl.refreshApp() }
                Row(
                    Modifier.at(u, 124f, 12f, 76f, 12f),
                    horizontalArrangement = Arrangement.spacedBy(u * 4f, Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (ctl.airplane) SvgIcon(Ic.airplane, u * 8f, Color.White)
                    if (ctl.wifi && !ctl.airplane) SvgIcon(Ic.wifi, u * 8f, Color.White)
                    if (ctl.cell && !ctl.airplane) SvgIcon(Ic.cell, u * 8f, Color.White)
                    Text(
                        "${(ctl.batteryLevel * 100).roundToInt()}%",
                        color = Color.White, fontSize = (u * 6.4f).spx(), fontWeight = FontWeight.SemiBold, maxLines = 1
                    )
                    BatteryIcon(ctl.batteryLevel, ctl.charging, u * 13f, u * 6.4f)
                }

                /* hint line ("Wi-Fi is on"), shown for a moment after a change */
                AnimatedVisibility(
                    visible = toastVisible,
                    modifier = Modifier.offset(u * 14f, u * 31f).width(u * 186f),
                    enter = fadeIn(), exit = fadeOut()
                ) {
                    Text(
                        ctl.toastText, Modifier.fillMaxWidth(),
                        color = Color(0xE6FFFFFF), fontSize = (u * 6.2f).spx(), fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }

                /* Wi-Fi + Mobile data */
                WideTile(
                    u, 14f, 50f, 96f, 38f, if (ctl.wifiOn) Tone.On else Tone.Off,
                    Ic.wifi, "Wi-Fi", if (ctl.wifiOn) "On" else "Off"
                ) { ctl.tapWifi() }
                WideTile(
                    u, 116f, 50f, 84f, 38f,
                    if (ctl.airplane) Tone.Bad else if (ctl.dataOn) Tone.On else Tone.Off,
                    Ic.cellOff.takeIf { ctl.airplane } ?: Ic.cell, "Mobile data",
                    if (ctl.airplane) "Not available" else if (ctl.dataOn) "On" else "Off"
                ) { ctl.tapCell() }

                /* media player + brightness + volume */
                MediaTile(u, ctl, 14f, 94f, 96f, 86f)
                VSlider(u, 116f, 94f, ctl.brightness, { ctl.changeBrightness(it) }, Ic.brightness, "Brightness")
                val tier = if (ctl.volume <= 0f) 0 else if (ctl.volume > 0.34f) 2 else 1
                VSlider(u, 160f, 94f, ctl.volume, { ctl.changeVolume(it) }, remember(tier) { Ic.volume(tier) }, "Volume")

                /* tiles: the ones chosen in Settings, filled row by row */
                tiles.forEachIndexed { i, id ->
                    val c = i % 4
                    val r = i / 4
                    when (id) {
                        "bluetooth" -> Sq(u, c, r, ctl.bluetooth, Ic.bluetooth, 19f, "Bluetooth") { ctl.tapBluetooth() }
                        "airplane" -> Sq(u, c, r, ctl.airplane, Ic.airplane, 20f, "Airplane mode") { ctl.tapAirplane() }
                        "silent" -> Sq(u, c, r, ctl.volume <= 0f, if (ctl.volume <= 0f) Ic.bellOff else Ic.bell, 19f, "Silent mode") { ctl.toggleMute() }
                        "torch" -> Sq(u, c, r, ctl.torch, Ic.flash, 19f, "Flashlight") { ctl.toggleTorch() }
                        "screenshot" -> Sq(u, c, r, false, Ic.scissors, 19f, "Screenshot") { ctl.screenshot() }
                        "battery" -> Sq(u, c, r, false, Ic.boltRing, 20f, "Battery saver") { ctl.tapBatterySaver() }
                        "internet" -> Sq(u, c, r, false, Ic.internet, 20f, "Internet") { ctl.tapInternet() }
                        "rotation" -> Sq(u, c, r, ctl.locked, Ic.lock, 21f, "Orientation lock") { ctl.toggleLock() }
                        "camera" -> Sq(u, c, r, false, Ic.video, 20f, "Camera") { ctl.openCamera() }
                        "cast" -> Sq(u, c, r, false, Ic.cast, 19f, "Screen cast") { ctl.tapMirror() }
                        "hotspot" -> Sq(u, c, r, ctl.hotspot, Ic.waves, 20f, "Personal hotspot") { ctl.tapHotspot() }
                        "qr" -> Sq(u, c, r, false, Ic.qr, 19f, "Code scanner") { ctl.scanQr() }
                        "timer" -> {
                            Sq(u, c, r, ctl.timerRunning, if (ctl.timerRunning) emptyList() else Ic.timer, 20f, "Timer") { page = Page.Timer }
                            if (ctl.timerRunning) {
                                Box(Modifier.at(u, colX(c), rowY(r), TW, TW), contentAlignment = Alignment.Center) {
                                    Text(
                                        ctl.timerText(),
                                        color = INK, fontSize = (u * 7.4f).spx(), fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center, maxLines = 1
                                    )
                                }
                            }
                        }
                        "focus" -> Sq(u, c, r, ctl.focus, Ic.moon, 19f, "Focus") { ctl.toggleFocus() }
                        "calc" -> Sq(u, c, r, false, Ic.calcMono, 19f, "Calculator") { page = Page.Calc }
                        "share" -> Sq(u, c, r, false, Ic.share, 19f, "Share") { ctl.share() }
                        "output" -> Sq(u, c, r, false, Ic.airplay, 19f, "Sound output") { ctl.tapAirplay() }
                        else -> {}
                    }
                }

                /* Edit pill = Settings */
                val editY = rowY((tiles.size - 1).coerceAtLeast(0) / 4) + TW + 15f
                Box(
                    Modifier.at(u, 85f, editY, 44f, 18f).pop(editY).tap { onOpenSettings() }
                        .semantics { contentDescription = "Settings" }
                        .background(TILE, RoundedCornerShape(u * 9f))
                        .border(u * 0.4f, EDGE, RoundedCornerShape(u * 9f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Edit", color = Color.White, fontSize = (u * 7.2f).spx(), fontWeight = FontWeight.Medium, maxLines = 1)
                }

                /* overlay: handle at the bottom closes the panel */
                if (onClose != null) {
                    Box(
                        Modifier.at(u, 77f, 436f, 60f, 24f).tap { onClose() }
                            .semantics { contentDescription = "Close Control Center" },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(u * 34f, u * 3.2f).background(Color(0x99FFFFFF), RoundedCornerShape(u * 2f)))
                    }
                }

                /* full-screen sheets */
                if (page == Page.Calc) CalcSheet(u) { page = Page.None }
                if (page == Page.Timer) TimerSheet(u, ctl) { page = Page.None }

                /* scanned QR code */
                ctl.qrResult?.let { text ->
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(start = u * 16f, end = u * 16f, bottom = u * 40f)
                            .fillMaxWidth()
                            .background(Color(0xE61E222A), RoundedCornerShape(u * 10f))
                            .padding(u * 8f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(u * 6f)
                    ) {
                        Text(
                            text.ifEmpty { "(empty code)" }, color = Color.White, fontSize = (u * 7f).spx(),
                            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 6,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(u * 6f)) {
                            if (text.startsWith("http://", true) || text.startsWith("https://", true)) {
                                Pill(u, "Open", Color(0xFF7DB4FF)) { ctl.openQrLink(text); ctl.qrResult = null }
                            }
                            Pill(u, "Copy", Color.White) { ctl.copy(text) }
                            Pill(u, "Close", Color(0xB3FFFFFF)) { ctl.qrResult = null }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Wallpaper() {
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(0f to Color(0xFF8793B0), 0.55f to Color(0xFF9EA9C4), 1f to Color(0xFF7A86A6)))
            .drawBehind {
                fun orb(c: Color, cx: Float, cy: Float, r: Float) = drawRect(
                    Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(size.width * cx, size.height * cy), radius = size.width * r)
                )
                orb(Color(0x99DCE8FF), 0.2f, 0.08f, 0.9f)
                orb(Color(0x6685B7FF), 0.95f, 0.3f, 0.8f)
                orb(Color(0x8059D27A), 0.12f, 0.92f, 0.7f)
                orb(Color(0x80F0545C), 0.75f, 0.96f, 0.65f)
            }
    )
    Box(Modifier.fillMaxSize().background(Color(0x14000000)))
}

/** A tappable control placed on the grid. Pass iconU = 0 to draw no icon. */
@Composable
private fun Ctl(
    u: Dp, x: Float, y: Float, w: Float, h: Float,
    bg: Color, icon: List<El>, iconU: Float, desc: String,
    tint: Color = Color.White,
    shape: Shape = CircleShape,
    onClick: () -> Unit
) {
    val c by animateColorAsState(bg, label = "bg")
    val t by animateColorAsState(tint, label = "tint")
    val filled = c.alpha > 0.02f
    Box(
        Modifier.at(u, x, y, w, h).pop(y).tap(onClick).semantics { contentDescription = desc }
            .then(if (filled) Modifier.background(c, shape).border(u * 0.4f, EDGE, shape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        if (iconU > 0f && icon.isNotEmpty()) SvgIcon(icon, u * iconU, t)
    }
}

/** Square rounded tile: dark when off, light with a dark icon when on. */
@Composable
private fun Sq(u: Dp, col: Int, row: Int, on: Boolean, icon: List<El>, iconU: Float, desc: String, onClick: () -> Unit) {
    Ctl(
        u, colX(col), rowY(row), TW, TW, if (on) TILE_ON else TILE, icon, iconU, desc,
        if (on) INK else Color.White, RoundedCornerShape(u * 14f), onClick
    )
}

/** Wide tile with an icon chip and two lines of text (Wi-Fi, Mobile data). */
@Composable
private fun WideTile(
    u: Dp, x: Float, y: Float, w: Float, h: Float, tone: Tone,
    icon: List<El>, title: String, sub: String, onClick: () -> Unit
) {
    val bg by animateColorAsState(
        when (tone) { Tone.On -> TILE_ON; Tone.Off -> TILE; Tone.Bad -> TILE_BAD }, label = "wbg"
    )
    val shape = RoundedCornerShape(u * 14f)
    val titleC = when (tone) { Tone.On -> INK; Tone.Off -> Color.White; Tone.Bad -> Color(0xB3FFFFFF) }
    val subC = when (tone) { Tone.On -> Color(0xFF6B6F78); Tone.Off -> Color(0x80FFFFFF); Tone.Bad -> Color(0x80FFFFFF) }
    val chip = when (tone) { Tone.On -> INK; Tone.Off -> Color(0x33FFFFFF); Tone.Bad -> Color(0x33FF5A5A) }
    val glyph = when (tone) { Tone.On -> Color.White; Tone.Off -> Color.White; Tone.Bad -> RED_ICON }
    Box(
        Modifier.at(u, x, y, w, h).pop(y).tap(onClick).semantics { contentDescription = title }
            .background(bg, shape).border(u * 0.4f, EDGE, shape)
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = u * 7f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(u * 5f)
        ) {
            Box(Modifier.size(u * 20f).background(chip, CircleShape), contentAlignment = Alignment.Center) {
                SvgIcon(icon, u * 11f, glyph)
            }
            Column(verticalArrangement = Arrangement.Center) {
                Text(title, color = titleC, fontSize = (u * 6.9f).spx(), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(sub, color = subC, fontSize = (u * 5.6f).spx(), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Dark media tile: "No playback history" + previous / play / next. */
@Composable
private fun MediaTile(u: Dp, ctl: Controller, x: Float, y: Float, w: Float, h: Float) {
    val shape = RoundedCornerShape(u * 14f)
    Box(Modifier.at(u, x, y, w, h).pop(y).background(TILE, shape).border(u * 0.4f, EDGE, shape))
    Text(
        if (ctl.nowPlaying == "Not Playing" && !ctl.playing) "No playback history" else ctl.nowPlaying,
        Modifier.at(u, x + 9f, y + 10f, w - 18f, 24f),
        color = Color(0x99FFFFFF), fontSize = (u * 6.6f).spx(), fontWeight = FontWeight.Medium,
        maxLines = 2, overflow = TextOverflow.Ellipsis
    )
    val cy = y + 55f
    Ctl(u, x + 6f, cy, 22f, 22f, Color.Transparent, Ic.prev, 12f, "Previous", Color(0x99FFFFFF)) { ctl.prev() }
    Ctl(
        u, x + w / 2f - 12f, cy - 1f, 24f, 24f, Color.Transparent,
        if (ctl.playing) Ic.pause else Ic.play, 14f, if (ctl.playing) "Pause" else "Play"
    ) { ctl.togglePlay() }
    Ctl(u, x + w - 28f, cy, 22f, 22f, Color.Transparent, Ic.next, 12f, "Next", Color(0x99FFFFFF)) { ctl.next() }
}

@Composable
private fun VSlider(
    u: Dp, x: Float, y: Float, value: Float, onValue: (Float) -> Unit,
    icon: List<El>, desc: String
) {
    var drag by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (drag) 1.04f else 1f, label = "drag")
    val shape = RoundedCornerShape(u * 14f)
    val v = value.coerceIn(0f, 1f)
    Box(
        Modifier.at(u, x, y, 40f, 86f).pop(y)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(TILE)
            .border(u * 0.4f, EDGE, shape)
            .semantics {
                contentDescription = desc
                progressBarRangeInfo = ProgressBarRangeInfo(v, 0f..1f)
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    drag = true
                    onValue(1f - down.position.y / size.height)
                    do {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull() ?: break
                        if (ch.pressed) {
                            onValue(1f - ch.position.y / size.height)
                            ch.consume()
                        }
                    } while (ev.changes.any { it.pressed })
                    drag = false
                }
            }
    ) {
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(v)
                .background(TILE_ON)
        )
        SvgIcon(
            icon, u * 17f, if (v > 0.16f) INK else Color.White,
            Modifier.align(Alignment.BottomCenter).padding(bottom = u * 9f)
        )
        if (drag) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = u * 6f)
                    .background(Color(0xB3141820), RoundedCornerShape(u * 6f))
                    .padding(horizontal = u * 4f, vertical = u * 1.5f)
            ) {
                Text("${(v * 100).roundToInt()}%", color = Color.White, fontSize = (u * 7f).spx(), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Pill(u: Dp, text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.tap(onClick).background(Color(0x26FFFFFF), RoundedCornerShape(u * 8f))
            .padding(horizontal = u * 10f, vertical = u * 4f),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontSize = (u * 7.4f).spx(), fontWeight = FontWeight.Bold)
    }
}

/* ---------- sheets ---------- */

@Composable
private fun SheetFrame(u: Dp, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xCC080A10)).pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            Modifier.fillMaxSize().padding(start = u * 18f, top = u * 22f, end = u * 18f, bottom = u * 30f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(u * 8f, Alignment.Bottom),
            content = content
        )
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = u * 16f, end = u * 16f).size(u * 22f)
                .tap(onClose).semantics { contentDescription = "Close" }
                .background(Color(0x2EFFFFFF), CircleShape),
            contentAlignment = Alignment.Center
        ) { SvgIcon(Ic.close, u * 11f, Color.White) }
    }
}

@Composable
private fun CalcSheet(u: Dp, onClose: () -> Unit) {
    val calc = remember { Calc() }
    SheetFrame(u, onClose) {
        Text(
            calc.cur, Modifier.fillMaxWidth(),
            color = Color.White, fontSize = (u * 32f).spx(), fontWeight = FontWeight.Light,
            textAlign = TextAlign.End, maxLines = 1
        )
        val rows = listOf(
            listOf("AC", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+")
        )
        rows.forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(u * 5f)) {
                r.forEach { k -> CalcKey(u, k, calc, false) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(u * 5f)) {
            CalcKey(u, "0", calc, true)
            CalcKey(u, ".", calc, false)
            CalcKey(u, "=", calc, false)
        }
    }
}

@Composable
private fun CalcKey(u: Dp, k: String, calc: Calc, wide: Boolean) {
    val isOp = k in setOf("÷", "×", "−", "+", "=")
    val isFn = k in setOf("AC", "±", "%")
    val active = isOp && k != "=" && calc.fresh && calc.op == k
    val bg = when {
        active -> Color.White
        isOp -> Color(0xFFFF9F0A)
        isFn -> Color(0xFFA5A5A5)
        else -> Color(0xFF333333)
    }
    val fg = when {
        active -> Color(0xFFFF9F0A)
        isFn -> Color(0xFF111111)
        else -> Color.White
    }
    Box(
        Modifier.size(if (wide) u * 81f else u * 38f, u * 38f).tap { calc.press(k) }
            .semantics { contentDescription = k }
            .background(bg, RoundedCornerShape(u * 19f)),
        contentAlignment = if (wide) Alignment.CenterStart else Alignment.Center
    ) {
        Text(
            k, Modifier.padding(start = if (wide) u * 15f else u * 0f),
            color = fg, fontSize = (u * 13f).spx()
        )
    }
}

@Composable
private fun TimerSheet(u: Dp, ctl: Controller, onClose: () -> Unit) {
    val running = ctl.timerRunning
    SheetFrame(u, onClose) {
        Text(ctl.timerText(), color = Color.White, fontSize = (u * 40f).spx(), fontWeight = FontWeight.ExtraLight)
        Row(horizontalArrangement = Arrangement.spacedBy(u * 14f), modifier = Modifier.alpha(if (running) 0.35f else 1f)) {
            listOf("−" to -1, "+" to 1).forEach { (label, d) ->
                Box(
                    Modifier.size(u * 38f).tap { ctl.timerAdjust(d) }
                        .semantics { contentDescription = if (d < 0) "One minute less" else "One minute more" }
                        .background(Color(0xFF333333), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text(label, color = Color.White, fontSize = (u * 18f).spx()) }
            }
        }
        Box(
            Modifier.padding(top = u * 6f).size(u * 110f, u * 34f).tap { ctl.timerToggle() }
                .background(if (running) RED else Color(0xFF30D158), RoundedCornerShape(u * 17f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (running) "Cancel" else "Start",
                color = if (running) Color.White else Color(0xFF04210D),
                fontSize = (u * 10f).spx(), fontWeight = FontWeight.Bold
            )
        }
    }
}
