package com.controlcenter.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.controlcenter.app.ui.ControlCenterApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Keeps a thin invisible strip over the top edge of the screen. Pulling down on it opens this
 * app's Control Center as an overlay on top of every app. Together with the "lock" switch in
 * Settings (Shizuku) the phone's own notification panel / control center no longer opens.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val owner = ViewOwner()
    private var strip: View? = null
    private var panel: PanelFrame? = null
    private var panelView: ComposeView? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // startForegroundService() requires startForeground() right away, even if we stop again below
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WindowManager::class.java)
        owner.resume()
        addStrip()
        running = true
        // after a restart: put the lock of the phone's own pull-down back (no-op if Shizuku is not ready yet)
        if (getSharedPreferences("cc", Context.MODE_PRIVATE).getBoolean("lock_stock", false)) {
            scope.launch { Shell.setStatusBarLocked(true) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        try { hidePanel(false) } catch (_: Exception) {}
        try { strip?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        strip = null
        owner.destroy()
        // Never leave the phone without any pull-down: when the trigger is gone, unlock the stock one.
        scope.launch { Shell.setStatusBarLocked(false) }
        super.onDestroy()
    }

    /* ---------- foreground notification ---------- */

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("cc_overlay", "Control Center", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_SETTINGS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, "cc_overlay")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Control Center is on")
            .setContentText("Pull down from the top of the screen · tap for settings")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    /* ---------- the pull-down strip ---------- */

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun systemDimen(name: String, fallbackDp: Float): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(fallbackDp).toInt()
    }

    private fun addStrip() {
        val prefs = getSharedPreferences("cc", Context.MODE_PRIVATE)
        val base = systemDimen("status_bar_height", 26f).coerceAtLeast(dp(20f).toInt())
        val h = when (prefs.getInt("trigger_h", 1)) {
            0 -> dp(16f).toInt()
            2 -> dp(44f).toInt()
            else -> base
        }
        val side = prefs.getInt("trigger_side", 0) // 0 = full width, 1 = left half, 2 = right half
        val v = object : View(this) {
            private var downY = 0f
            private var fired = false
            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downY = e.rawY; fired = false }
                    MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - downY > dp(22f)) {
                        fired = true
                        showPanel()
                    }
                }
                return true
            }
        }
        val lp = WindowManager.LayoutParams(
            if (side == 0) ViewGroup.LayoutParams.MATCH_PARENT else resources.displayMetrics.widthPixels / 2, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or (if (side == 2) Gravity.END else Gravity.START) }
        wm.addView(v, lp)
        strip = v
    }

    /* ---------- the Control Center panel ---------- */

    private fun showPanel() {
        if (panel != null) return
        val themed = ContextThemeWrapper(this, R.style.Theme_ControlCenter)
        val top = systemDimen("status_bar_height", 26f)
        val bottom = systemDimen("navigation_bar_height", 0f)
        val density = resources.displayMetrics.density

        val root = PanelFrame(themed) { hidePanel(true) }
        val cv = ComposeView(themed)
        cv.setContent {
            ControlCenterApp(
                onOpenSettings = {
                    startActivity(
                        Intent(this, MainActivity::class.java)
                            .putExtra(MainActivity.EXTRA_SETTINGS, true)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    hidePanel(true)
                },
                onClose = { hidePanel(true) },
                insetTop = androidx.compose.ui.unit.Dp(top / density),
                insetBottom = androidx.compose.ui.unit.Dp(bottom / density)
            )
        }
        root.addView(cv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setViewTreeLifecycleOwner(owner)
        root.setViewTreeSavedStateRegistryOwner(owner)
        root.setViewTreeViewModelStoreOwner(owner)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        root.alpha = 0f
        root.translationY = -resources.displayMetrics.heightPixels * 0.25f
        try {
            wm.addView(root, lp)
        } catch (_: Exception) {
            return
        }
        panel = root
        panelView = cv
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        root.requestFocus()
        root.animate().alpha(1f).translationY(0f).setDuration(220).start()
    }

    private fun hidePanel(animated: Boolean) {
        val p = panel ?: return
        val cv = panelView
        panel = null
        panelView = null
        fun finish() {
            try { cv?.disposeComposition() } catch (_: Exception) {}
            try { wm.removeViewImmediate(p) } catch (_: Exception) {}
        }
        if (animated) {
            p.animate().alpha(0f).translationY(-p.height * 0.2f).setDuration(160).withEndAction { finish() }.start()
        } else {
            finish()
        }
    }

    /** Window root: Back key and losing focus (Home, Recents, another window) close the panel. */
    private class PanelFrame(ctx: Context, val close: () -> Unit) : FrameLayout(ctx) {
        private var hadFocus = false

        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) close()
                return true
            }
            return super.dispatchKeyEvent(e)
        }

        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus) hadFocus = true
            else if (hadFocus) close()
        }
    }

    /** Lifecycle / saved state / view model owner that a ComposeView needs outside an Activity. */
    private class ViewOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = store

        init {
            controller.performAttach()
            controller.performRestore(null)
            registry.currentState = Lifecycle.State.CREATED
        }

        fun resume() {
            registry.currentState = Lifecycle.State.RESUMED
        }

        fun destroy() {
            registry.currentState = Lifecycle.State.DESTROYED
            store.clear()
        }
    }

    companion object {
        @Volatile
        var running = false
            private set

        fun start(ctx: Context) {
            androidx.core.content.ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
