package com.controlcenter.app.ui

import android.content.Context

/** The square tiles of the Control Center grid. The user chooses which ones are shown, and in which order. */
object Tiles {
    /** The grid has room for 4 rows of 4 tiles. */
    const val MAX = 16

    data class Def(val id: String, val label: String, val defaultOn: Boolean)

    val all = listOf(
        Def("bluetooth", "Bluetooth", true),
        Def("wifi", "Wi-Fi", false),
        Def("mobile", "Mobile data", false),
        Def("torch", "Flashlight", true),
        Def("silent", "Silent mode", true),
        Def("screenshot", "Screenshot", true),
        Def("airplane", "Airplane mode", true),
        Def("rotation", "Orientation lock", true),
        Def("hotspot", "Hotspot", true),
        Def("focus", "Focus (Do Not Disturb)", true),
        Def("battery", "Battery saver", true),
        Def("cast", "Screen cast", true),
        Def("timer", "Timer", true),
        Def("share", "Share", false),
        Def("output", "Sound output", false)
    )

    private const val ORDER = "tile_order"

    private fun prefs(c: Context) = c.getSharedPreferences("cc", Context.MODE_PRIVATE)

    /**
     * Ids of the tiles to draw, in grid order (at most [MAX]).
     * Stored as one ordered list. Older versions stored one on/off switch per tile: that is used once
     * if there is no saved order yet.
     */
    fun enabled(c: Context): List<String> {
        val p = prefs(c)
        val raw = p.getString(ORDER, null)
        val known = all.map { it.id }.toSet()
        val list = if (raw == null) {
            all.filter { p.getBoolean("tile_${it.id}", it.defaultOn) }.map { it.id }
        } else {
            raw.split(",").filter { it in known }.distinct()
        }
        return list.take(MAX)
    }

    /** Saves the shown tiles in their grid order. */
    fun save(c: Context, ids: List<String>) {
        prefs(c).edit().putString(ORDER, ids.distinct().take(MAX).joinToString(",")).apply()
    }

    fun isOn(c: Context, d: Def): Boolean = d.id in enabled(c)

    /** Switch one tile on (added at the end) or off (the others keep their order). */
    fun setOn(c: Context, id: String, on: Boolean) {
        val l = enabled(c).toMutableList()
        if (on) {
            if (id !in l && l.size < MAX) l.add(id)
        } else {
            l.remove(id)
        }
        save(c, l)
    }
}
