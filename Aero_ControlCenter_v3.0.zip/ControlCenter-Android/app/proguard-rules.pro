# Keep AIDL binder interfaces and generated implementations used across process boundaries.
-keep interface com.controlcenter.app.IUserService { *; }
-keep interface com.controlcenter.app.IPullListener { *; }
-keep class com.controlcenter.app.** extends android.app.Service { *; }
-keep class com.controlcenter.app.** extends android.content.BroadcastReceiver { *; }
