package com.aerocontrolcenter.app

import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.telephony.TelephonyManager
import android.view.ContextThemeWrapper
import android.view.Display
import android.view.Gravity
import android.view.Surface
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.aerocontrolcenter.app.ui.StatusBarContent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

/** Everything the custom status bar shows. Compose reads it; only [StatusBarService] writes it (main thread). */
class StatusData {
    /** False until the phone's own status bar is really hidden: nothing is drawn before that (no double bar). */
    var active by mutableStateOf(false)

    var time by mutableStateOf("")
    var speed by mutableStateOf("0.00")
    var speedUnit by mutableStateOf("KB/s")
    var down by mutableStateOf(false)
    var up by mutableStateOf(false)
    var alarm by mutableStateOf(false)
    var volte by mutableStateOf(false)
    var netType by mutableStateOf("")
    var signal by mutableIntStateOf(0)        // 0..4
    var wifiLevel by mutableIntStateOf(-1)    // -1 = not on Wi-Fi, otherwise 0..4
    var battery by mutableIntStateOf(100)
    var charging by mutableStateOf(false)
    var saver by mutableStateOf(false)

    var showSpeed by mutableStateOf(true)
    var showNotif by mutableStateOf(true)
    var showVolte by mutableStateOf(true)
    var black by mutableStateOf(false)

    /** True while the app behind the bar is light: icons and text turn dark so they stay readable. */
    var dark by mutableStateOf(false)

    /** True while the Control Center / notification panel is open: the bar is not drawn over it. */
    var panel by mutableStateOf(false)

    /** Left / right space in dp (round corners and side camera cut-outs). */
    var padStart by mutableFloatStateOf(16f)
    var padEnd by mutableFloatStateOf(16f)
}

/**
 * Custom status bar. The phone's own status bar is hidden through Shizuku (clock, notification icons and
 * system icons are switched off) and this bar is drawn in its place as an overlay.
 *
 * Landscape: the phone's own bar is shown; turning the phone back to portrait brings this bar back.
 *
 * Safety: the phone's own bar is given back while the screen is off / the phone is locked, when Shizuku stops,
 * when this service stops, and by the "Restore phone's status bar" button at the top of the app settings.
 */
class StatusBarService : Service() {

    private lateinit var wm: WindowManager
    private val owner = BarOwner()
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val data = StatusData()
    private var bar: ComposeView? = null

    private var lastRotation = 0
    private var screenOn = true
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L
    private var telCallback: Any? = null
    private var telListener: Any? = null
    /** 5G NSA shows up as LTE in dataNetworkType; the display info tells the real label. */
    private var overrideNet = 0

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            main.postDelayed(this, 1000L)
        }
    }

    /** Status bar text colour: looked at 5 times a second (every 200 ms) and applied at once. */
    private val inkTicker = object : Runnable {
        override fun run() {
            if (screenOn) readBackground()
            main.postDelayed(this, INK_INTERVAL_MS)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val intent = i ?: return
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> readBattery(intent)
                PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> readSaver()
                Intent.ACTION_SCREEN_OFF -> onScreen(false)
                Intent.ACTION_SCREEN_ON -> onScreen(true)
                Intent.ACTION_USER_PRESENT -> syncStock()
                WifiManager.RSSI_CHANGED_ACTION, WifiManager.NETWORK_STATE_CHANGED_ACTION -> if (screenOn) readNetwork()
                // clock, time zone and alarm changes
                else -> if (screenOn) tick()
            }
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val r = rotation()
            if (r == lastRotation) return
            lastRotation = r
            addBar()
            // landscape: the phone's own bar comes back; portrait: this bar comes back
            syncStock()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WindowManager::class.java)
        owner.resume()
        instance = this
        running = true
        loadPrefs()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_TIME_TICK)
            addAction(WifiManager.RSSI_CHANGED_ACTION)
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED)
        }
        try {
            ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (_: Exception) {
        }
        try {
            registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { readBattery(it) }
        } catch (_: Exception) {
        }
        readSaver()
        startTelephony()

        lastRotation = rotation()
        try {
            getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, main)
        } catch (_: Exception) {
        }

        screenOn = try { getSystemService(PowerManager::class.java).isInteractive } catch (_: Exception) { true }
        addBar()
        if (screenOn) { main.post(ticker); main.post(inkTicker) }
        main.postDelayed({ syncStock() }, 300)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        if (instance === this) instance = null
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        stopTelephony()
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener) } catch (_: Exception) {}
        if (::wm.isInitialized) removeBar()
        owner.destroy()
        // never leave the phone without a status bar: give the phone's own one back
        scope.launch { Shell.setStatusBarHidden(false) }
        super.onDestroy()
    }

    /* ---------- foreground notification ---------- */

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("cc_statusbar", "Status bar", NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_SETTINGS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, "cc_statusbar")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Custom status bar is on")
            .setContentText("Tap for settings")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 2, n, type)
    }

    /* ---------- settings ---------- */

    private fun loadPrefs() {
        val p = getSharedPreferences("cc", Context.MODE_PRIVATE)
        data.showSpeed = p.getBoolean("cs_speed", true)
        data.showNotif = p.getBoolean("cs_notif", true)
        data.showVolte = p.getBoolean("cs_volte", true)
        data.black = false   // always fully transparent: no dark background or shadow
        autoInk = p.getBoolean("cs_autoink", true)
        manualDark = p.getBoolean("cs_darkink", false)
        if (!autoInk) data.dark = manualDark
        lastT = 0L
    }

    /* ---------- the phone's own status bar ---------- */

    /**
     * Hides the phone's own bar (and shows this one) while the screen is on and the phone is unlocked.
     * On the lock screen and while the screen is off the phone's own bar is given back.
     */
    private fun syncStock() {
        if (instance !== this) return
        val kg = getSystemService(KeyguardManager::class.java)
        val locked = try { kg?.isKeyguardLocked == true } catch (_: Exception) { false }
        val hide = screenOn && !locked && !isLandscape()
        if (!hide) data.active = false
        scope.launch {
            val ok = Shell.setStatusBarHidden(hide)
            main.post { if (instance === this@StatusBarService) data.active = hide && ok }
        }
    }

    private fun onScreen(on: Boolean) {
        screenOn = on
        main.removeCallbacks(ticker)
        main.removeCallbacks(inkTicker)
        if (on) {
            lastT = 0L
            main.post(ticker)
            main.post(inkTicker)
            main.postDelayed({ syncStock() }, 600)
        } else {
            data.active = false
            scope.launch { Shell.setStatusBarHidden(false) }
        }
    }

    /* ---------- the bar window ---------- */

    private fun rotation(): Int = try {
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
    } catch (_: Exception) {
        Surface.ROTATION_0
    }

    /** True while the screen is wider than it is tall (phone turned sideways). */
    @Suppress("DEPRECATION")
    private fun isLandscape(): Boolean = try {
        val dm = android.util.DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.getRealMetrics(dm)
        dm.widthPixels > dm.heightPixels
    } catch (_: Exception) {
        false
    }

    private fun statusHeight(): Int {
        val land = rotation() == Surface.ROTATION_90 || rotation() == Surface.ROTATION_270
        var id = resources.getIdentifier(if (land) "status_bar_height_landscape" else "status_bar_height_portrait", "dimen", "android")
        if (id <= 0) id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else (24 * resources.displayMetrics.density).toInt()
    }

    private fun updatePads() {
        val density = resources.displayMetrics.density
        var l = 0
        var r = 0
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val c = wm.currentWindowMetrics.windowInsets.displayCutout
                l = c?.safeInsetLeft ?: 0
                r = c?.safeInsetRight ?: 0
            } catch (_: Throwable) {
            }
        }
        data.padStart = maxOf(16f, l / density + 6f)
        data.padEnd = maxOf(16f, r / density + 6f)
    }

    private fun removeBar() {
        val v = bar ?: return
        bar = null
        try { v.disposeComposition() } catch (_: Exception) {}
        try { wm.removeViewImmediate(v) } catch (_: Exception) {}
    }

    private fun addBar() {
        removeBar()
        updatePads()
        val cv = ComposeView(ContextThemeWrapper(this, R.style.Theme_ControlCenter))
        cv.setViewTreeLifecycleOwner(owner)
        cv.setViewTreeSavedStateRegistryOwner(owner)
        cv.setViewTreeViewModelStoreOwner(owner)
        cv.setContent { StatusBarContent(data) }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, statusHeight(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            wm.addView(cv, lp)
            bar = cv
        } catch (_: Exception) {
        }
    }

    /* ---------- live values ---------- */

    private fun tick() {
        // Shizuku went away: the phone's own bar is back by itself, so this one must not be drawn as well
        if (data.active && !Shell.ready) data.active = false
        readClock()
        readAlarm()
        readNetwork()
        readSpeed()
    }

    private var lumaBusy = false
    private var autoInk = true
    private var manualDark = false

    /**
     * Looks at the strip of the screen behind the bar: on a light app the bar turns dark, on a dark app it
     * stays white. Two thresholds so it does not flicker on mid-grey backgrounds.
     */
    private fun readBackground() {
        if (!autoInk) { data.dark = manualDark; return }
        if (lumaBusy || !data.active || !screenOn) return
        lumaBusy = true
        val rows = statusHeight()
        scope.launch {
            val l = Shell.barLuma(rows)
            var light = -1
            var dbg = "screencap luma=$l"
            if (l < 0) {
                // screencap is blocked on some phones: ask the system whether the app asked for dark icons
                // (APPEARANCE_LIGHT_STATUS_BARS = 0x8), which light apps set themselves
                val (_, out) = Shell.exec("dumpsys window | grep -i -E 'appearance|lightstatus' | head -8")
                val m = Regex("(?i)appearance\\w*\\s*[=:]\\s*(?:0x)?([0-9a-f]+)").find(out)
                if (m != null) {
                    val v = m.groupValues[1].toLongOrNull(16) ?: -1L
                    if (v >= 0) light = if ((v and 0x8L) != 0L) 1 else 0
                }
                dbg = "screencap failed; dumpsys=" + out.trim().replace('\n', ' ').take(160)
            }
            try { getSharedPreferences("cc", Context.MODE_PRIVATE).edit().putString("cs_dbg", dbg).apply() } catch (_: Throwable) {}
            main.post {
                lumaBusy = false
                if (l >= 0) data.dark = if (l > 150) true else if (l < 105) false else data.dark
                else if (light >= 0) data.dark = light == 1
            }
        }
    }

    private fun readClock() {
        val p = getSharedPreferences("cc", Context.MODE_PRIVATE)
        val is24 = p.getBoolean("clock24", android.text.format.DateFormat.is24HourFormat(this))
        data.time = android.text.format.DateFormat.format(if (is24) "HH:mm" else "h:mm", System.currentTimeMillis()).toString()
    }

    private fun readAlarm() {
        data.alarm = try {
            getSystemService(AlarmManager::class.java).nextAlarmClock != null
        } catch (_: Throwable) {
            false
        }
    }

    private fun readBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (lvl >= 0 && scale > 0) data.battery = (lvl * 100f / scale).roundToInt().coerceIn(0, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        data.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun readSaver() {
        data.saver = try { getSystemService(PowerManager::class.java).isPowerSaveMode } catch (_: Throwable) { false }
    }

    /** Mobile signal bars and network type update the moment the modem reports a change (no waiting for the 1-2 s poll). */
    @Suppress("DEPRECATION")
    private fun startTelephony() {
        try {
            val tm = getSystemService(TelephonyManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : android.telephony.TelephonyCallback(),
                    android.telephony.TelephonyCallback.SignalStrengthsListener,
                    android.telephony.TelephonyCallback.DisplayInfoListener {
                    override fun onSignalStrengthsChanged(signalStrength: android.telephony.SignalStrength) {
                        main.post { readNetwork() }
                    }
                    override fun onDisplayInfoChanged(telephonyDisplayInfo: android.telephony.TelephonyDisplayInfo) {
                        overrideNet = telephonyDisplayInfo.overrideNetworkType
                        main.post { readNetwork() }
                    }
                }
                tm.registerTelephonyCallback(ContextCompat.getMainExecutor(this), cb)
                telCallback = cb
            } else {
                val l = object : android.telephony.PhoneStateListener() {
                    override fun onSignalStrengthsChanged(signalStrength: android.telephony.SignalStrength?) {
                        main.post { readNetwork() }
                    }
                    override fun onServiceStateChanged(serviceState: android.telephony.ServiceState?) {
                        main.post { readNetwork() }
                    }
                }
                tm.listen(l, android.telephony.PhoneStateListener.LISTEN_SIGNAL_STRENGTHS or
                    android.telephony.PhoneStateListener.LISTEN_SERVICE_STATE)
                telListener = l
            }
        } catch (_: Throwable) {
            // needs the Phone permission (given through Shizuku); the 1-2 s poll still works without it
        }
    }

    @Suppress("DEPRECATION")
    private fun stopTelephony() {
        try {
            val tm = getSystemService(TelephonyManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= 31) (telCallback as? android.telephony.TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            else (telListener as? android.telephony.PhoneStateListener)?.let { tm.listen(it, android.telephony.PhoneStateListener.LISTEN_NONE) }
        } catch (_: Throwable) {
        }
        telCallback = null
        telListener = null
    }

    @Suppress("DEPRECATION")
    private fun wifiLevel(): Int = try {
        val w = applicationContext.getSystemService(WifiManager::class.java)
        val rssi = w.connectionInfo?.rssi ?: -100
        WifiManager.calculateSignalLevel(rssi, 5).coerceIn(0, 4)
    } catch (_: Throwable) {
        2
    }

    private fun netLabel(t: Int): String = when (t) {
        20 -> "5G"                                  // NETWORK_TYPE_NR
        19 -> "4G+"                                 // NETWORK_TYPE_LTE_CA
        13 -> "4G"                                  // NETWORK_TYPE_LTE
        3, 8, 9, 10, 15, 17 -> "3G"                 // UMTS, HSDPA, HSUPA, HSPA, HSPAP, TD-SCDMA
        5, 6, 12, 14 -> "3G"                        // EVDO 0 / A / B, EHRPD
        1, 2, 4, 7, 11 -> "2G"                      // GPRS, EDGE, CDMA, 1xRTT, IDEN
        else -> ""
    }

    private fun readNetwork() {
        val cm = getSystemService(ConnectivityManager::class.java)
        val onWifi = try {
            cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (_: Throwable) {
            false
        }
        data.wifiLevel = if (onWifi) wifiLevel() else -1

        val tm = getSystemService(TelephonyManager::class.java) ?: return
        val hasSim = try { tm.simState == TelephonyManager.SIM_STATE_READY } catch (_: Throwable) { false }
        if (!hasSim) {
            data.signal = 0
            data.netType = ""
            data.volte = false
            return
        }
        data.signal = try {
            if (Build.VERSION.SDK_INT >= 28) (tm.signalStrength?.level ?: 0) else 0
        } catch (_: Throwable) {
            0
        }
        // these two need "Phone" permission: it is given through Shizuku when the status bar is switched on
        val dn = try { tm.dataNetworkType } catch (_: Throwable) { 0 }
        // 3 = NR NSA, 4 = NR advanced (5G shown on top of an LTE anchor)
        data.netType = if (overrideNet == 3 || overrideNet == 4) "5G" else netLabel(dn)
        val vn = try { tm.voiceNetworkType } catch (_: Throwable) { 0 }
        data.volte = vn == 13 || vn == 19
    }

    private fun formatSpeed(bytesPerSec: Double): Pair<String, String> {
        val kb = bytesPerSec / 1024.0
        if (kb < 1000.0) {
            val f = if (kb < 10.0) "%.2f" else if (kb < 100.0) "%.1f" else "%.0f"
            return f.format(Locale.US, kb) to "KB/s"
        }
        val mb = kb / 1024.0
        return (if (mb < 10.0) "%.2f" else "%.1f").format(Locale.US, mb) to "MB/s"
    }

    private fun readSpeed() {
        if (!data.showSpeed) return
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx < 0 || tx < 0) return
        val now = SystemClock.elapsedRealtime()
        if (lastT != 0L && now > lastT) {
            val secs = (now - lastT) / 1000.0
            val dr = (rx - lastRx).coerceAtLeast(0L) / secs
            val dt = (tx - lastTx).coerceAtLeast(0L) / secs
            val (num, unit) = formatSpeed(dr + dt)
            data.speed = num
            data.speedUnit = unit
            data.down = dr > 512.0
            data.up = dt > 512.0
        }
        lastRx = rx
        lastTx = tx
        lastT = now
    }

    /** Lifecycle / saved state / view model owner that a ComposeView needs outside an Activity. */
    private class BarOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = store

        init {
            controller.performAttach()
            controller.performRestore(null)
            registry.currentState = Lifecycle.State.CREATED
        }

        fun resume() {
            registry.currentState = Lifecycle.State.RESUMED
        }

        fun destroy() {
            registry.currentState = Lifecycle.State.DESTROYED
            store.clear()
        }
    }

    companion object {
        private const val INK_INTERVAL_MS = 200L

        @Volatile
        var running = false
            private set

        @Volatile
        var instance: StatusBarService? = null
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, StatusBarService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, StatusBarService::class.java))
        }

        /** The pull-down panel opened / closed (called by OverlayService, main thread). */
        fun panelOpen(open: Boolean) {
            val s = instance ?: return
            s.data.panel = open
            if (open) {
                // The panel is a later overlay window, so it would cover the bar: add the bar again after the
                // panel is on screen so it sits on top (a few tries because the panel shows with a small delay).
                for (ms in longArrayOf(60L, 200L, 450L)) {
                    s.main.postDelayed({
                        if (instance === s && s.data.panel && s.data.active) s.addBar()
                    }, ms)
                }
            }
        }

        /** A status bar setting changed: read the settings again and redraw. */
        fun reload() {
            val s = instance ?: return
            s.main.post { s.loadPrefs(); s.tick() }
        }

        /** Shizuku (re)connected: hide the phone's own bar again. */
        fun onShizukuReady() {
            val s = instance ?: return
            s.main.post { s.syncStock() }
        }
    }
}
