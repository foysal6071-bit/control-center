package com.controlcenter.app

import android.app.Application

class CCApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Shell.init(this)
    }
}
