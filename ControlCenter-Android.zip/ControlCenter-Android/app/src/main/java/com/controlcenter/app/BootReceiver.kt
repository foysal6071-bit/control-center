package com.controlcenter.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Brings the pull-down trigger back after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = i.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val p = c.getSharedPreferences("cc", Context.MODE_PRIVATE)
        if (p.getBoolean("overlay_on", false) && Settings.canDrawOverlays(c)) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
