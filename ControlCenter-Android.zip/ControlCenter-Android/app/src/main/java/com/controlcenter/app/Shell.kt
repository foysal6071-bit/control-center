package com.controlcenter.app

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/**
 * The one door to Shizuku. Every toggle in the app calls [exec]; the pull-down lock calls
 * [setStatusBarLocked]. Compose can observe [state].
 */
object Shell {

    enum class State { NotRunning, NoPermission, Connecting, Ready }

    var state by mutableStateOf(State.NotRunning)
        private set

    /** True when the user pressed "Deny and don't ask again" - the permission must then be given inside Shizuku. */
    var deniedForever by mutableStateOf(false)
        private set

    val ready: Boolean get() = state == State.Ready && svc != null

    private const val REQ = 4601
    private var svc: IUserService? = null
    private lateinit var app: Application
    private val main = Handler(Looper.getMainLooper())
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(a: Application) {
        app = a
        Shizuku.addBinderReceivedListenerSticky { main.post { evaluate() } }
        Shizuku.addBinderDeadListener {
            main.post {
                svc = null
                state = State.NotRunning
            }
        }
        Shizuku.addRequestPermissionResultListener { _, _ -> main.post { evaluate() } }
    }

    /** Re-checks Shizuku (running? permission? service bound?). Cheap, call it on resume. */
    fun evaluate() {
        try {
            if (!Shizuku.pingBinder()) {
                svc = null
                state = State.NotRunning
                return
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                state = State.NoPermission
                return
            }
            if (svc != null) state = State.Ready
            else if (state != State.Connecting) bind()
        } catch (_: Throwable) {
            state = State.NotRunning
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                deniedForever = true
                return
            }
            Shizuku.requestPermission(REQ)
        } catch (_: Throwable) {
        }
    }

    fun launchShizukuApp(ctx: Context): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api") ?: return false
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder == null || !binder.pingBinder()) return
            svc = IUserService.Stub.asInterface(binder)
            state = State.Ready
            onReady()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            state = if (try { Shizuku.pingBinder() } catch (_: Throwable) { false }) State.Connecting else State.NotRunning
        }
    }

    private fun bind() {
        state = State.Connecting
        try {
            val ver = PackageInfoCompat.getLongVersionCode(app.packageManager.getPackageInfo(app.packageName, 0)).toInt()
            val args = Shizuku.UserServiceArgs(ComponentName(app.packageName, ShellService::class.java.name))
                .processNameSuffix("shell")
                .daemon(true)
                .version(ver)
                .tag("controlcenter-shell")
            Shizuku.bindUserService(args, conn)
        } catch (_: Throwable) {
            state = State.NotRunning
        }
    }

    /** Once connected, put back the pull-down lock the user had switched on. */
    private fun onReady() {
        val p = app.getSharedPreferences("cc", Context.MODE_PRIVATE)
        if (p.getBoolean("lock_stock", false) && p.getBoolean("overlay_on", false)) {
            io.launch { setStatusBarLocked(true) }
        }
    }

    /** Runs a shell command as the shell user. Returns exit code and output. */
    suspend fun exec(cmd: String): Pair<Int, String> = withContext(Dispatchers.IO) {
        val s = svc ?: return@withContext -1 to "Shizuku not ready"
        try {
            val raw = s.exec(cmd)
            val i = raw.indexOf('\n')
            if (i < 0) -1 to raw else (raw.substring(0, i).trim().toIntOrNull() ?: -1) to raw.substring(i + 1)
        } catch (t: Throwable) {
            if (t is android.os.DeadObjectException) {
                svc = null
                main.post { evaluate() }
            }
            -1 to (t.message ?: "error")
        }
    }

    /** Locks / unlocks the phone's own notification panel and quick settings. */
    suspend fun setStatusBarLocked(locked: Boolean): Boolean = withContext(Dispatchers.IO) {
        val s = svc ?: return@withContext false
        try {
            s.setStatusBarLocked(locked)
        } catch (_: Throwable) {
            false
        }
    }
}
