package com.controlcenter.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.controlcenter.app.OverlayService
import com.controlcenter.app.Shell
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val BG = Color(0xFF0D1015)
private val CARD = Color(0xFF1A1F2A)
private val DIM = Color(0xB3FFFFFF)

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val prefs = remember { ctx.getSharedPreferences("cc", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var overlayPerm by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    var overlayOn by remember { mutableStateOf(prefs.getBoolean("overlay_on", false) && Settings.canDrawOverlays(ctx)) }
    var lockOn by remember { mutableStateOf(prefs.getBoolean("lock_stock", false)) }
    var msg by remember { mutableStateOf("") }

    DisposableEffect(activity) {
        Shell.evaluate()
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                overlayPerm = Settings.canDrawOverlays(ctx)
                Shell.evaluate()
            }
        }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            if (Shell.ready) scope.launch { Shell.exec("pm grant ${ctx.packageName} android.permission.POST_NOTIFICATIONS") }
            else notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun setOverlay(on: Boolean) {
        scope.launch {
            if (on) {
                if (!Settings.canDrawOverlays(ctx) && Shell.ready) {
                    Shell.exec("appops set ${ctx.packageName} SYSTEM_ALERT_WINDOW allow")
                    delay(400)
                }
                if (!Settings.canDrawOverlays(ctx)) {
                    msg = "“Display over other apps” অনুমতি দিন, তারপর ফিরে এসে আবার চালু করুন।"
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                    return@launch
                }
                overlayPerm = true
                askNotificationPermission()
                prefs.edit().putBoolean("overlay_on", true).apply()
                overlayOn = true
                OverlayService.start(ctx)
                msg = "চালু হয়েছে। স্ক্রিনের একদম উপর থেকে নিচে টানুন।"
            } else {
                // switch the lock off first so the phone is never left without a pull-down
                if (lockOn) {
                    Shell.setStatusBarLocked(false)
                    lockOn = false
                    prefs.edit().putBoolean("lock_stock", false).apply()
                }
                prefs.edit().putBoolean("overlay_on", false).apply()
                overlayOn = false
                OverlayService.stop(ctx)
                msg = ""
            }
        }
    }

    fun setLock(on: Boolean) {
        scope.launch {
            val ok = Shell.setStatusBarLocked(on)
            if (ok) {
                lockOn = on
                prefs.edit().putBoolean("lock_stock", on).apply()
                msg = if (on) "ফোনের নিজস্ব Notification panel ও Control Center এখন লক।" else "ফোনের নিজস্ব pull-down আবার চালু।"
            } else {
                msg = "এই ফোনে লক করা গেল না। (Shizuku চালু আছে কি?)"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(
            Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onBack) { Text("←") }
                Text("Settings", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }

            /* ---- Shizuku ---- */
            Card("Shizuku") {
                val (text, ok) = when (Shell.state) {
                    Shell.State.Ready -> "সংযুক্ত ✓  Wi-Fi, Mobile data, Airplane, Bluetooth, Hotspot, Focus (DND), Rotation ও Brightness এখন Shizuku দিয়ে চলবে।" to true
                    Shell.State.Connecting -> "Shizuku এর সাথে সংযোগ হচ্ছে…" to false
                    Shell.State.NoPermission ->
                        (if (Shell.deniedForever) "Permission আগে “Deny” করা হয়েছে। Shizuku অ্যাপ → Authorized apps থেকে Control Center কে অনুমতি দিন।"
                        else "Shizuku চলছে, কিন্তু এই অ্যাপকে অনুমতি দেওয়া হয়নি।") to false
                    Shell.State.NotRunning -> "Shizuku চালু নেই। Shizuku অ্যাপ খুলে Start চাপুন (Wireless debugging বা root দিয়ে)।" to false
                }
                Text(text, color = if (ok) Color(0xFF34C759) else DIM, fontSize = 14.sp)
                when (Shell.state) {
                    Shell.State.NoPermission -> if (!Shell.deniedForever) {
                        Button(onClick = { Shell.requestPermission() }) { Text("অনুমতি দিন") }
                    } else {
                        Button(onClick = { if (!Shell.launchShizukuApp(ctx)) msg = "Shizuku ইনস্টল করা নেই।" }) { Text("Shizuku খুলুন") }
                    }
                    Shell.State.NotRunning ->
                        Button(onClick = { if (!Shell.launchShizukuApp(ctx)) msg = "Shizuku ইনস্টল করা নেই।" }) { Text("Shizuku খুলুন") }
                    else -> {}
                }
            }

            /* ---- pull-down ---- */
            Card("আমার Control Center") {
                SwitchRow(
                    "উপর থেকে টানলে আমার Control Center",
                    "স্ক্রিনের একদম উপরের অংশ থেকে নিচে টানলে যেকোনো অ্যাপের উপর এটি নামবে।",
                    overlayOn, true
                ) { setOverlay(it) }
                if (!overlayPerm && !overlayOn) {
                    Text("“Display over other apps” অনুমতি লাগবে। Shizuku সংযুক্ত থাকলে নিজে থেকেই দেওয়া হবে।", color = DIM, fontSize = 12.sp)
                }
            }

            Card("ফোনের আসল pull-down লক") {
                SwitchRow(
                    "Notification panel ও আসল Control Center লক",
                    "চালু থাকলে ফোনের নিজস্ব panel নামবে না, শুধু আমার Control Center নামবে।",
                    lockOn, Shell.ready && overlayOn
                ) { setLock(it) }
                if (!overlayOn) Text("আগে উপরের “আমার Control Center” চালু করুন।", color = DIM, fontSize = 12.sp)
                else if (!Shell.ready) Text("Shizuku সংযুক্ত না থাকলে লক করা যায় না।", color = DIM, fontSize = 12.sp)
                Text(
                    "লক ফোন রিস্টার্ট দিলে বা Shizuku বন্ধ হলে খুলে যায়। Shizuku আবার চালু হলে অ্যাপ নিজে লক ফিরিয়ে আনে। " +
                        "আটকে গেলে এই অ্যাপ খুলে সুইচ বন্ধ করুন।",
                    color = DIM, fontSize = 12.sp
                )
            }

            Card("ব্যাকগ্রাউন্ড") {
                Text("সিস্টেম যেন অ্যাপটি বন্ধ না করে দেয়, তার জন্য battery optimization থেকে বাদ দিন।", color = DIM, fontSize = 13.sp)
                OutlinedButton(
                    enabled = Shell.ready,
                    onClick = {
                        scope.launch {
                            val (c, _) = Shell.exec("cmd deviceidle whitelist +${ctx.packageName}")
                            msg = if (c == 0) "Battery optimization থেকে বাদ দেওয়া হয়েছে।" else "করা গেল না।"
                        }
                    }
                ) { Text("Battery optimization বন্ধ") }
            }

            if (msg.isNotEmpty()) Text(msg, color = Color(0xFF7DB4FF), fontSize = 13.sp)

            Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Control Center দেখুন") }
            Box(Modifier.padding(8.dp))
        }
    }
}

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(CARD, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(sub, color = DIM, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
