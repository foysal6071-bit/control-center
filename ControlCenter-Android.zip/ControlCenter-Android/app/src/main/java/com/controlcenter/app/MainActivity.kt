package com.controlcenter.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.controlcenter.app.ui.ControlCenterApp
import com.controlcenter.app.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    private var showSettings by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        showSettings = intent?.getBooleanExtra(EXTRA_SETTINGS, false) == true
        setContent {
            if (showSettings) {
                BackHandler { showSettings = false }
                SettingsScreen(onBack = { showSettings = false })
            } else {
                ControlCenterApp(onOpenSettings = { showSettings = true })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_SETTINGS, false)) showSettings = true
    }

    companion object {
        const val EXTRA_SETTINGS = "open_settings"
    }
}
