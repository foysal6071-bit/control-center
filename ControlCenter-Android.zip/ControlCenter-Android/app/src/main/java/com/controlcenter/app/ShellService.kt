package com.controlcenter.app

import android.os.Binder
import android.os.IBinder
import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku "user service" process, which has the privileges of the adb shell.
 * Everything that a normal app cannot do (Wi-Fi, data, airplane, Bluetooth, DND, status bar lock)
 * is done from here.
 */
class ShellService : IUserService.Stub() {

    /** Status bar disable flags stay active as long as this token (= this process) is alive. */
    private val token: IBinder = Binder()

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(cmd: String): String {
        return try {
            val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
            val killer = Thread {
                try {
                    Thread.sleep(20_000)
                    p.destroyForcibly()
                } catch (_: InterruptedException) {
                }
            }.apply { isDaemon = true; start() }
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            killer.interrupt()
            "$code\n$out"
        } catch (t: Throwable) {
            "-1\n${t.message}"
        }
    }

    override fun setStatusBarLocked(locked: Boolean): Boolean {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "statusbar") as IBinder
            val stub = Class.forName("com.android.internal.statusbar.IStatusBarService\$Stub")
            val svc = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!

            // StatusBarManager.DISABLE_EXPAND  = 0x00010000
            // StatusBarManager.DISABLE2_QUICK_SETTINGS = 1, DISABLE2_NOTIFICATION_SHADE = 1 shl 2
            val what = if (locked) 0x00010000 else 0
            val what2 = if (locked) (1 or 4) else 0

            val ok1 = call(svc, "disable", what)
            call(svc, "disable2", what2)
            ok1
        } catch (t: Throwable) {
            false
        }
    }

    private fun call(svc: Any, name: String, what: Int): Boolean {
        val c = svc.javaClass
        val int = Int::class.javaPrimitiveType
        try {
            c.getMethod(name, int, IBinder::class.java, String::class.java).invoke(svc, what, token, "com.android.shell")
            return true
        } catch (_: NoSuchMethodException) {
        } catch (_: Throwable) {
            return false
        }
        // newer Android versions only have the "ForUser" variants
        return try {
            c.getMethod(name + "ForUser", int, IBinder::class.java, String::class.java, int)
                .invoke(svc, what, token, "com.android.shell", 0)
            true
        } catch (_: Throwable) {
            false
        }
    }
}
