package com.controlcenter.app

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.database.ContentObserver
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * All real device behaviour lives here. Where Android does not let an app change a system
 * setting (airplane mode, Wi-Fi, hotspot, ...), the control opens the matching system screen
 * instead of faking a result.
 */
class Controller(private val ctx: Context, private val scope: CoroutineScope) {

    private val activity: Activity? = ctx.findActivity()
    private val prefs = ctx.getSharedPreferences("cc", Context.MODE_PRIVATE)
    private val cm = ctx.getSystemService(ConnectivityManager::class.java)
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val camMgr = ctx.getSystemService(CameraManager::class.java)
    private val wifiMgr = ctx.applicationContext.getSystemService(WifiManager::class.java)

    /* ---------- observable state ---------- */
    var airplane by mutableStateOf(false)
    var online by mutableStateOf(false)
    var wifi by mutableStateOf(false)
    var cell by mutableStateOf(false)

    /** Real on/off state of the switches (Wi-Fi radio, mobile data, hotspot) - read live, changed through Shizuku. */
    var wifiOn by mutableStateOf(false)
    var dataOn by mutableStateOf(false)
    var hotspot by mutableStateOf(false)
    var bluetooth by mutableStateOf(false)
    var batteryLevel by mutableFloatStateOf(1f)
    var charging by mutableStateOf(false)
    var torch by mutableStateOf(false)
    var locked by mutableStateOf(false)
    var focus by mutableStateOf(prefs.getBoolean("focus", false))
    var brightness by mutableFloatStateOf(if (Shell.ready) systemBrightness() else prefs.getFloat("brightness", systemBrightness()))
    var volume by mutableFloatStateOf(0.5f)

    var toastText by mutableStateOf("")
    var toastTick by mutableIntStateOf(0)

    var nowPlaying by mutableStateOf("Not Playing")
    var playing by mutableStateOf(false)
    var onPickAudio: () -> Unit = {}

    /** Called after a system screen / another app was opened (the overlay panel closes itself then). */
    var onLaunched: () -> Unit = {}

    var qrResult by mutableStateOf<String?>(null)

    var timerMin by mutableIntStateOf(prefs.getInt("timerMin", 5))
    var timerEnd by mutableLongStateOf(prefs.getLong("timerEnd", 0L))
    var timerNow by mutableLongStateOf(System.currentTimeMillis())
    val timerRunning: Boolean get() = timerEnd > 0L

    /* ---------- toast (muted while Focus is on) ---------- */
    fun say(msg: String, force: Boolean = false) {
        if (!force && focus) return
        toastText = msg
        toastTick++
    }

    /* ---------- lifecycle ---------- */
    private var torchId: String? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var torchCb: CameraManager.TorchCallback? = null
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val intent = i ?: return
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> readBattery(intent)
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> readAirplane()
                BluetoothAdapter.ACTION_STATE_CHANGED -> readBluetooth()
                WifiManager.WIFI_STATE_CHANGED_ACTION -> readWifi()
                "android.media.VOLUME_CHANGED_ACTION" -> readVolume()
            }
        }
    }

    private val settingsObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            readAirplane(); readData(); readZen(); readRotation()
        }
    }

    private val resumeObserver = LifecycleEventObserver { _, e ->
        if (e == Lifecycle.Event.ON_RESUME) refresh()
    }

    fun start() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction("android.media.VOLUME_CHANGED_ACTION")
        }
        try {
            ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        } catch (_: Exception) {
        }
        try {
            ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { readBattery(it) }
        } catch (_: Exception) {
        }

        try {
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) = updateNet(cm.getNetworkCapabilities(network))
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = updateNet(caps)
                override fun onLost(network: Network) = updateNet(null)
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
            updateNet(cm.getNetworkCapabilities(cm.activeNetwork))
        } catch (_: Exception) {
        }

        try {
            val id = camMgr.cameraIdList.firstOrNull { cid ->
                val c = camMgr.getCameraCharacteristics(cid)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            torchId = id
            val tcb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) torch = enabled
                }
            }
            camMgr.registerTorchCallback(tcb, null)
            torchCb = tcb
        } catch (_: Exception) {
        }

        try {
            val cr = ctx.contentResolver
            cr.registerContentObserver(Settings.Global.getUriFor("mobile_data"), false, settingsObserver)
            cr.registerContentObserver(Settings.Global.getUriFor("zen_mode"), false, settingsObserver)
            cr.registerContentObserver(Settings.Global.getUriFor(Settings.Global.AIRPLANE_MODE_ON), false, settingsObserver)
            cr.registerContentObserver(Settings.System.getUriFor(Settings.System.ACCELEROMETER_ROTATION), false, settingsObserver)
        } catch (_: Exception) {
        }

        (activity as? LifecycleOwner)?.lifecycle?.addObserver(resumeObserver)
        refresh()
        if (!Shell.ready && prefs.contains("brightness")) applyBrightness()
    }

    fun stop() {
        (activity as? LifecycleOwner)?.lifecycle?.removeObserver(resumeObserver)
        try { if (registered) ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
        try { ctx.contentResolver.unregisterContentObserver(settingsObserver) } catch (_: Exception) {}
        registered = false
        try { netCb?.let { cm.unregisterNetworkCallback(it) } } catch (_: Exception) {}
        netCb = null
        try { torchCb?.let { camMgr.unregisterTorchCallback(it) } } catch (_: Exception) {}
        torchCb = null
        releasePlayer()
    }

    fun refresh() {
        readAirplane(); readBluetooth(); readVolume()
        readWifi(); readData(); readZen(); readRotation(); readSystemBrightness()
        try { updateNet(cm.getNetworkCapabilities(cm.activeNetwork)) } catch (_: Exception) {}
    }

    /* ---------- live state readers ---------- */
    private fun updateNet(caps: NetworkCapabilities?) {
        online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        cell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    }

    private fun readWifi() {
        wifiOn = try { wifiMgr?.isWifiEnabled == true } catch (_: Exception) { false }
    }

    private fun readData() {
        dataOn = try {
            val cr = ctx.contentResolver
            var v = Settings.Global.getInt(cr, "mobile_data", -1)
            if (v < 0) v = Settings.Global.getInt(cr, "mobile_data1", 0)
            v == 1
        } catch (_: Exception) {
            false
        }
    }

    /** With Shizuku the Focus button is the real Do Not Disturb switch. */
    private fun readZen() {
        if (!Shell.ready) return
        focus = try { Settings.Global.getInt(ctx.contentResolver, "zen_mode", 0) != 0 } catch (_: Exception) { focus }
    }

    /** With Shizuku the lock button is the real auto-rotate switch of the phone. */
    private fun readRotation() {
        if (!Shell.ready) return
        locked = try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        } catch (_: Exception) {
            locked
        }
    }

    private var lastBrightSet = 0L
    private fun readSystemBrightness() {
        if (!Shell.ready) return
        if (System.currentTimeMillis() - lastBrightSet < 1500) return
        brightness = systemBrightness()
    }

    private fun readBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (lvl >= 0 && scale > 0) batteryLevel = lvl / scale.toFloat()
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun readAirplane() {
        airplane = try {
            Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        } catch (_: Exception) {
            false
        }
    }

    private fun readBluetooth() {
        bluetooth = try {
            ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        } catch (_: Exception) {
            false
        }
    }

    private fun readVolume() {
        val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (mx > 0) volume = audio.getStreamVolume(AudioManager.STREAM_MUSIC) / mx.toFloat()
    }

    /* ---------- opening system screens ---------- */
    private fun launch(intent: Intent) {
        try {
            val a = activity
            if (a != null) a.startActivity(intent)
            else ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onLaunched()
        } catch (_: Exception) {
            say("This isn’t available on your device.", true)
        }
    }

    private fun openSettings(action: String) = launch(Intent(action))

    /* ---------- toggles: real switches through Shizuku, system screen as a fallback ---------- */

    private fun put(ns: String, key: String, value: String) =
        "cmd settings put $ns $key $value || settings put $ns $key $value"

    /**
     * Flips a switch with a shell command. The button changes at once; if the command fails the
     * old state comes back. Without Shizuku the [fallback] (the matching system screen) runs.
     */
    private fun toggleVia(
        cur: Boolean, set: (Boolean) -> Unit, label: String,
        cmdOn: String, cmdOff: String, fallback: () -> Unit
    ) {
        if (!Shell.ready) {
            fallback()
            return
        }
        val want = !cur
        set(want)
        scope.launch {
            val (code, _) = Shell.exec(if (want) cmdOn else cmdOff)
            if (code != 0) {
                set(cur)
                say("Couldn’t change $label", true)
            }
            delay(800)
            refresh()
        }
    }

    fun tapAirplane() = toggleVia(
        airplane, { airplane = it }, "airplane mode",
        "cmd connectivity airplane-mode enable || (settings put global airplane_mode_on 1; am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true)",
        "cmd connectivity airplane-mode disable || (settings put global airplane_mode_on 0; am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false)"
    ) { openSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }

    fun tapWifi() = toggleVia(
        wifiOn, { wifiOn = it }, "Wi-Fi", "svc wifi enable", "svc wifi disable"
    ) {
        openSettings(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS)
    }

    fun tapCell() = toggleVia(
        dataOn, { dataOn = it }, "mobile data", "svc data enable", "svc data disable"
    ) { openSettings(Settings.ACTION_DATA_ROAMING_SETTINGS) }

    fun tapBluetooth() = toggleVia(
        bluetooth, { bluetooth = it }, "Bluetooth",
        "cmd bluetooth_manager enable || svc bluetooth enable",
        "cmd bluetooth_manager disable || svc bluetooth disable"
    ) { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }

    /** Hotspot: depends on the ROM. If the shell command is refused, the tethering screen opens. */
    fun tapHotspot() {
        if (!Shell.ready) {
            openSettings(Settings.ACTION_WIRELESS_SETTINGS)
            return
        }
        val want = !hotspot
        hotspot = want
        scope.launch {
            val (code, _) = Shell.exec(
                if (want) "cmd connectivity start-tethering wifi" else "cmd connectivity stop-tethering wifi"
            )
            if (code != 0) {
                hotspot = !want
                openSettings(Settings.ACTION_WIRELESS_SETTINGS)
            }
        }
    }

    fun tapInternet() = openSettings(
        if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
    )

    fun tapMirror() = openSettings(Settings.ACTION_CAST_SETTINGS)
    fun tapAirplay() = openSettings(
        if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_VOLUME else Settings.ACTION_CAST_SETTINGS
    )

    fun share() {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Control Center")
        launch(Intent.createChooser(i, null))
    }

    fun openCamera() = launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))

    fun refreshApp() {
        say("Refreshing…", true)
        scope.launch {
            delay(350)
            activity?.recreate()
        }
    }

    /* ---------- focus ---------- */
    fun toggleFocus() {
        if (Shell.ready) {
            val want = !focus
            focus = want
            scope.launch {
                val (code, _) = Shell.exec("cmd notification set_dnd ${if (want) "on" else "off"}")
                if (code != 0) {
                    focus = !want
                    say("Couldn’t change Do Not Disturb", true)
                }
                delay(600)
                readZen()
            }
            return
        }
        focus = !focus
        prefs.edit().putBoolean("focus", focus).apply()
        say(if (focus) "Do Not Disturb on. Messages from this app are muted." else "Do Not Disturb off", true)
    }

    /* ---------- orientation lock ---------- */
    fun toggleLock() {
        if (Shell.ready) {
            val want = !locked
            locked = want
            scope.launch {
                val (code, _) = Shell.exec(put("system", "accelerometer_rotation", if (want) "0" else "1"))
                if (code != 0) {
                    locked = !want
                    say("Couldn’t change rotation lock", true)
                }
            }
            return
        }
        val a = activity
        if (a == null) {
            say("Turn on Shizuku in Settings to lock rotation", true)
            return
        }
        locked = !locked
        a.requestedOrientation =
            if (locked) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        say(if (locked) "Orientation locked" else "Orientation lock off")
    }

    /* ---------- flashlight ---------- */
    fun toggleTorch() {
        val id = torchId
        if (id == null) {
            say("This device has no flashlight.")
            return
        }
        try {
            camMgr.setTorchMode(id, !torch)
        } catch (_: Exception) {
            say("Flashlight isn’t available right now.")
        }
    }

    /* ---------- sliders ---------- */
    private fun systemBrightness(): Float = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (_: Exception) {
        0.5f
    }

    private fun applyBrightness() {
        activity?.window?.let { w ->
            val lp = w.attributes
            lp.screenBrightness = brightness.coerceIn(0.02f, 1f)
            w.attributes = lp
        }
    }

    private var pendingBright = -1
    private var brightJob: Job? = null
    private var autoBrightOff = false

    /** With Shizuku: the real screen brightness of the phone. Without: only this app's window. */
    fun changeBrightness(p: Float) {
        brightness = p.coerceIn(0f, 1f)
        if (Shell.ready) {
            lastBrightSet = System.currentTimeMillis()
            pendingBright = (brightness * 255f).roundToInt().coerceIn(1, 255)
            if (brightJob?.isActive != true) {
                brightJob = scope.launch {
                    while (pendingBright >= 0) {
                        val v = pendingBright
                        pendingBright = -1
                        val pre = if (!autoBrightOff) {
                            autoBrightOff = true
                            put("system", "screen_brightness_mode", "0") + "; "
                        } else ""
                        Shell.exec(pre + put("system", "screen_brightness", v.toString()))
                        delay(40)
                    }
                }
            }
            return
        }
        applyBrightness()
        prefs.edit().putFloat("brightness", brightness).apply()
    }

    /** Real media volume of the phone. */
    fun changeVolume(p: Float) {
        val v = p.coerceIn(0f, 1f)
        volume = v
        try {
            val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (v * mx).roundToInt().coerceIn(0, mx), 0)
        } catch (_: Exception) {
        }
    }

    /* ---------- QR scanner ---------- */
    fun scanQr() {
        try {
            val options = GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build()
            GmsBarcodeScanning.getClient(ctx, options).startScan()
                .addOnSuccessListener { b ->
                    val v = b.rawValue ?: ""
                    if (activity != null) {
                        qrResult = v
                    } else if (v.startsWith("http://", true) || v.startsWith("https://", true)) {
                        openQrLink(v)
                    } else {
                        copy(v)
                        Toast.makeText(ctx, "Copied: $v", Toast.LENGTH_LONG).show()
                    }
                }
                .addOnFailureListener { say("The code scanner needs Google Play services.", true) }
        } catch (_: Exception) {
            say("The code scanner needs Google Play services.", true)
        }
    }

    fun openQrLink(text: String) {
        if (text.startsWith("http://", true) || text.startsWith("https://", true)) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(text)))
        }
    }

    fun copy(text: String) {
        try {
            ctx.getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("Control Center", text))
            say("Copied", true)
        } catch (_: Exception) {
        }
    }

    /* ---------- timer ---------- */
    fun timerAdjust(d: Int) {
        if (timerRunning) return
        timerMin = (timerMin + d).coerceIn(1, 180)
        prefs.edit().putInt("timerMin", timerMin).apply()
    }

    fun timerToggle() {
        if (timerRunning) {
            timerEnd = 0L
        } else {
            timerNow = System.currentTimeMillis()
            timerEnd = timerNow + timerMin * 60_000L
        }
        prefs.edit().putLong("timerEnd", timerEnd).apply()
    }

    fun tickTimer() {
        if (!timerRunning) return
        timerNow = System.currentTimeMillis()
        if (timerNow >= timerEnd) finishTimer()
    }

    private fun finishTimer() {
        timerEnd = 0L
        prefs.edit().putLong("timerEnd", 0L).apply()
        say("Timer finished", true)
        vibrate()
        scope.launch {
            try {
                val tg = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                repeat(3) {
                    tg.startTone(ToneGenerator.TONE_PROP_BEEP, 250)
                    delay(450)
                }
                tg.release()
            } catch (_: Exception) {
            }
        }
    }

    fun timerText(): String {
        val ms = if (timerRunning) timerEnd - timerNow else timerMin * 60_000L
        val s = max(0, ceil(ms / 1000.0).toInt())
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun vibrate() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200), -1))
        } catch (_: Exception) {
        }
    }

    /* ---------- now playing: your own audio files ---------- */
    private var player: MediaPlayer? = null
    private var tracks: List<Pair<String, Uri>> = emptyList()
    private var index = -1

    private fun displayName(uri: Uri): String {
        val name = try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
        return (name ?: "Track").substringBeforeLast('.')
    }

    fun setTracks(uris: List<Uri>) {
        if (uris.isEmpty()) return
        tracks = uris.map { displayName(it) to it }
        load(0)
    }

    private fun releasePlayer() {
        try { player?.release() } catch (_: Exception) {}
        player = null
        playing = false
    }

    private fun load(i: Int) {
        if (tracks.isEmpty()) return
        index = (i + tracks.size) % tracks.size
        val (name, uri) = tracks[index]
        releasePlayer()
        nowPlaying = name
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(ctx, uri)
            mp.setOnPreparedListener { it.start(); playing = true }
            mp.setOnCompletionListener { if (tracks.size > 1) load(index + 1) else playing = false }
            mp.setOnErrorListener { _, _, _ ->
                playing = false
                say("Can’t play this file", true)
                true
            }
            mp.prepareAsync()
            player = mp
        } catch (_: Exception) {
            say("Can’t play this file", true)
        }
    }

    fun togglePlay() {
        val mp = player
        if (mp == null || tracks.isEmpty()) {
            onPickAudio()
            return
        }
        try {
            if (mp.isPlaying) {
                mp.pause(); playing = false
            } else {
                mp.start(); playing = true
            }
        } catch (_: Exception) {
        }
    }

    fun prev() {
        val mp = player
        if (mp == null || tracks.isEmpty()) {
            say("Tap play to choose music"); return
        }
        try {
            if (mp.currentPosition > 3000) mp.seekTo(0) else load(index - 1)
        } catch (_: Exception) {
        }
    }

    fun next() {
        if (tracks.isEmpty()) {
            say("Tap play to choose music"); return
        }
        load(index + 1)
    }
}
