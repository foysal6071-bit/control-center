package com.controlcenter.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp

/** Tiny vector-icon model that reuses the SVG path data of the web version (24 x 24 view box). */
sealed interface El {
    val fill: Boolean
    val sw: Float
    val color: Color?
}

data class Pa(
    val d: String,
    override val fill: Boolean = false,
    override val sw: Float = 2f,
    override val color: Color? = null
) : El

data class Ci(
    val cx: Float, val cy: Float, val r: Float,
    override val fill: Boolean = true,
    override val sw: Float = 2f,
    override val color: Color? = null
) : El

data class Re(
    val x: Float, val y: Float, val w: Float, val h: Float, val rx: Float,
    override val fill: Boolean = true,
    override val sw: Float = 2f,
    override val color: Color? = null
) : El

@Composable
fun SvgIcon(els: List<El>, dp: Dp, tint: Color, modifier: Modifier = Modifier) {
    val paths = remember(els) {
        els.map { if (it is Pa) PathParser().parsePathString(it.d).toPath() else null }
    }
    Canvas(modifier.size(dp)) {
        val k = this.size.minDimension / 24f
        withTransform({ scale(k, k, Offset.Zero) }) {
            els.forEachIndexed { i, e ->
                val c = e.color ?: tint
                val style: DrawStyle =
                    if (e.fill) Fill else Stroke(width = e.sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
                when (e) {
                    is Pa -> drawPath(paths[i]!!, c, style = style)
                    is Ci -> drawCircle(c, radius = e.r, center = Offset(e.cx, e.cy), style = style)
                    is Re -> drawRoundRect(
                        c,
                        topLeft = Offset(e.x, e.y),
                        size = Size(e.w, e.h),
                        cornerRadius = CornerRadius(e.rx, e.rx),
                        style = style
                    )
                }
            }
        }
    }
}

@Composable
fun BatteryIcon(level: Float, charging: Boolean, w: Dp, h: Dp) {
    val bolt = remember { PathParser().parsePathString("M12.4 2.2 8.2 6.6h2.6l-.9 3.2 4.3-4.6h-2.6z").toPath() }
    Canvas(Modifier.size(w, h)) {
        val k = this.size.width / 26f
        withTransform({ scale(k, k, Offset.Zero) }) {
            drawRoundRect(
                Color.White.copy(alpha = 0.5f), Offset(0.6f, 0.6f), Size(21.6f, 10.8f),
                CornerRadius(3.4f, 3.4f), style = Stroke(width = 1f)
            )
            val l = level.coerceIn(0f, 1f)
            val col = when {
                charging -> Color(0xFF34C759)
                l <= 0.2f -> Color(0xFFFF453A)
                else -> Color.White
            }
            drawRoundRect(col, Offset(2f, 2f), Size(maxOf(1.6f, 19.6f * l), 8f), CornerRadius(2f, 2f))
            if (charging) drawPath(bolt, Color(0xFF20242C))
            drawRoundRect(
                Color.White.copy(alpha = 0.5f), Offset(23.4f, 3.8f), Size(2f, 4.4f), CornerRadius(1f, 1f)
            )
        }
    }
}

object Ic {
    private val CUT_CALC = Color(0xFF9A5560)
    private val CUT_CAM = Color(0xFF3A76D6)

    val plus = listOf<El>(Pa("M12 4v16M4 12h16"))
    val power = listOf<El>(Pa("M12 3v8M6.8 6.6a8 8 0 1 0 10.4 0"))
    val close = listOf<El>(Pa("M6 6l12 12M18 6L6 18"))
    val gear = listOf<El>(
        Ci(12f, 12f, 3.2f, fill = false),
        Ci(12f, 12f, 6.8f, fill = false),
        Pa("M12 2.6v3M12 18.4v3M2.6 12h3M18.4 12h3M5.4 5.4l2.1 2.1M16.5 16.5l2.1 2.1M18.6 5.4l-2.1 2.1M7.5 16.5l-2.1 2.1")
    )

    val airplane = listOf<El>(
        Pa("M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z", fill = true)
    )
    val share = listOf<El>(
        Ci(12f, 12f, 2f),
        Pa("M8.5 15.5a5 5 0 1 1 7 0M5.5 18.5a9.2 9.2 0 1 1 13 0")
    )
    val wifi = listOf<El>(
        Pa("M2 8.8a15 15 0 0 1 20 0M5.2 12.2a10.5 10.5 0 0 1 13.6 0M8.5 15.4a6 6 0 0 1 7 0"),
        Ci(12f, 19f, 1.4f)
    )
    val cell = listOf<El>(
        Re(3f, 15f, 3.2f, 5f, 1f),
        Re(8.4f, 11f, 3.2f, 9f, 1f),
        Re(13.8f, 7f, 3.2f, 13f, 1f),
        Re(19.2f, 3f, 3.2f, 17f, 1f)
    )
    val bluetooth = listOf<El>(Pa("M7 7l10 10-5 4.5V2.5L17 7 7 17"))
    val hotspot = listOf<El>(
        Pa("M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1")
    )
    val internet = listOf<El>(
        Ci(12f, 12f, 8f, fill = false),
        Pa("M4 12h16M12 4c2.6 2.4 2.6 13.6 0 16M12 4c-2.6 2.4-2.6 13.6 0 16")
    )

    val music = listOf<El>(
        Pa("M9 17.5V6l10-2v11.5"),
        Ci(6.8f, 17.8f, 2.6f),
        Ci(16.8f, 15.8f, 2.6f)
    )
    val airplay = listOf<El>(
        Pa("M6 17H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-1"),
        Pa("M12 14l5.5 6.5h-11z", fill = true)
    )
    val prev = listOf<El>(Pa("M12.5 6v12l-8-6zM21 6v12l-8-6z", fill = true))
    val next = listOf<El>(Pa("M11.5 6v12l8-6zM3 6v12l8-6z", fill = true))
    val play = listOf<El>(Pa("M7 4v16l13-8z", fill = true))
    val pause = listOf<El>(
        Re(6f, 4f, 4.2f, 16f, 1.2f),
        Re(13.8f, 4f, 4.2f, 16f, 1.2f)
    )

    val lock = listOf<El>(
        Pa("M20 12a8 8 0 1 1-2.4-5.7M18 3.2v3.8h-3.8"),
        Re(9.2f, 11.2f, 5.6f, 4.6f, 1.1f, fill = false),
        Pa("M10.4 11.2V10a1.6 1.6 0 0 1 3.2 0v1.2")
    )
    val mirror = listOf<El>(
        Re(3f, 8.5f, 12.5f, 10f, 2.2f, fill = false),
        Re(8.5f, 5f, 12.5f, 10f, 2.2f, fill = false)
    )
    val moon = listOf<El>(Pa("M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z", fill = true))
    val chevrons = listOf<El>(Pa("M8 9l4-4 4 4M8 15l4 4 4-4"))

    val brightness = listOf<El>(
        Ci(12f, 12f, 4f),
        Pa("M12 2.5v2.4M12 19.1v2.4M2.5 12h2.4M19.1 12h2.4M5.3 5.3L7 7M17 17l1.7 1.7M5.3 18.7L7 17M17 7l1.7-1.7")
    )

    /** tier 0 = muted, 1 = one wave, 2 = two waves */
    fun volume(tier: Int): List<El> = buildList<El> {
        add(Pa("M3 9.5v5h4l5 4v-13l-5 4z", fill = true))
        if (tier >= 1) add(Pa("M15.6 9a4 4 0 0 1 0 6"))
        if (tier >= 2) add(Pa("M18.2 6.4a7.6 7.6 0 0 1 0 11.2"))
        if (tier == 0) add(Pa("M15.5 9.5l5 5M20.5 9.5l-5 5"))
    }

    val flash = listOf<El>(
        Pa("M8 2h8v4.2L14.6 8v12.6a1.4 1.4 0 0 1-1.4 1.4h-2.4a1.4 1.4 0 0 1-1.4-1.4V8L8 6.2z", fill = true),
        Re(11f, 10.5f, 2f, 3.4f, 1f, color = Color(0x993C282D))
    )
    val timer = listOf<El>(
        Ci(12f, 13.4f, 7.6f, fill = false),
        Pa("M10 2.6h4M12 13.4V9M18.6 6.6l1.4-1.4")
    )
    val calc = listOf<El>(
        Re(4.2f, 2.5f, 15.6f, 19f, 3.2f, color = Color.White),
        Re(7f, 5f, 10f, 4f, 1.2f, color = CUT_CALC),
        Re(7f, 11f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(10.7f, 11f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(14.4f, 11f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(7f, 14.7f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(10.7f, 14.7f, 2.6f, 2.6f, 0.8f, color = CUT_CALC),
        Re(14.4f, 14.7f, 2.6f, 6f, 0.8f, color = CUT_CALC),
        Re(7f, 18.4f, 6.3f, 2.4f, 0.8f, color = CUT_CALC)
    )
    val camera = listOf<El>(
        Pa(
            "M4 7.5h3l1.5-2.5h7L17 7.5h3a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H4A1.5 1.5 0 0 1 2.5 18V9A1.5 1.5 0 0 1 4 7.5z",
            fill = true, color = Color.White
        ),
        Ci(12f, 13.2f, 3.6f, color = CUT_CAM)
    )
    val qr = listOf<El>(
        Pa("M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2"),
        Re(8f, 8f, 3f, 3f, 0.6f, fill = false, sw = 1.6f),
        Re(13f, 8f, 3f, 3f, 0.6f, fill = false, sw = 1.6f),
        Re(8f, 13f, 3f, 3f, 0.6f, fill = false, sw = 1.6f),
        Ci(14.5f, 14.5f, 1.3f)
    )

    val heart = listOf<El>(
        Pa("M12 20.6s-8.2-5-8.2-11.2A4.6 4.6 0 0 1 12 7a4.6 4.6 0 0 1 8.2 2.4c0 6.2-8.2 11.2-8.2 11.2z", fill = true)
    )
    val waves = listOf<El>(
        Ci(12f, 12f, 1.8f),
        Pa("M8.2 8.2a5.4 5.4 0 0 0 0 7.6M15.8 8.2a5.4 5.4 0 0 1 0 7.6M5.2 5.2a9.6 9.6 0 0 0 0 13.6M18.8 5.2a9.6 9.6 0 0 1 0 13.6")
    )
}
