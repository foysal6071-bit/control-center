package com.controlcenter.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.controlcenter.app.Controller
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/* ---------- colours (same values as the CSS of the web version) ---------- */
private val GLASS = Color(0x57969CA8)
private val GLASS_DARK = Color(0x85242830)
private val BTN_OFF = Color(0x8C242830)
private val BLUE = Color(0xFF3D82F4)
private val ORANGE = Color(0xFFF2882F)
private val GREEN = Color(0xFF34C759)
private val RED = Color(0xFFFF453A)
private val LIGHT_ON = Color(0xE0ECEFF6)
private val DARK_INK = Color(0xFF20242C)
private val PINK = Color(0x94C4606C)

private val GLASS_BRUSH = Brush.verticalGradient(listOf(Color(0x70C4CEE2), Color(0x388892AC)))
private val RIM = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.42f), Color.White.copy(alpha = 0.05f)))

private enum class Page { None, Calc, Timer }

/** One grid unit = u dp. The layout is drawn on a 214 x 465 unit grid, exactly like the web version. */
private fun Modifier.at(u: Dp, x: Float, y: Float, w: Float, h: Float): Modifier =
    this.offset(u * x, u * y).size(u * w, u * h)

@Composable
private fun Dp.spx(): TextUnit = with(LocalDensity.current) { this@spx.toSp() }

@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.92f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "press")
    val haptic = LocalHapticFeedback.current
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, role = Role.Button) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

/** Springy staggered entrance, top row first. */
@Composable
private fun Modifier.pop(y: Float): Modifier {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay((y * 1.4f).toLong()); shown = true }
    val sc by animateFloatAsState(if (shown) 1f else 0.85f, spring(dampingRatio = 0.62f, stiffness = 360f), label = "pop")
    val al by animateFloatAsState(if (shown) 1f else 0f, tween(280), label = "popA")
    return this.graphicsLayer { scaleX = sc; scaleY = sc; alpha = al }
}

/**
 * @param onOpenSettings the gear button (top left)
 * @param onClose when not null the screen runs as the pull-down overlay: dim background, closes on
 *   swipe up / tap outside / the handle at the bottom. When null it is the normal full screen app.
 */
@Composable
fun ControlCenterApp(
    onOpenSettings: () -> Unit = {},
    onClose: (() -> Unit)? = null,
    insetTop: Dp = 0.dp,
    insetBottom: Dp = 0.dp
) {
    val overlay = onClose != null
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ctl = remember { Controller(ctx, scope) }

    DisposableEffect(ctl) {
        ctl.start()
        onDispose { ctl.stop() }
    }

    if (!overlay) {
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            ctl.setTracks(uris)
        }
        SideEffect { ctl.onPickAudio = { picker.launch(arrayOf("audio/*")) } }
    } else {
        SideEffect {
            ctl.onPickAudio = { ctl.say("Open the app to choose music", true) }
            ctl.onLaunched = { onClose?.invoke() }
        }
    }

    var page by remember { mutableStateOf(Page.None) }
    var side by remember { mutableIntStateOf(0) }
    var toastVisible by remember { mutableStateOf(false) }

    LaunchedEffect(ctl.toastTick) {
        if (ctl.toastTick > 0) {
            toastVisible = true
            delay(2400)
            toastVisible = false
        }
    }
    LaunchedEffect(ctl.timerEnd) {
        while (ctl.timerEnd > 0L) {
            ctl.tickTimer()
            delay(250)
        }
    }

    var clock by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val f = java.text.SimpleDateFormat("EEE, d MMM  •  h:mm a", java.util.Locale.getDefault())
        while (true) {
            clock = f.format(java.util.Date())
            delay(15_000)
        }
    }

    if (!overlay) {
        BackHandler(enabled = page != Page.None || ctl.qrResult != null) {
            if (ctl.qrResult != null) ctl.qrResult = null else page = Page.None
        }
    }

    /* overlay only: tap outside the grid or swipe up closes the panel */
    val closeMod = if (onClose != null) {
        Modifier
            .pointerInput(Unit) { detectTapGestures { onClose() } }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc < -size.height * 0.08f) onClose() },
                    onDragCancel = { acc = 0f }
                ) { _, dy -> acc += dy }
            }
    } else Modifier

    Box(Modifier.fillMaxSize().then(if (overlay) Modifier else Modifier.background(Color(0xFF0D1015))).then(closeMod)) {
        if (overlay) Box(Modifier.fillMaxSize().alpha(0.94f)) { Wallpaper() } else Wallpaper()
        BoxWithConstraints(
            Modifier.fillMaxSize().then(
                if (overlay) Modifier.padding(top = insetTop, bottom = insetBottom)
                else Modifier.windowInsetsPadding(WindowInsets.systemBars)
            )
        ) {
            val u = minOf(maxWidth / 214f, maxHeight / 465f)
            Box(
                Modifier.width(u * 214f).fillMaxHeight().align(Alignment.TopCenter)
                    .then(if (overlay) Modifier.pointerInput(Unit) { detectTapGestures { } } else Modifier)
            ) {

                /* top bar */
                Ctl(u, 14f, 10f, 20f, 20f, Color.Transparent, Ic.gear, 11f, "Settings") { onOpenSettings() }
                Ctl(u, 179f, 10f, 20f, 20f, Color.Transparent, Ic.power, 11f, "Refresh") { ctl.refreshApp() }

                Text(
                    clock, Modifier.at(u, 24f, 31f, 150f, 12f),
                    color = Color(0xD9FFFFFF), fontSize = (u * 7.2f).spx(), fontWeight = FontWeight.Medium, maxLines = 1
                )

                /* live status row */
                Row(
                    Modifier.at(u, 25f, 47f, 56f, 12f),
                    horizontalArrangement = Arrangement.spacedBy(u * 5f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (ctl.airplane) SvgIcon(Ic.airplane, u * 8.5f, Color.White)
                    if (ctl.wifi && !ctl.airplane) SvgIcon(Ic.wifi, u * 8.5f, Color.White)
                    if (ctl.cell && !ctl.airplane) SvgIcon(Ic.cell, u * 8.5f, Color.White)
                }
                Row(
                    Modifier.at(u, 112f, 47f, 86f, 12f),
                    horizontalArrangement = Arrangement.spacedBy(u * 5f, Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (ctl.locked) SvgIcon(Ic.lock, u * 8.5f, Color.White)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(u * 3.5f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${(ctl.batteryLevel * 100).roundToInt()}%",
                            color = Color.White, fontSize = (u * 6.8f).spx(), fontWeight = FontWeight.SemiBold, maxLines = 1
                        )
                        BatteryIcon(ctl.batteryLevel, ctl.charging, u * 13f, u * 6.4f)
                    }
                }

                /* connectivity module */
                Glass(u, 22f, 70f, 84f, 80f, 21f)
                Ctl(u, 29.5f, 77.5f, 29f, 29f, if (ctl.airplane) ORANGE else BTN_OFF, Ic.airplane, 18f, "Airplane mode") { ctl.tapAirplane() }
                Ctl(u, 73.5f, 77.5f, 29f, 29f, BLUE, Ic.share, 18f, "Share") { ctl.share() }
                Ctl(u, 29.5f, 113.5f, 29f, 29f, if (ctl.wifiOn) BLUE else BTN_OFF, Ic.wifi, 18f, "Wi-Fi") { ctl.tapWifi() }
                Ctl(u, 74f, 114f, 14f, 14f, if (ctl.dataOn) GREEN else GLASS_DARK, Ic.cell, 8f, "Mobile data") { ctl.tapCell() }
                Ctl(u, 88f, 114f, 14f, 14f, if (ctl.bluetooth) BLUE else GLASS_DARK, Ic.bluetooth, 8f, "Bluetooth") { ctl.tapBluetooth() }
                Ctl(u, 74f, 128f, 14f, 14f, if (ctl.hotspot) GREEN else GLASS_DARK, Ic.hotspot, 8f, "Personal hotspot") { ctl.tapHotspot() }
                Ctl(u, 88f, 128f, 14f, 14f, if (ctl.online) BLUE else GLASS_DARK, Ic.internet, 8f, "Internet") { ctl.tapInternet() }

                /* now playing */
                Glass(u, 112f, 70f, 83f, 80f, 21f)
                Box(
                    Modifier.at(u, 118f, 77f, 22f, 22f).background(Color(0x1AFFFFFF), RoundedCornerShape(u * 5f)),
                    contentAlignment = Alignment.Center
                ) { SvgIcon(Ic.music, u * 12f, Color(0x8CFFFFFF)) }
                Ctl(u, 171f, 78f, 20f, 20f, Color(0x33FFFFFF), Ic.airplay, 11f, "Output device") { ctl.tapAirplay() }
                Text(
                    ctl.nowPlaying,
                    Modifier.at(u, 118.5f, 111f, 68f, 16f),
                    color = Color(0xEBFFFFFF), fontSize = (u * 7.6f).spx(), fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Ctl(u, 118f, 132f, 18f, 18f, Color.Transparent, Ic.prev, 13f, "Previous", Color(0x99FFFFFF)) { ctl.prev() }
                Ctl(u, 143f, 131f, 20f, 20f, Color.Transparent, if (ctl.playing) Ic.pause else Ic.play, 14f, if (ctl.playing) "Pause" else "Play") { ctl.togglePlay() }
                Ctl(u, 171f, 132f, 18f, 18f, Color.Transparent, Ic.next, 13f, "Next", Color(0x99FFFFFF)) { ctl.next() }

                /* orientation lock + screen mirroring */
                Ctl(u, 22.5f, 160.5f, 37f, 37f, if (ctl.locked) Color(0xDBECEFF6) else GLASS_DARK, Ic.lock, 21f, "Orientation lock",
                    if (ctl.locked) RED else Color.White) { ctl.toggleLock() }
                Ctl(u, 66.5f, 160.5f, 37f, 37f, GLASS_DARK, Ic.mirror, 20f, "Screen mirroring") { ctl.tapMirror() }

                /* focus */
                Ctl(u, 22f, 207f, 82f, 37f, GLASS, Ic.moon, 0f, "Focus", shape = RoundedCornerShape(u * 19f)) { ctl.toggleFocus() }
                Box(
                    Modifier.at(u, 26.5f, 211.5f, 29f, 29f)
                        .background(if (ctl.focus) Color(0xFF6A62F5) else Color(0x57CED2F0), CircleShape),
                    contentAlignment = Alignment.Center
                ) { SvgIcon(Ic.moon, u * 16f, Color.White) }
                Box(Modifier.at(u, 60f, 217.5f, 30f, 16f), contentAlignment = Alignment.CenterStart) {
                    Text("Focus", color = Color.White, fontSize = (u * 8f).spx(), fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
                Box(Modifier.at(u, 88f, 219.5f, 10f, 12f), contentAlignment = Alignment.Center) {
                    SvgIcon(Ic.chevrons, u * 9f, Color(0xBFFFFFFF))
                }

                /* sliders */
                VSlider(u, 112f, 160f, ctl.brightness, { ctl.setBrightness(it) }, Ic.brightness, Color(0xFFF0A52C), "Brightness")
                val tier = if (ctl.volume <= 0f) 0 else if (ctl.volume > 0.34f) 2 else 1
                VSlider(u, 156f, 160f, ctl.volume, { ctl.setVolume(it) }, remember(tier) { Ic.volume(tier) }, BLUE, "Volume")

                /* shortcuts */
                Ctl(u, 22.5f, 252.5f, 37f, 37f, if (ctl.torch) Color.White else PINK, Ic.flash, 19f, "Flashlight",
                    if (ctl.torch) DARK_INK else Color.White) { ctl.toggleTorch() }
                Ctl(u, 66.5f, 252.5f, 37f, 37f, GLASS_DARK, if (ctl.timerRunning) emptyList() else Ic.timer, 21f, "Timer") { page = Page.Timer }
                if (ctl.timerRunning) {
                    Box(Modifier.at(u, 66.5f, 252.5f, 37f, 37f), contentAlignment = Alignment.Center) {
                        Text(
                            ctl.timerText(),
                            color = Color.White, fontSize = (u * 8f).spx(), fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center, maxLines = 1
                        )
                    }
                }
                Ctl(u, 112.5f, 252.5f, 37f, 37f, PINK, Ic.calc, 20f, "Calculator") { page = Page.Calc }
                Ctl(u, 157.5f, 252.5f, 37f, 37f, Color(0xCC3A76D6), Ic.camera, 21f, "Camera") { ctl.openCamera() }
                Ctl(u, 22.5f, 297.5f, 37f, 37f, Color(0x8580A892), Ic.qr, 20f, "Code scanner") { ctl.scanQr() }

                /* right-edge page indicators */
                listOf(Ic.heart to 196f, Ic.music to 227f, Ic.waves to 257f).forEachIndexed { i, (icon, y) ->
                    Ctl(u, 197f, y, 12f, 12f, Color.Transparent, icon, 9f, "Page ${i + 1}",
                        if (side == i) Color.White else Color(0x99FFFFFF)) { side = i }
                }

                /* toast */
                AnimatedVisibility(
                    visible = toastVisible,
                    modifier = Modifier.offset(u * 22f, u * 352f).width(u * 170f),
                    enter = fadeIn(), exit = fadeOut()
                ) {
                    Box(
                        Modifier.fillMaxWidth().heightIn(min = u * 17f)
                            .background(Color(0xB31A1E2A), RoundedCornerShape(u * 9f))
                            .border(u * 0.4f, RIM, RoundedCornerShape(u * 9f))
                            .padding(horizontal = u * 7f, vertical = u * 3f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            ctl.toastText, color = Color.White, fontSize = (u * 6.6f).spx(),
                            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
                        )
                    }
                }

                /* overlay: handle at the bottom closes the panel */
                if (onClose != null) {
                    Box(
                        Modifier.at(u, 77f, 436f, 60f, 24f).tap { onClose() }
                            .semantics { contentDescription = "Close Control Center" },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(u * 34f, u * 3.2f).background(Color(0x99FFFFFF), RoundedCornerShape(u * 2f)))
                    }
                }

                /* full-screen sheets */
                if (page == Page.Calc) CalcSheet(u) { page = Page.None }
                if (page == Page.Timer) TimerSheet(u, ctl) { page = Page.None }

                /* scanned QR code */
                ctl.qrResult?.let { text ->
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(start = u * 16f, end = u * 16f, bottom = u * 40f)
                            .fillMaxWidth()
                            .background(Color(0xE61E222A), RoundedCornerShape(u * 10f))
                            .padding(u * 8f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(u * 6f)
                    ) {
                        Text(
                            text.ifEmpty { "(empty code)" }, color = Color.White, fontSize = (u * 7f).spx(),
                            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 6,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(u * 6f)) {
                            if (text.startsWith("http://", true) || text.startsWith("https://", true)) {
                                Pill(u, "Open", Color(0xFF7DB4FF)) { ctl.openQrLink(text); ctl.qrResult = null }
                            }
                            Pill(u, "Copy", Color.White) { ctl.copy(text) }
                            Pill(u, "Close", Color(0xB3FFFFFF)) { ctl.qrResult = null }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Wallpaper() {
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(0f to Color(0xFF080C1A), 0.5f to Color(0xFF141B3D), 1f to Color(0xFF0A1628)))
            .drawBehind {
                fun orb(c: Color, cx: Float, cy: Float, r: Float) = drawRect(
                    Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(size.width * cx, size.height * cy), radius = size.width * r)
                )
                orb(Color(0xB37C4DFF), 0.15f, 0.12f, 0.95f)
                orb(Color(0x8C26C6DA), 0.95f, 0.42f, 0.85f)
                orb(Color(0x8CE0468C), 0.25f, 0.88f, 0.95f)
                orb(Color(0x664C6FFF), 0.8f, 0.95f, 0.7f)
            }
    )
    Box(Modifier.fillMaxSize().background(Color(0x1F000000)))
}

@Composable
private fun Blob(u: Dp, x: Float, y: Float, w: Float, h: Float, color: Color, a: Float) {
    Box(
        Modifier.at(u, x, y, w, h).blur(u * 2.6f).alpha(a).background(color, RoundedCornerShape(u * 7f))
    )
}

@Composable
private fun Glass(u: Dp, x: Float, y: Float, w: Float, h: Float, r: Float) {
    val shape = RoundedCornerShape(u * r)
    Box(
        Modifier.at(u, x, y, w, h).pop(y)
            .shadow(u * 6f, shape, ambientColor = Color(0x66000000), spotColor = Color(0x66000000))
            .background(GLASS_BRUSH, shape)
            .border(u * 0.5f, RIM, shape)
    )
}

/** A tappable control placed on the grid. Pass iconU = 0 to draw no icon. */
@Composable
private fun Ctl(
    u: Dp, x: Float, y: Float, w: Float, h: Float,
    bg: Color, icon: List<El>, iconU: Float, desc: String,
    tint: Color = Color.White,
    shape: Shape = CircleShape,
    onClick: () -> Unit
) {
    val c by animateColorAsState(bg, label = "bg")
    val filled = c.alpha > 0.02f
    val glow = c.alpha > 0.99f && w >= 29f
    val top = lerp(c, Color.White.copy(alpha = c.alpha), 0.16f)
    Box(
        Modifier.at(u, x, y, w, h).pop(y).tap(onClick).semantics { contentDescription = desc }
            .then(if (glow) Modifier.shadow(u * 7f, shape, ambientColor = c, spotColor = c) else Modifier)
            .then(if (filled) Modifier.background(Brush.verticalGradient(listOf(top, c)), shape) else Modifier)
            .then(if (filled) Modifier.border(u * 0.4f, Color.White.copy(alpha = 0.16f), shape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        if (iconU > 0f && icon.isNotEmpty()) SvgIcon(icon, u * iconU, tint)
    }
}

@Composable
private fun VSlider(
    u: Dp, x: Float, y: Float, value: Float, onValue: (Float) -> Unit,
    icon: List<El>, tint: Color, desc: String
) {
    var drag by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (drag) 1.04f else 1f, label = "drag")
    val shape = RoundedCornerShape(u * 20f)
    val v = value.coerceIn(0f, 1f)
    Box(
        Modifier.at(u, x, y, 40f, 86f).pop(y)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(GLASS_BRUSH)
            .border(u * 0.5f, RIM, shape)
            .semantics {
                contentDescription = desc
                progressBarRangeInfo = ProgressBarRangeInfo(v, 0f..1f)
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    drag = true
                    onValue(1f - down.position.y / size.height)
                    do {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull() ?: break
                        if (ch.pressed) {
                            onValue(1f - ch.position.y / size.height)
                            ch.consume()
                        }
                    } while (ev.changes.any { it.pressed })
                    drag = false
                }
            }
    ) {
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(v)
                .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFD6E2FF))))
        )
        SvgIcon(icon, u * 17f, tint, Modifier.align(Alignment.BottomCenter).padding(bottom = u * 9f))
        if (drag) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = u * 6f)
                    .background(Color(0xB3141820), RoundedCornerShape(u * 6f))
                    .padding(horizontal = u * 4f, vertical = u * 1.5f)
            ) {
                Text("${(v * 100).roundToInt()}%", color = Color.White, fontSize = (u * 7f).spx(), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Pill(u: Dp, text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.tap(onClick).background(Color(0x26FFFFFF), RoundedCornerShape(u * 8f))
            .padding(horizontal = u * 10f, vertical = u * 4f),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontSize = (u * 7.4f).spx(), fontWeight = FontWeight.Bold)
    }
}

/* ---------- sheets ---------- */

@Composable
private fun SheetFrame(u: Dp, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xCC080A10)).pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            Modifier.fillMaxSize().padding(start = u * 18f, top = u * 22f, end = u * 18f, bottom = u * 30f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(u * 8f, Alignment.Bottom),
            content = content
        )
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = u * 16f, end = u * 16f).size(u * 22f)
                .tap(onClose).semantics { contentDescription = "Close" }
                .background(Color(0x2EFFFFFF), CircleShape),
            contentAlignment = Alignment.Center
        ) { SvgIcon(Ic.close, u * 11f, Color.White) }
    }
}

@Composable
private fun CalcSheet(u: Dp, onClose: () -> Unit) {
    val calc = remember { Calc() }
    SheetFrame(u, onClose) {
        Text(
            calc.cur, Modifier.fillMaxWidth(),
            color = Color.White, fontSize = (u * 32f).spx(), fontWeight = FontWeight.Light,
            textAlign = TextAlign.End, maxLines = 1
        )
        val rows = listOf(
            listOf("AC", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+")
        )
        rows.forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(u * 5f)) {
                r.forEach { k -> CalcKey(u, k, calc, false) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(u * 5f)) {
            CalcKey(u, "0", calc, true)
            CalcKey(u, ".", calc, false)
            CalcKey(u, "=", calc, false)
        }
    }
}

@Composable
private fun CalcKey(u: Dp, k: String, calc: Calc, wide: Boolean) {
    val isOp = k in setOf("÷", "×", "−", "+", "=")
    val isFn = k in setOf("AC", "±", "%")
    val active = isOp && k != "=" && calc.fresh && calc.op == k
    val bg = when {
        active -> Color.White
        isOp -> Color(0xFFFF9F0A)
        isFn -> Color(0xFFA5A5A5)
        else -> Color(0xFF333333)
    }
    val fg = when {
        active -> Color(0xFFFF9F0A)
        isFn -> Color(0xFF111111)
        else -> Color.White
    }
    Box(
        Modifier.size(if (wide) u * 81f else u * 38f, u * 38f).tap { calc.press(k) }
            .semantics { contentDescription = k }
            .background(bg, RoundedCornerShape(u * 19f)),
        contentAlignment = if (wide) Alignment.CenterStart else Alignment.Center
    ) {
        Text(
            k, Modifier.padding(start = if (wide) u * 15f else u * 0f),
            color = fg, fontSize = (u * 13f).spx()
        )
    }
}

@Composable
private fun TimerSheet(u: Dp, ctl: Controller, onClose: () -> Unit) {
    val running = ctl.timerRunning
    SheetFrame(u, onClose) {
        Text(ctl.timerText(), color = Color.White, fontSize = (u * 40f).spx(), fontWeight = FontWeight.ExtraLight)
        Row(horizontalArrangement = Arrangement.spacedBy(u * 14f), modifier = Modifier.alpha(if (running) 0.35f else 1f)) {
            listOf("−" to -1, "+" to 1).forEach { (label, d) ->
                Box(
                    Modifier.size(u * 38f).tap { ctl.timerAdjust(d) }
                        .semantics { contentDescription = if (d < 0) "One minute less" else "One minute more" }
                        .background(Color(0xFF333333), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text(label, color = Color.White, fontSize = (u * 18f).spx()) }
            }
        }
        Box(
            Modifier.padding(top = u * 6f).size(u * 110f, u * 34f).tap { ctl.timerToggle() }
                .background(if (running) RED else Color(0xFF30D158), RoundedCornerShape(u * 17f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (running) "Cancel" else "Start",
                color = if (running) Color.White else Color(0xFF04210D),
                fontSize = (u * 10f).spx(), fontWeight = FontWeight.Bold
            )
        }
    }
}
