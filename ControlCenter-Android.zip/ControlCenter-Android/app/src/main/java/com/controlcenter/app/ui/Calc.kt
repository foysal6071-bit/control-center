package com.controlcenter.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.math.BigDecimal
import java.math.MathContext
import java.util.Locale

/** iOS-style calculator logic (port of the JavaScript version). */
class Calc {
    var cur by mutableStateOf("0")
    var op by mutableStateOf<String?>(null)
    var fresh by mutableStateOf(true)
    private var acc: Double? = null

    private fun fmt(n: Double): String {
        if (n.isNaN() || n.isInfinite()) return "Error"
        val s = BigDecimal(n).round(MathContext(10)).stripTrailingZeros().toPlainString()
        return if (s.length > 11) String.format(Locale.US, "%.5e", n) else s
    }

    private fun reset() {
        acc = null; cur = "0"; op = null; fresh = true
    }

    private fun value(): Double = cur.toDoubleOrNull() ?: 0.0

    private fun pending() {
        val v = value()
        val a = acc
        val o = op
        if (a != null && o != null && !fresh) {
            val r = when (o) {
                "+" -> a + v
                "−" -> a - v
                "×" -> a * v
                else -> a / v
            }
            acc = r
            cur = fmt(r)
        } else {
            acc = v
        }
    }

    fun press(k: String) {
        if (cur == "Error") reset()
        when {
            k.length == 1 && k[0].isDigit() -> {
                cur = if (fresh || cur == "0") k else cur + k
                fresh = false
            }
            k == "." -> {
                if (fresh) {
                    cur = "0."; fresh = false
                } else if (!cur.contains('.')) {
                    cur += "."
                }
            }
            k == "AC" -> reset()
            k == "±" -> {
                cur = if (cur.startsWith("-")) cur.substring(1) else if (cur == "0") "0" else "-$cur"
            }
            k == "%" -> {
                cur = fmt(value() / 100.0); fresh = true
            }
            k == "=" -> {
                pending(); op = null; fresh = true
            }
            else -> {
                pending(); op = k; fresh = true
            }
        }
    }
}
