package com.controlcenter.app;

interface IUserService {
    // Transaction id reserved by Shizuku for "destroy" (must be 16777114).
    void destroy() = 16777114;

    // Runs a shell command as the shell user. Returns "<exit code>\n<output>".
    String exec(String cmd) = 1;

    // Locks / unlocks the phone's own notification panel and quick settings pull-down.
    boolean setStatusBarLocked(boolean locked) = 2;
}
