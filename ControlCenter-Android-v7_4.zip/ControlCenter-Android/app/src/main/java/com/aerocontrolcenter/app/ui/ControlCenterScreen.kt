package com.aerocontrolcenter.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.aerocontrolcenter.app.Controller
import com.aerocontrolcenter.app.QsTiles
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/* ---------- colours: dark glass tiles on a soft blurred wallpaper ---------- */
private val INK = Color(0xFF1B1D22)
private val RED = Color(0xFFFF453A)
private val RED_ICON = Color(0xFFFF5A5A)

private enum class Tone { Off, On, Bad }

/* square tile grid: 4 columns x 4 rows under the sliders */
private const val TW = 41f
private fun colX(i: Int) = 14f + i * (TW + 7.33f)
private fun rowY(r: Int) = 190f + r * 51f


/** Where one tile of the grid sits (grid units). MIUI: the first two are wide tiles, the others circles. */
private class Slot(val x: Float, val y: Float, val w: Float, val h: Float, val wide: Boolean)

private fun slotFor(style: Int, i: Int): Slot =
    if (style == 1) {
        if (i < 2) Slot(14f + i * 96.5f, 102f, 89.5f, 36f, true)
        else {
            val j = i - 2
            Slot(14f + (j % 4) * 49.33f, 148f + (j / 4) * 49f, 38f, 38f, false)
        }
    } else Slot(colX(i % 4), rowY(i / 4), TW, TW, false)

private enum class Page { None, Calc, Timer }

/** One grid unit = u dp. The layout is drawn on a 214 x 465 unit grid, exactly like the web version. */
private fun Modifier.at(u: Dp, x: Float, y: Float, w: Float, h: Float): Modifier =
    this.offset(u * x, u * y).size(u * w, u * h)

@Composable
private fun Dp.spx(): TextUnit = with(LocalDensity.current) { this@spx.toSp() }

@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier = ccTap(null, onClick)

/** One shared 0..1 progress for the entrance of the whole grid (read only while drawing, never recomposes). */
private val LocalEnter = compositionLocalOf<State<Float>> { object : State<Float> { override val value = 1f } }

/** Staggered entrance, top row first: each tile rises, grows with a small overshoot and fades in. */
@Composable
private fun Modifier.pop(y: Float): Modifier {
    val e = LocalEnter.current
    return this.graphicsLayer {
        val t = ((e.value * 1.5f) - (y / 465f) * 0.5f).coerceIn(0f, 1f)
        // ease-out-back: overshoots a little, then settles
        val c1 = 1.4f
        val b = t - 1f
        val back = 1f + (c1 + 1f) * b * b * b + c1 * b * b
        val k = 0.78f + 0.22f * back
        scaleX = k
        scaleY = k
        alpha = (t * 1.6f).coerceIn(0f, 1f)
        translationY = (1f - t) * 22.dp.toPx()
    }
}

/**
 * @param onOpenSettings the gear button (top left)
 * @param onClose when not null the screen runs as the pull-down overlay: dim background, closes on
 *   swipe up / tap outside / the handle at the bottom. When null it is the normal full screen app.
 * @param active false while the overlay is built but hidden: nothing is registered or animated then.
 */
@Composable
fun ControlCenterApp(
    onOpenSettings: () -> Unit = {},
    onClose: (() -> Unit)? = null,
    insetTop: Dp = 0.dp,
    insetBottom: Dp = 0.dp,
    active: Boolean = true,
    blurBehind: Boolean = false
) {
    val overlay = onClose != null
    val ctx = LocalContext.current
    val th = rememberCCTheme(blurBehind)
    val scope = rememberCoroutineScope()
    val ctl = remember { Controller(ctx, scope) }

    DisposableEffect(ctl, active) {
        if (active) ctl.start()
        onDispose { if (active) ctl.stop() }
    }
    DisposableEffect(ctl) { onDispose { ctl.release() } }

    /* entrance animation: one progress value for the whole grid, restarted every time the panel opens */
    val enter = remember { Animatable(0f) }
    LaunchedEffect(active) {
        if (active) {
            enter.snapTo(0f)
            enter.animateTo(1f, tween(620, easing = FastOutSlowInEasing))
        } else {
            enter.snapTo(0f)
        }
    }

    if (!overlay) {
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            ctl.setTracks(uris)
        }
        SideEffect { ctl.onPickAudio = { picker.launch(arrayOf("audio/*")) } }
    } else {
        SideEffect {
            ctl.onPickAudio = {
                ctl.say(
                    if (ctl.hasNotifAccess()) "Start music in any app and it shows here"
                    else "Allow Notification access in the app to control your music", true
                )
            }
            ctl.onLaunched = { onClose?.invoke() }
        }
    }

    /* the shown tiles in grid order; edited right here in the panel (Edit button) */
    val order = remember { mutableStateListOf<String>().apply { addAll(Tiles.enabled(ctx)) } }
    var editing by remember { mutableStateOf(false) }
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragPos by remember { mutableStateOf(Offset.Zero) }
    var grab by remember { mutableStateOf(Offset.Zero) }
    val haptic = LocalHapticFeedback.current
    val hapticOn = remember { ctx.getSharedPreferences("cc", android.content.Context.MODE_PRIVATE).getBoolean("haptic", true) }
    // the tiles may have been changed in Settings while the panel was hidden: read them again every time it opens
    LaunchedEffect(active) {
        editing = false
        dragId = null
        if (active) {
            val fresh = Tiles.enabled(ctx)
            if (fresh != order.toList()) { order.clear(); order.addAll(fresh) }
        }
    }
    var page by remember { mutableStateOf(Page.None) }
    var toastVisible by remember { mutableStateOf(false) }

    LaunchedEffect(ctl.toastTick) {
        if (ctl.toastTick > 0) {
            toastVisible = true
            delay(2400)
            toastVisible = false
        }
    }
    LaunchedEffect(ctl.timerEnd, active) {
        while (active && ctl.timerEnd > 0L) {
            ctl.tickTimer()
            delay(250)
        }
    }
    LaunchedEffect(active) {
        if (!active) {
            page = Page.None
            ctl.qrResult = null
        }
    }

    if (!overlay) {
        BackHandler(enabled = page != Page.None || ctl.qrResult != null || editing) {
            if (ctl.qrResult != null) ctl.qrResult = null else if (page != Page.None) page = Page.None else editing = false
        }
    }

    /* overlay only: tap outside the grid or swipe up closes the panel */
    val closeMod = if (onClose != null && !editing) {
        Modifier
            .pointerInput(Unit) { detectTapGestures { onClose() } }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc < -size.height * 0.08f) onClose() },
                    onDragCancel = { acc = 0f }
                ) { _, dy -> acc += dy }
            }
    } else Modifier

    CompositionLocalProvider(LocalEnter provides enter.asState(), LocalCC provides th) {
    Box(Modifier.fillMaxSize().then(if (overlay) Modifier else Modifier.background(Color(0xFF0D1015))).then(closeMod)) {
        CCWallpaper(th, overlay)
        BoxWithConstraints(
            Modifier.fillMaxSize().then(
                if (overlay) Modifier.padding(top = insetTop, bottom = insetBottom)
                else Modifier.windowInsetsPadding(WindowInsets.systemBars)
            )
        ) {
            /* no status row any more (the phone has its own): the grid starts 28 units higher */
            val land = maxWidth > maxHeight
            /* landscape: make the panel bigger and let it scroll, instead of shrinking it to the screen height */
            val u = if (land) minOf(maxWidth / 214f, maxHeight / 437f * 1.7f) else minOf(maxWidth / 214f, maxHeight / 437f)
            val landScroll = rememberScrollState()
            val unitPx = with(LocalDensity.current) { u.toPx() }
            Box(
                (if (land)
                    Modifier.width(u * 214f).fillMaxHeight().align(Alignment.TopCenter)
                        .verticalScroll(landScroll)
                        .layout { m, c ->
                            val pl = m.measure(androidx.compose.ui.unit.Constraints.fixed(c.maxWidth, (u * 437f).roundToPx()))
                            layout(pl.width, (u * 409f).roundToPx()) { pl.place(0, -(u * 28f).roundToPx()) }
                        }
                else Modifier.width(u * 214f).fillMaxHeight().align(Alignment.TopCenter).offset(y = -(u * 28f)))
                    .then(if (overlay) Modifier.pointerInput(Unit) { detectTapGestures { } } else Modifier)
                    .pointerInput(editing, unitPx, th.style) {
                        if (!editing) return@pointerInput
                        val st = th.style
                        // hold a tile, then drag it to another place; the others move out of the way
                        detectDragGesturesAfterLongPress(
                            onDragStart = { pos ->
                                val i = order.indices.firstOrNull { i ->
                                    val sl = slotFor(st, i)
                                    pos.x in (sl.x * unitPx)..((sl.x + sl.w) * unitPx) &&
                                        pos.y in (sl.y * unitPx)..((sl.y + sl.h) * unitPx)
                                }
                                if (i != null) {
                                    val sl = slotFor(st, i)
                                    dragId = order[i]
                                    grab = Offset(pos.x - sl.x * unitPx, pos.y - sl.y * unitPx)
                                    dragPos = pos
                                    if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                }
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val id = dragId ?: return@detectDragGesturesAfterLongPress
                                dragPos = change.position
                                val from = order.indexOf(id)
                                if (from < 0) return@detectDragGesturesAfterLongPress
                                val cur = slotFor(st, from)
                                val cx = (dragPos.x - grab.x) / unitPx + cur.w / 2f
                                val cy = (dragPos.y - grab.y) / unitPx + cur.h / 2f
                                // the slot whose centre is nearest to the centre of the dragged tile
                                val to = order.indices.minByOrNull { i ->
                                    val sl = slotFor(st, i)
                                    val dx = sl.x + sl.w / 2f - cx
                                    val dy = sl.y + sl.h / 2f - cy
                                    dx * dx + dy * dy
                                } ?: from
                                if (to != from) {
                                    order.removeAt(from)
                                    order.add(to, id)
                                }
                            },
                            onDragEnd = { dragId = null; Tiles.save(ctx, order.toList()) },
                            onDragCancel = { dragId = null; Tiles.save(ctx, order.toList()) }
                        )
                    }
            ) {

                val style = th.style
                val dateText = remember(active) {
                    java.text.SimpleDateFormat("EEE, MMM d", java.util.Locale.getDefault()).format(java.util.Date())
                }

                /* hint line ("Wi-Fi is on"), shown for a moment after a change */
                AnimatedVisibility(
                    visible = toastVisible,
                    modifier = Modifier.offset(u * 14f, u * (if (style == 1) 419f else 31f)).width(u * 186f),
                    enter = fadeIn(), exit = fadeOut()
                ) {
                    Text(
                        ctl.toastText, Modifier.fillMaxWidth(),
                        color = th.fg.copy(alpha = 0.9f), fontSize = (u * 6.2f).spx(), fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }

                /* HyperOS: the date on the top left */
                if (style == 2 && !toastVisible) {
                    Text(
                        dateText, Modifier.offset(u * 16f, u * 33f),
                        color = th.fg.copy(alpha = 0.9f), fontSize = (u * 7f).spx(), fontWeight = FontWeight.Medium
                    )
                }

                /* MIUI: title with the settings and edit buttons */
                if (style == 1) {
                    Text(
                        "Control center", Modifier.offset(u * 14f, u * 32f),
                        color = th.fg, fontSize = (u * 12.5f).spx(), maxLines = 1
                    )
                    Ctl(u, 158f, 31f, 22f, 22f, Color.Transparent, Ic.hex, 14f, "Settings") { onOpenSettings() }
                    Ctl(u, 180f, 31f, 22f, 22f, Color.Transparent, Ic.pencil, 14f, "Edit tiles") { editing = !editing }
                }

                /* Wi-Fi + Mobile data */
                val wifiTone = if (ctl.wifiOn) Tone.On else Tone.Off
                val dataTone = if (ctl.airplane) Tone.Bad else if (ctl.dataOn) Tone.On else Tone.Off
                val dataIcon = Ic.cellOff.takeIf { ctl.airplane } ?: Ic.cell
                val dataSub = if (ctl.airplane) "Not available" else if (ctl.dataOn) "On" else "Off"
                if (style == 1) {
                    WideTile(
                        u, 14f, 60f, 89.5f, 36f, dataTone, dataIcon, "Mobile data", dataSub,
                        onLong = { ctl.longPressInternet() }
                    ) { ctl.tapCell() }
                    WideTile(
                        u, 110.5f, 60f, 89.5f, 36f, wifiTone, Ic.wifi, "Wi-Fi", if (ctl.wifiOn) "On" else "Off",
                        onLong = { ctl.longPressInternet() }
                    ) { ctl.tapWifi() }
                } else {
                    WideTile(
                        u, 14f, 50f, 96f, 38f, wifiTone, Ic.wifi, "Wi-Fi", if (ctl.wifiOn) "On" else "Off",
                        onLong = { ctl.longPressInternet() }
                    ) { ctl.tapWifi() }
                    WideTile(
                        u, 116f, 50f, 84f, 38f, dataTone, dataIcon, "Mobile data", dataSub,
                        onLong = { ctl.longPressInternet() }
                    ) { ctl.tapCell() }

                    /* media player + brightness + volume */
                    MediaTile(u, ctl, 14f, 94f, 96f, 86f)
                    VSlider(
                        u, 116f, 94f, { ctl.brightness }, { ctl.changeBrightness(it) },
                        { ctl.brightnessStart() }, { ctl.brightnessEnd() }, brightIcons, { 0 }, "Brightness"
                    )
                    VSlider(
                        u, 160f, 94f, { ctl.volume }, { ctl.changeVolume(it) },
                        { ctl.volumeStart() }, { ctl.volumeEnd() }, volIcons,
                        { val v = ctl.volume; if (v <= 0f) 0 else if (v > 0.34f) 2 else 1 }, "Volume"
                    )
                }

                /* tiles: filled row by row; in edit mode each has a small minus and can be dragged */
                order.toList().forEach { id ->
                    key(id) {
                        val index = order.indexOf(id)
                        val slot = slotFor(style, index)
                        val ax by animateFloatAsState(slot.x, tween(220), label = "gx")
                        val ay by animateFloatAsState(slot.y, tween(220), label = "gy")
                        val lifted = dragId == id
                        val x = if (lifted) (dragPos.x - grab.x) / unitPx else ax
                        val y = if (lifted) (dragPos.y - grab.y) / unitPx else ay
                        GridTile(u, slot, x, y, id, ctl, editing, lifted, { page = Page.Calc }) { page = Page.Timer }
                        if (editing && !lifted) {
                            RemoveBadge(u, x + slot.w - 9f, y - 6f) {
                                order.remove(id)
                                Tiles.save(ctx, order.toList())
                                if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                        }
                    }
                }

                /* where the grid ends (the buttons under it follow) */
                val gridBottom = if (order.isEmpty()) (if (style == 1) 138f else 190f)
                else slotFor(style, order.lastIndex).let { it.y + it.h }
                val labelPad = if (style == 2) 8f else 0f

                /* MIUI: brightness and volume as wide sliders under the tiles */
                if (style == 1 && !editing) {
                    HSlider(
                        u, 14f, gridBottom + 12f, 186f, 30f, { ctl.brightness }, { ctl.changeBrightness(it) },
                        { ctl.brightnessStart() }, { ctl.brightnessEnd() }, { Ic.brightness }, "Brightness"
                    )
                    HSlider(
                        u, 14f, gridBottom + 48f, 186f, 30f, { ctl.volume }, { ctl.changeVolume(it) },
                        { ctl.volumeStart() }, { ctl.volumeEnd() },
                        { val v = ctl.volume; volIcons[if (v <= 0f) 0 else if (v > 0.34f) 2 else 1] }, "Volume"
                    )
                }

                /* Edit pill: tap = edit the tiles right here; in edit mode: Settings + Done */
                val editY by animateFloatAsState(
                    if (editing) gridBottom + 6f + labelPad else gridBottom + 15f, tween(220), label = "ey"
                )
                if (!editing) {
                    if (style != 1) PillButton(u, 85f, editY, 44f, "Edit", "Edit tiles") { editing = true }
                } else {
                    PillButton(u, 34f, editY, 70f, "Settings", "Settings") { onOpenSettings() }
                    PillButton(u, 110f, editY, 70f, "Done", "Done") { editing = false }

                    /* tiles that are switched off: tap one to add it again */
                    val hidden = (Tiles.all.map { it.id } + remember { QsTiles.installed(ctx).map { it.id } }).filter { it !in order }
                    if (hidden.isNotEmpty()) {
                        Row(
                            Modifier.at(u, 14f, editY + 22f, 186f, 24f).horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(u * 5f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            hidden.forEach { id ->
                                AddChip(u, id, order.size < Tiles.MAX) {
                                    if (order.size < Tiles.MAX) {
                                        order.add(id)
                                        Tiles.save(ctx, order.toList())
                                    } else {
                                        ctl.say("You can show up to ${Tiles.MAX} tiles", true)
                                    }
                                }
                            }
                        }
                    }
                }

                /* overlay: handle at the bottom closes the panel */
                if (onClose != null && !editing) {
                    Box(
                        Modifier.at(u, 77f, 436f, 60f, 24f).tap { onClose() }
                            .semantics { contentDescription = "Close Aero Control Center" },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(u * 34f, u * 3.2f).background(th.fg.copy(alpha = 0.6f), RoundedCornerShape(u * 2f)))
                    }
                }

                /* full-screen sheets */
                if (page == Page.Calc) CalcSheet(u) { page = Page.None }
                if (page == Page.Timer) TimerSheet(u, ctl) { page = Page.None }

                /* scanned QR code */
                ctl.qrResult?.let { text ->
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(start = u * 16f, end = u * 16f, bottom = u * 40f)
                            .fillMaxWidth()
                            .background(Color(0xE61E222A), RoundedCornerShape(u * 10f))
                            .padding(u * 8f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(u * 6f)
                    ) {
                        Text(
                            text.ifEmpty { "(empty code)" }, color = Color.White, fontSize = (u * 7f).spx(),
                            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 6,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(u * 6f)) {
                            if (text.startsWith("http://", true) || text.startsWith("https://", true)) {
                                Pill(u, "Open", Color(0xFF7DB4FF)) { ctl.openQrLink(text); ctl.qrResult = null }
                            }
                            Pill(u, "Copy", Color.White) { ctl.copy(text) }
                            Pill(u, "Close", Color(0xB3FFFFFF)) { ctl.qrResult = null }
                        }
                    }
                }
            }
        }
    }
    }
}

/** The running countdown on the Timer tile. Own function so that only this label redraws every tick. */
@Composable
private fun TimerLabel(u: Dp, ctl: Controller, x: Float, y: Float) {
    val th = LocalCC.current
    Box(Modifier.at(u, x, y, TW, TW), contentAlignment = Alignment.Center) {
        Text(
            ctl.timerText(),
            color = th.tileOnFg, fontSize = (u * 7.4f).spx(), fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, maxLines = 1
        )
    }
}

/** App icon to draw instead of the line icon (tiles of other apps). */
private val LocalQsIcon = compositionLocalOf<ImageBitmap?> { null }

/** A tappable control placed on the grid. Pass iconU = 0 to draw no icon. */
@Composable
private fun Ctl(
    u: Dp, x: Float, y: Float, w: Float, h: Float,
    bg: Color, icon: List<El>, iconU: Float, desc: String,
    tint: Color = Color.Unspecified,
    shape: Shape = CircleShape,
    onLong: (() -> Unit)? = null,
    lift: Boolean = false,
    onClick: () -> Unit
) {
    val th = LocalCC.current
    val c by animateColorAsState(bg, label = "bg")
    val t by animateColorAsState(if (tint == Color.Unspecified) th.fg else tint, label = "tint")
    val filled = c.alpha > 0.02f
    Box(
        Modifier.then(if (lift) Modifier.zIndex(10f) else Modifier)
            .at(u, x, y, w, h).pop(y).ccTap(onLong, onClick).semantics { contentDescription = desc }
            .then(if (lift) Modifier.graphicsLayer { scaleX = 1.1f; scaleY = 1.1f } else Modifier)
            .then(if (filled) Modifier.background(c, shape).border(u * 0.4f, th.edge, shape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        val qsIcon = LocalQsIcon.current
        if (qsIcon != null) Image(qsIcon, desc, Modifier.size(u * 21f).clip(RoundedCornerShape(u * 5f)))
        else if (iconU > 0f && icon.isNotEmpty()) SvgIcon(icon, u * iconU, t)
    }
}

/** Tile: a rounded square (iOS), or a circle (MIUI / HyperOS). Dark when off, light or accent coloured when on. */
@Composable
private fun Sq(
    u: Dp, x: Float, y: Float, on: Boolean, icon: List<El>, iconU: Float, desc: String,
    size: Float = TW, circle: Boolean = false, lift: Boolean = false,
    onLong: (() -> Unit)? = null, onClick: () -> Unit
) {
    val th = LocalCC.current
    Ctl(
        u, x, y, size, size, if (on) th.tileOn else th.tile, icon, iconU, desc,
        if (on) th.tileOnFg else th.fg, if (circle) CircleShape else RoundedCornerShape(u * th.radius), onLong, lift, onClick
    )
}

private fun shortLabel(ctx: android.content.Context, id: String): String = if (QsTiles.isQs(id)) QsTiles.shortLabel(ctx, id) else shortLabelBuiltIn(id)

private fun shortLabelBuiltIn(id: String) = when (id) {
    "bluetooth" -> "Bluetooth"
    "airplane" -> "Airplane mode"
    "silent" -> "Mute"
    "torch" -> "Flashlight"
    "screenshot" -> "Screenshot"
    "battery" -> "Battery saver"
    "rotation" -> "Lock orientation"
    "cast" -> "Screen cast"
    "hotspot" -> "Hotspot"
    "timer" -> "Timer"
    "focus" -> "Focus"
    "share" -> "Share"
    "location" -> "Location"
    "nfc" -> "NFC"
    "dark" -> "Dark mode"
    "datasaver" -> "Data saver"
    "sync" -> "Auto-sync"
    "camera" -> "Camera"
    "calc" -> "Calculator"
    "qr" -> "QR scanner"
    "settings" -> "Settings"
    else -> "Sound output"
}

private fun iconFor(id: String, ctl: Controller): Pair<List<El>, Float> = when (id) {
    "bluetooth" -> Ic.bluetooth to 19f
    "airplane" -> Ic.airplane to 20f
    "silent" -> (if (ctl.volume <= 0f) Ic.bellOff else Ic.bell) to 19f
    "torch" -> Ic.flash to 19f
    "screenshot" -> Ic.scissors to 19f
    "battery" -> Ic.boltRing to 20f
    "rotation" -> Ic.lock to 21f
    "cast" -> Ic.cast to 19f
    "hotspot" -> Ic.waves to 20f
    "timer" -> Ic.timer to 20f
    "focus" -> Ic.moon to 19f
    "location" -> Ic.location to 19f
    "nfc" -> Ic.nfc to 19f
    "dark" -> Ic.darkMode to 19f
    "datasaver" -> Ic.dataSaver to 19f
    "sync" -> Ic.sync to 19f
    "camera" -> Ic.camera to 19f
    "calc" -> Ic.calc to 19f
    "qr" -> Ic.qr to 19f
    "settings" -> Ic.gear to 19f
    "share" -> Ic.share to 19f
    else -> (if (QsTiles.isQs(id)) Ic.tiles else Ic.airplay) to 19f
}

private fun tileOn(id: String, ctl: Controller): Boolean = when (id) {
    "bluetooth" -> ctl.bluetooth
    "airplane" -> ctl.airplane
    "silent" -> ctl.volume <= 0f
    "torch" -> ctl.torch
    "rotation" -> ctl.locked
    "hotspot" -> ctl.hotspot
    "focus" -> ctl.focus
    "timer" -> ctl.timerRunning
    "location" -> ctl.locationOn
    "nfc" -> ctl.nfcOn
    "dark" -> ctl.darkOn
    "datasaver" -> ctl.saverOn
    "sync" -> ctl.syncOn
    else -> false
}

/** Second line of a wide tile (MIUI). */
private fun tileSub(id: String, ctl: Controller): String = when (id) {
    "rotation" -> if (ctl.locked) "Locked" else "Off"
    "timer" -> if (ctl.timerRunning) ctl.timerText() else "Off"
    "bluetooth", "airplane", "silent", "torch", "hotspot", "focus", "location", "nfc", "dark", "datasaver", "sync" -> if (tileOn(id, ctl)) "On" else "Off"
    else -> ""
}

private fun tileAction(id: String, ctl: Controller, onCalc: () -> Unit, onTimer: () -> Unit): () -> Unit = {
    when (id) {
        "bluetooth" -> ctl.tapBluetooth()
        "airplane" -> ctl.tapAirplane()
        "silent" -> ctl.toggleMute()
        "torch" -> ctl.toggleTorch()
        "screenshot" -> ctl.screenshot()
        "battery" -> ctl.tapBatterySaver()
        "rotation" -> ctl.toggleLock()
        "cast" -> ctl.tapMirror()
        "hotspot" -> ctl.tapHotspot()
        "timer" -> onTimer()
        "focus" -> ctl.toggleFocus()
        "share" -> ctl.share()
        "output" -> ctl.tapAirplay()
        "location" -> ctl.tapLocation()
        "nfc" -> ctl.tapNfc()
        "dark" -> ctl.tapDark()
        "datasaver" -> ctl.tapDataSaver()
        "sync" -> ctl.tapSync()
        "camera" -> ctl.openCamera()
        "calc" -> onCalc()
        "qr" -> ctl.scanQr()
        "settings" -> ctl.openSystemSettings()
        else -> if (QsTiles.isQs(id)) ctl.tapQsTile(id)
    }
}

/** Tap-and-hold action of a tile, or null when the tile has none. */
private fun tileLongAction(id: String, ctl: Controller): (() -> Unit)? = when (id) {
    "bluetooth" -> ({ ctl.longPressBluetooth() })
    else -> null
}

/** One tile of the grid by its id. In edit mode a tap does nothing (the tile is only moved or removed). */
@Composable
private fun GridTile(
    u: Dp, slot: Slot, x: Float, y: Float, id: String, ctl: Controller,
    editing: Boolean, lift: Boolean, onCalc: () -> Unit, onTimer: () -> Unit
) {
    val th = LocalCC.current
    val (icon, iconU) = iconFor(id, ctl)
    val on = tileOn(id, ctl)
    val click: () -> Unit = if (editing) ({}) else tileAction(id, ctl, onCalc, onTimer)
    val long: (() -> Unit)? = if (editing) null else tileLongAction(id, ctl)
    val label = shortLabel(LocalContext.current, id)
    if (slot.wide) {
        WideTile(u, x, y, slot.w, slot.h, if (on) Tone.On else Tone.Off, icon, label, tileSub(id, ctl), long, lift, click)
        return
    }
    val running = id == "timer" && ctl.timerRunning
    val ic = if (running) emptyList() else icon
    val qsBmp = if (QsTiles.isQs(id)) QsTiles.icon(LocalContext.current, id) else null
    CompositionLocalProvider(LocalQsIcon provides qsBmp) {
    when (th.style) {
        2 -> {
            Sq(u, x + 1.5f, y, on, ic, iconU * 0.95f, label, 38f, true, lift, long, click)
            Text(
                label, Modifier.at(u, x - 4f, y + 40f, TW + 8f, 8f).pop(y),
                color = th.fg.copy(alpha = 0.85f), fontSize = (u * 5.2f).spx(),
                textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (running) TimerLabel(u, ctl, x, y)
        }
        1 -> {
            Sq(u, x, y, on, ic, iconU * 0.95f, label, 38f, true, lift, long, click)
            if (running) TimerLabel(u, ctl, x - 1.5f, y - 1.5f)
        }
        else -> {
            Sq(u, x, y, on, ic, iconU, label, TW, false, lift, long, click)
            if (running) TimerLabel(u, ctl, x, y)
        }
    }
    }
}

/** Small round minus at the top right corner of a tile (edit mode). The touch area is bigger than the dot. */
@Composable
private fun RemoveBadge(u: Dp, x: Float, y: Float, onClick: () -> Unit) {
    Box(
        Modifier.at(u, x - 3f, y - 3f, 20f, 20f).zIndex(5f).tap(onClick)
            .semantics { contentDescription = "Remove tile" },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(u * 14f).background(Color(0xFF3A3D45), CircleShape).border(u * 0.8f, Color.White.copy(alpha = 0.9f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(u * 7f, u * 1.6f).background(Color.White, RoundedCornerShape(u)))
        }
    }
}

/** A tile that is switched off, shown in edit mode with a small plus. Tap = add it to the grid. */
@Composable
private fun AddChip(u: Dp, id: String, enabled: Boolean, onClick: () -> Unit) {
    val th = LocalCC.current
    val (icon, iconU) = when (id) {
        "bluetooth" -> Ic.bluetooth to 19f
        "airplane" -> Ic.airplane to 20f
        "silent" -> Ic.bell to 19f
        "torch" -> Ic.flash to 19f
        "screenshot" -> Ic.scissors to 19f
        "battery" -> Ic.boltRing to 20f
        "rotation" -> Ic.lock to 21f
        "cast" -> Ic.cast to 19f
        "hotspot" -> Ic.waves to 20f
        "timer" -> Ic.timer to 20f
        "focus" -> Ic.moon to 19f
        "location" -> Ic.location to 19f
        "nfc" -> Ic.nfc to 19f
        "dark" -> Ic.darkMode to 19f
        "datasaver" -> Ic.dataSaver to 19f
        "sync" -> Ic.sync to 19f
        "camera" -> Ic.camera to 19f
        "calc" -> Ic.calc to 19f
        "qr" -> Ic.qr to 19f
        "settings" -> Ic.gear to 19f
        "share" -> Ic.share to 19f
        else -> (if (QsTiles.isQs(id)) Ic.tiles else Ic.airplay) to 19f
    }
    val label = Tiles.labelOf(LocalContext.current, id)
    Box(
        Modifier.size(u * 24f).alpha(if (enabled) 1f else 0.4f).tap(onClick)
            .semantics { contentDescription = "Add $label" },
        contentAlignment = Alignment.Center
    ) {
        val shape = RoundedCornerShape(u * (th.radius * 0.55f))
        Box(
            Modifier.size(u * 22f).background(th.tile, shape).border(u * 0.4f, th.edge, shape),
            contentAlignment = Alignment.Center
        ) { SvgIcon(icon, u * iconU * 0.5f, th.fg) }
        Box(
            Modifier.align(Alignment.TopEnd).size(u * 10f).background(Color(0xFF30D158), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(u * 5f, u * 1.2f).background(Color.White, RoundedCornerShape(u)))
            Box(Modifier.size(u * 1.2f, u * 5f).background(Color.White, RoundedCornerShape(u)))
        }
    }
}

/** Small rounded button under the grid (Edit / Settings / Done). */
@Composable
private fun PillButton(u: Dp, x: Float, y: Float, w: Float, text: String, desc: String, onClick: () -> Unit) {
    val th = LocalCC.current
    Box(
        Modifier.at(u, x, y, w, 18f).pop(y).tap(onClick)
            .semantics { contentDescription = desc }
            .background(th.tile, RoundedCornerShape(u * 9f))
            .border(u * 0.4f, th.edge, RoundedCornerShape(u * 9f)),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = th.fg, fontSize = (u * 7.2f).spx(), fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/**
 * Wide tile with an icon and two lines of text (Wi-Fi, Mobile data, ...). [onLong] = tap and hold.
 * iOS: icon in a round chip. MIUI: flat rounded tile with a small corner mark. HyperOS: glass pill.
 */
@Composable
private fun WideTile(
    u: Dp, x: Float, y: Float, w: Float, h: Float, tone: Tone,
    icon: List<El>, title: String, sub: String,
    onLong: (() -> Unit)? = null,
    lift: Boolean = false,
    onClick: () -> Unit
) {
    val th = LocalCC.current
    val bg by animateColorAsState(
        when (tone) { Tone.On -> th.tileOn; Tone.Off -> th.tile; Tone.Bad -> th.tileBad }, label = "wbg"
    )
    val shape = when (th.style) {
        1 -> RoundedCornerShape(u * 12f)
        2 -> RoundedCornerShape(50)
        else -> RoundedCornerShape(u * th.radius)
    }
    val titleC = when (tone) { Tone.On -> th.tileOnFg; Tone.Off -> th.fg; Tone.Bad -> th.fg.copy(alpha = 0.7f) }
    val subC = when (tone) { Tone.On -> th.tileOnSub; Tone.Off -> th.fgSub; Tone.Bad -> th.fgSub }
    val chip = when (tone) { Tone.On -> th.tileOnFg; Tone.Off -> th.fg.copy(alpha = 0.18f); Tone.Bad -> Color(0x33FF5A5A) }
    val glyph = when (tone) { Tone.On -> th.tileOn; Tone.Off -> th.fg; Tone.Bad -> RED_ICON }
    val flatGlyph = when (tone) { Tone.On -> th.tileOnFg; Tone.Off -> th.fg; Tone.Bad -> RED_ICON }
    Box(
        Modifier.then(if (lift) Modifier.zIndex(10f) else Modifier)
            .at(u, x, y, w, h).pop(y).ccTap(onLong, onClick).semantics { contentDescription = title }
            .then(if (lift) Modifier.graphicsLayer { scaleX = 1.06f; scaleY = 1.06f } else Modifier)
            .background(bg, shape)
            .then(if (th.style == 1) Modifier else Modifier.border(u * 0.4f, th.edge, shape))
            .then(
                if (th.style == 1 && onLong != null) Modifier.drawBehind {
                    val sz = size.height * 0.17f
                    val pad = size.height * 0.12f
                    val tri = Path().apply {
                        moveTo(size.width - pad, size.height - pad - sz)
                        lineTo(size.width - pad, size.height - pad)
                        lineTo(size.width - pad - sz, size.height - pad)
                        close()
                    }
                    drawPath(tri, titleC.copy(alpha = 0.55f))
                } else Modifier
            )
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = u * (if (th.style == 0) 7f else 9f)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(u * (if (th.style == 0) 5f else 6f))
        ) {
            if (th.style == 0) {
                Box(Modifier.size(u * 20f).background(chip, CircleShape), contentAlignment = Alignment.Center) {
                    SvgIcon(icon, u * 11f, glyph)
                }
            } else {
                Box(Modifier.size(u * 16f), contentAlignment = Alignment.Center) {
                    SvgIcon(icon, u * (if (th.style == 1) 14f else 12f), flatGlyph)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(title, color = titleC, fontSize = (u * 6.9f).spx(), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (sub.isNotEmpty()) Text(sub, color = subC, fontSize = (u * 5.6f).spx(), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Dark media tile: "No playback history" + previous / play / next. */
@Composable
private fun MediaTile(u: Dp, ctl: Controller, x: Float, y: Float, w: Float, h: Float) {
    val th = LocalCC.current
    val shape = RoundedCornerShape(u * th.radius)
    Box(Modifier.at(u, x, y, w, h).pop(y).background(th.tile, shape).border(u * 0.4f, th.edge, shape))
    Text(
        if (ctl.nowPlaying == "Not Playing" && !ctl.playing) "No playback history" else ctl.nowPlaying,
        Modifier.at(u, x + 9f, y + 10f, w - 18f, 24f),
        color = th.fg.copy(alpha = 0.6f), fontSize = (u * 6.6f).spx(), fontWeight = FontWeight.Medium,
        maxLines = 2, overflow = TextOverflow.Ellipsis
    )
    val cy = y + 55f
    Ctl(u, x + 6f, cy, 22f, 22f, Color.Transparent, Ic.prev, 12f, "Previous", th.fg.copy(alpha = 0.6f)) { ctl.prev() }
    Ctl(
        u, x + w / 2f - 12f, cy - 1f, 24f, 24f, Color.Transparent,
        if (ctl.playing) Ic.pause else Ic.play, 14f, if (ctl.playing) "Pause" else "Play"
    ) { ctl.togglePlay() }
    Ctl(u, x + w - 28f, cy, 22f, 22f, Color.Transparent, Ic.next, 12f, "Next", th.fg.copy(alpha = 0.6f)) { ctl.next() }
}

private val brightIcons = listOf(Ic.brightness)
private val volIcons = listOf(Ic.volume(0), Ic.volume(1), Ic.volume(2))

/**
 * Vertical slider. It is built to stay smooth while the finger moves:
 *  - the value is read only while drawing (lambdas), so nothing is recomposed per frame,
 *  - while dragging, the slider shows its own finger position and never waits for the system,
 *  - the fill is drawn, not laid out.
 */
@Composable
private fun VSlider(
    u: Dp, x: Float, y: Float,
    value: () -> Float, onValue: (Float) -> Unit, onStart: () -> Unit, onEnd: () -> Unit,
    icons: List<List<El>>, iconIndex: () -> Int, desc: String
) {
    val th = LocalCC.current
    var drag by remember { mutableStateOf(false) }
    var local by remember { mutableFloatStateOf(0f) }
    val scale by animateFloatAsState(if (drag) 1.04f else 1f, spring(dampingRatio = 0.7f, stiffness = 700f), label = "drag")
    val shape = RoundedCornerShape(u * (th.radius * 0.65f))
    val onV by rememberUpdatedState(onValue)
    val onS by rememberUpdatedState(onStart)
    val onE by rememberUpdatedState(onEnd)
    val valueNow by rememberUpdatedState(value)

    val light = remember { derivedStateOf { (if (drag) local else valueNow()).coerceIn(0f, 1f) > 0.16f } }
    val pct = remember { derivedStateOf { ((if (drag) local else valueNow()).coerceIn(0f, 1f) * 100f).roundToInt() } }
    val iconNo = remember { derivedStateOf { iconIndex().coerceIn(0, icons.size - 1) } }

    Box(
        Modifier.at(u, x, y, 40f, 86f).pop(y)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(th.tile)
            .drawBehind {
                val v = (if (drag) local else valueNow()).coerceIn(0f, 1f)
                val h = size.height * v
                drawRect(th.tileOn, topLeft = Offset(0f, size.height - h), size = Size(size.width, h))
            }
            .border(u * 0.4f, th.edge, shape)
            .semantics {
                contentDescription = desc
                progressBarRangeInfo = ProgressBarRangeInfo(valueNow().coerceIn(0f, 1f), 0f..1f)
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    drag = true
                    onS()
                    local = (1f - down.position.y / size.height).coerceIn(0f, 1f)
                    onV(local)
                    do {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull() ?: break
                        if (ch.pressed) {
                            local = (1f - ch.position.y / size.height).coerceIn(0f, 1f)
                            onV(local)
                            ch.consume()
                        }
                    } while (ev.changes.any { it.pressed })
                    drag = false
                    onE()
                }
            }
    ) {
        SvgIcon(
            icons[iconNo.value], u * 17f, if (light.value) th.tileOnFg else th.fg,
            Modifier.align(Alignment.BottomCenter).padding(bottom = u * 9f)
        )
        if (drag) PercentBubble(u, pct, Modifier.align(Alignment.TopCenter))
    }
}

/** Horizontal slider (MIUI brightness / volume). Same smooth behaviour as [VSlider]. */
@Composable
private fun HSlider(
    u: Dp, x: Float, y: Float, w: Float, h: Float,
    value: () -> Float, onValue: (Float) -> Unit, onStart: () -> Unit, onEnd: () -> Unit,
    icon: () -> List<El>, desc: String
) {
    val th = LocalCC.current
    var drag by remember { mutableStateOf(false) }
    var local by remember { mutableFloatStateOf(0f) }
    val shape = RoundedCornerShape(u * 12f)
    val onV by rememberUpdatedState(onValue)
    val onS by rememberUpdatedState(onStart)
    val onE by rememberUpdatedState(onEnd)
    val valueNow by rememberUpdatedState(value)
    val iconNow by rememberUpdatedState(icon)
    val pct = remember { derivedStateOf { ((if (drag) local else valueNow()).coerceIn(0f, 1f) * 100f).roundToInt() } }
    val fill = th.fg.copy(alpha = 0.34f)

    Box(
        Modifier.at(u, x, y, w, h).pop(y)
            .clip(shape)
            .background(th.tile)
            .drawBehind {
                val v = (if (drag) local else valueNow()).coerceIn(0f, 1f)
                drawRect(fill, topLeft = Offset.Zero, size = Size(size.width * v, size.height))
            }
            .semantics {
                contentDescription = desc
                progressBarRangeInfo = ProgressBarRangeInfo(valueNow().coerceIn(0f, 1f), 0f..1f)
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    drag = true
                    onS()
                    local = (down.position.x / size.width).coerceIn(0f, 1f)
                    onV(local)
                    do {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull() ?: break
                        if (ch.pressed) {
                            local = (ch.position.x / size.width).coerceIn(0f, 1f)
                            onV(local)
                            ch.consume()
                        }
                    } while (ev.changes.any { it.pressed })
                    drag = false
                    onE()
                }
            }
    ) {
        SvgIcon(iconNow(), u * 15f, th.fg, Modifier.align(Alignment.CenterStart).padding(start = u * 10f))
        if (drag) PercentBubble(u, pct, Modifier.align(Alignment.CenterEnd).padding(end = u * 4f))
    }
}

@Composable
private fun PercentBubble(u: Dp, pct: State<Int>, modifier: Modifier) {
    Box(
        modifier.padding(top = u * 6f)
            .background(Color(0xB3141820), RoundedCornerShape(u * 6f))
            .padding(horizontal = u * 4f, vertical = u * 1.5f)
    ) {
        Text("${pct.value}%", color = Color.White, fontSize = (u * 7f).spx(), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Pill(u: Dp, text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.tap(onClick).background(Color(0x26FFFFFF), RoundedCornerShape(u * 8f))
            .padding(horizontal = u * 10f, vertical = u * 4f),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontSize = (u * 7.4f).spx(), fontWeight = FontWeight.Bold)
    }
}

/* ---------- sheets ---------- */

@Composable
private fun SheetFrame(u: Dp, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val th = LocalCC.current
    Box(
        Modifier.fillMaxSize().background(th.sheet).pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            Modifier.fillMaxSize().padding(start = u * 18f, top = u * 22f, end = u * 18f, bottom = u * 30f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(u * 8f, Alignment.Bottom),
            content = content
        )
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = u * 16f, end = u * 16f).size(u * 22f)
                .tap(onClose).semantics { contentDescription = "Close" }
                .background(th.pill, CircleShape),
            contentAlignment = Alignment.Center
        ) { SvgIcon(Ic.close, u * 11f, th.fg) }
    }
}

@Composable
private fun CalcSheet(u: Dp, onClose: () -> Unit) {
    val calc = remember { Calc() }
    SheetFrame(u, onClose) {
        Text(
            calc.cur, Modifier.fillMaxWidth(),
            color = Color.White, fontSize = (u * 32f).spx(), fontWeight = FontWeight.Light,
            textAlign = TextAlign.End, maxLines = 1
        )
        val rows = listOf(
            listOf("AC", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+")
        )
        rows.forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(u * 5f)) {
                r.forEach { k -> CalcKey(u, k, calc, false) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(u * 5f)) {
            CalcKey(u, "0", calc, true)
            CalcKey(u, ".", calc, false)
            CalcKey(u, "=", calc, false)
        }
    }
}

@Composable
private fun CalcKey(u: Dp, k: String, calc: Calc, wide: Boolean) {
    val isOp = k in setOf("÷", "×", "−", "+", "=")
    val isFn = k in setOf("AC", "±", "%")
    val active = isOp && k != "=" && calc.fresh && calc.op == k
    val bg = when {
        active -> Color.White
        isOp -> Color(0xFFFF9F0A)
        isFn -> Color(0xFFA5A5A5)
        else -> Color(0xFF333333)
    }
    val fg = when {
        active -> Color(0xFFFF9F0A)
        isFn -> Color(0xFF111111)
        else -> Color.White
    }
    Box(
        Modifier.size(if (wide) u * 81f else u * 38f, u * 38f).tap { calc.press(k) }
            .semantics { contentDescription = k }
            .background(bg, RoundedCornerShape(u * 19f)),
        contentAlignment = if (wide) Alignment.CenterStart else Alignment.Center
    ) {
        Text(
            k, Modifier.padding(start = if (wide) u * 15f else u * 0f),
            color = fg, fontSize = (u * 13f).spx()
        )
    }
}

@Composable
private fun TimerSheet(u: Dp, ctl: Controller, onClose: () -> Unit) {
    val th = LocalCC.current
    val running = ctl.timerRunning
    SheetFrame(u, onClose) {
        Text(ctl.timerText(), color = th.fg, fontSize = (u * 40f).spx(), fontWeight = FontWeight.ExtraLight)
        Row(horizontalArrangement = Arrangement.spacedBy(u * 14f), modifier = Modifier.alpha(if (running) 0.35f else 1f)) {
            listOf("−" to -1, "+" to 1).forEach { (label, d) ->
                Box(
                    Modifier.size(u * 38f).tap { ctl.timerAdjust(d) }
                        .semantics { contentDescription = if (d < 0) "One minute less" else "One minute more" }
                        .background(th.pill, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text(label, color = th.fg, fontSize = (u * 18f).spx()) }
            }
        }
        Box(
            Modifier.padding(top = u * 6f).size(u * 110f, u * 34f).tap { ctl.timerToggle() }
                .background(if (running) RED else Color(0xFF30D158), RoundedCornerShape(u * 17f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (running) "Cancel" else "Start",
                color = if (running) Color.White else Color(0xFF04210D),
                fontSize = (u * 10f).spx(), fontWeight = FontWeight.Bold
            )
        }
    }
}
