package com.aerocontrolcenter.app;

// Called from the Shizuku shell process when a swipe-down from the top edge is seen.
// half = 1 when the swipe started on the left half of the screen, 2 when it started on the right half.
oneway interface IPullListener {
    void onPull(int half) = 1;
}
