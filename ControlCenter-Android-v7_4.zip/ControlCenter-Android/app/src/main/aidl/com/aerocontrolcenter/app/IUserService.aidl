package com.aerocontrolcenter.app;

import com.aerocontrolcenter.app.IPullListener;

interface IUserService {
    // Transaction id reserved by Shizuku for "destroy" (must be 16777114).
    void destroy() = 16777114;

    // Runs a shell command as the shell user. Returns "<exit code>\n<output>".
    String exec(String cmd) = 1;

    // Locks / unlocks the phone's own notification panel and quick settings pull-down.
    boolean setStatusBarLocked(boolean locked) = 2;

    // Watches the touch screen (getevent) and calls listener.onPull() when a finger that started in the
    // top edge area moves down. w/h = natural (portrait) display size in px, rotation = Surface.ROTATION_*,
    // side = 0 full width (both halves, reported through onPull(half)), 1 left half, 2 right half. Returns false if no touch screen was found.
    // autoLock = hold back the phone's own pull-down (status bar disable flags) only while a finger that
    // started inside the trigger area is on the screen. Used by the split mode, where the other half of
    // the top edge must keep opening the phone's own notification panel.
    boolean startPullWatch(IPullListener listener, int w, int h, int rotation, int topPx, int dragPx, int side, boolean autoLock) = 3;

    void setPullRotation(int rotation) = 4;

    void stopPullWatch() = 5;

    // Hides / shows the clock, notification icons and system icons of the phone's own status bar (the custom
    // status bar of this app is drawn instead). Kept separate from setStatusBarLocked: both are combined.
    boolean setStatusBarHidden(boolean hidden) = 6;

    // Median brightness (0..255) of the top [rows] pixel rows of the screen (the strip behind the custom status
    // bar), measured from a raw screencap. Returns -1 when it could not be measured.
    int barLuma(int rows) = 7;
}
