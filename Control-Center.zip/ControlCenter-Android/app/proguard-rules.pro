
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
