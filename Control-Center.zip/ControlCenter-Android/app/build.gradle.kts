import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.aerocontrolcenter.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aerocontrolcenter.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 13
        versionName = "3.0.0"
        // only English resources of the libraries are packed: the whole app is English
        resourceConfigurations += listOf("en")
    }

    // Release signing: the keystore comes from environment variables (GitHub secrets) or keystore.properties.
    // Without them the release build stays unsigned and the debug build is used instead.
    val props = Properties().apply {
        val f = rootProject.file("keystore.properties")
        if (f.exists()) f.inputStream().use { load(it) }
    }
    fun cfg(env: String, key: String): String? = System.getenv(env)?.takeIf { it.isNotBlank() } ?: props.getProperty(key)
    val keystorePath = cfg("KEYSTORE_PATH", "storeFile")

    signingConfigs {
        if (keystorePath != null) {
            create("release") {
                storeFile = file(keystorePath)
                storePassword = cfg("KEYSTORE_PASSWORD", "storePassword")
                keyAlias = cfg("KEY_ALIAS", "keyAlias")
                keyPassword = cfg("KEY_PASSWORD", "keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (keystorePath != null) signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        // a lint warning must never stop a release build
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    // QR scanner (Google code scanner, no camera permission needed)
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
}
