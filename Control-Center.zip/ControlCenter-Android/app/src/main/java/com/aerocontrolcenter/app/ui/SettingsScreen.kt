package com.aerocontrolcenter.app.ui

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.aerocontrolcenter.app.IslandService
import com.aerocontrolcenter.app.MediaListener
import com.aerocontrolcenter.app.OverlayService
import com.aerocontrolcenter.app.QsTiles
import com.aerocontrolcenter.app.Shell
import com.aerocontrolcenter.app.StatusBarService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// iOS (dark) system colours
private val BG = Color(0xFF000000)
private val CARD = Color(0xFF1C1C1E)
private val DIM = Color(0x99EBEBF5)
private val OK = Color(0xFF30D158)
private val INFO = Color(0xFF0A84FF)
private val BLUE = Color(0xFF0A84FF)
private val RED = Color(0xFFFF453A)
private val SEP = Color(0x33FFFFFF)

/** Home screen of the app: every setting in one place. */
@Composable
fun SettingsScreen(onOpenControlCenter: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val prefs = remember { ctx.getSharedPreferences("cc", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val pkg = ctx.packageName

    var overlayOn by remember { mutableStateOf(prefs.getBoolean("overlay_on", false) && Settings.canDrawOverlays(ctx)) }
    var split by remember { mutableStateOf(prefs.getBoolean("split", true)) }
    // the full lock and the split pull-down exclude each other (the left half has to open the phone's own panel)
    var lockOn by remember { mutableStateOf(prefs.getBoolean("lock_stock", false) && !prefs.getBoolean("split", true)) }
    var msg by remember { mutableStateOf("") }
    var pendingOverlay by remember { mutableStateOf(false) }
    var resumeTick by remember { mutableIntStateOf(0) }
    var triggerH by remember { mutableIntStateOf(prefs.getInt("trigger_h", 1)) }
    var triggerSide by remember { mutableIntStateOf(prefs.getInt("trigger_side", 0)) }
    var notifOwn by remember { mutableStateOf(prefs.getBoolean("notif_own", true)) }
    var themeMode by remember { mutableIntStateOf(prefs.getInt("theme_mode", 0)) }
    var uiStyle by remember { mutableIntStateOf(prefs.getInt("ui_style", 2)) }
    var accent by remember { mutableIntStateOf(prefs.getInt("accent", 0)) }
    var corner by remember { mutableIntStateOf(prefs.getInt("corner", 1)) }
    var bgStyle by remember { mutableIntStateOf(prefs.getInt("bg_style", 0)) }
    var blurAmt by remember { mutableFloatStateOf(prefs.getInt("blur_amt", Look.DEF_BLUR).toFloat()) }
    var dimAmt by remember { mutableFloatStateOf(prefs.getInt("dim", Look.DEF_DIM).toFloat()) }
    var longPress by remember { mutableIntStateOf(prefs.getInt("long_press", 0)) }
    // custom status bar: off by default
    var statusOn by remember { mutableStateOf(prefs.getBoolean("cs_on", false) && Settings.canDrawOverlays(ctx)) }
    var csBg by remember { mutableIntStateOf(prefs.getInt("cs_bg", 0)) }
    var csStyle by remember { mutableIntStateOf(prefs.getInt("cs_style", 0)) }
    var csScale by remember { mutableFloatStateOf(prefs.getInt("cs_scale", 100).toFloat()) }
    // Dynamic Island: a floating pill that only sits on screen
    var islandOn by remember { mutableStateOf(prefs.getBoolean("isl_on", false) && Settings.canDrawOverlays(ctx)) }
    var islW by remember { mutableIntStateOf(prefs.getInt("isl_w", IslandService.DEF_W)) }
    var islH by remember { mutableIntStateOf(prefs.getInt("isl_h", IslandService.DEF_H)) }
    var islY by remember { mutableIntStateOf(prefs.getInt("isl_y", IslandService.DEF_Y)) }
    var islX by remember { mutableIntStateOf(prefs.getInt("isl_x", IslandService.DEF_X)) }
    var page by rememberSaveable { mutableStateOf(Pg.Home) }
    var query by rememberSaveable { mutableStateOf("") }
    var entered by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = page != Pg.Home) { page = Pg.Home }
    val blurSupported = remember(resumeTick, Shell.blurTick) {
        Build.VERSION.SDK_INT >= 31 && try { activity.windowManager.isCrossWindowBlurEnabled } catch (_: Throwable) { false }
    }
    /** a theme / blur setting changed: the pull-down panels are built again with the new look */
    fun lookChanged() { OverlayService.rebuildLook() }

    DisposableEffect(activity) {
        Shell.evaluate()
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                Shell.evaluate()
                resumeTick++
            }
        }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }

    /* permission states, re-read every time the screen comes back to the front or something changes */
    var permTick by remember { mutableIntStateOf(0) }
    val overlayPerm = remember(resumeTick, permTick) { Settings.canDrawOverlays(ctx) }
    val notifPerm = remember(resumeTick, permTick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val writePerm = remember(resumeTick, permTick) { Settings.System.canWrite(ctx) }
    val dndPerm = remember(resumeTick, permTick) {
        try { ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted } catch (_: Exception) { false }
    }
    val listenerOn = remember(resumeTick, permTick) { MediaListener.hasAccess(ctx) }
    val battPerm = remember(resumeTick, permTick) {
        try { ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(pkg) } catch (_: Exception) { false }
    }

    // music tile background picture: pick from the gallery, then crop a frame out of it
    var mediaV by remember { mutableStateOf(prefs.getLong("media_bg_v", 0L)) }
    var mediaDim by remember { mutableStateOf(prefs.getInt("media_bg_dim", 25).toFloat()) }
    var cropBmp by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val b = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { MediaBg.decode(ctx, uri) }
            if (b != null) cropBmp = b else msg = "This picture could not be opened."
        }
    }
    cropBmp?.let { b ->
        ImageCropDialog(b, MediaBg.ASPECT, onCancel = { cropBmp = null }) { out ->
            MediaBg.save(ctx, out)
            mediaV = System.currentTimeMillis()
            prefs.edit().putLong("media_bg_v", mediaV).apply()
            cropBmp = null
            lookChanged()
        }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permTick++
        if (!granted) {
            // Android will not ask again: send the user to the app's notification page
            ctx.startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
            )
        }
    }

    fun grantNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (Shell.ready) scope.launch {
                Shell.exec("pm grant $pkg android.permission.POST_NOTIFICATIONS")
                delay(300); permTick++
            } else notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg))
        }
    }

    /** Notification access: one tap with AeroHUB, otherwise the system screen (its own page for this app on Android 11+). */
    fun grantListener() {
        scope.launch {
            if (Shell.ready) {
                Shell.exec("cmd notification allow_listener ${MediaListener.component(ctx).flattenToString()}")
                delay(500); permTick++
                return@launch
            }
            msg = "Enable Aero Control Center. If unavailable: App info › ⋮ › Allow restricted settings."
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    ctx.startActivity(
                        Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
                            Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                            MediaListener.component(ctx).flattenToString()
                        )
                    )
                } else {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            } catch (_: Exception) {
                try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (_: Exception) {}
            }
        }
    }

    fun grantOverlay() {
        scope.launch {
            if (Shell.ready) {
                Shell.exec("appops set $pkg SYSTEM_ALERT_WINDOW allow"); delay(300); permTick++
            } else ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
        }
    }
    fun grantWrite() {
        scope.launch {
            if (Shell.ready) {
                Shell.exec("appops set $pkg WRITE_SETTINGS allow"); delay(300); permTick++
            } else ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$pkg")))
        }
    }
    fun grantDnd() {
        scope.launch {
            if (Shell.ready) {
                Shell.exec("cmd notification allow_dnd $pkg"); delay(300); permTick++
            } else ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }
    fun grantBattery() {
        scope.launch {
            if (Shell.ready) {
                Shell.exec("cmd deviceidle whitelist +$pkg"); delay(300); permTick++
            } else ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
    /** Autostart / background-run page of the phone maker (Xiaomi and HyperOS have one); otherwise this app's own info page. */
    fun openAutostart() {
        val tries = listOf(
            Intent().setComponent(android.content.ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent().setComponent(android.content.ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"))
                .putExtra("package_name", pkg).putExtra("package_label", "Aero Control Center"),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
        )
        for (i in tries) {
            try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Throwable) {}
        }
    }
    fun grantAeroHUB() {
        if (Shell.state == Shell.State.NoPermission && !Shell.deniedForever) Shell.requestPermission(ctx)
        else if (!Shell.launchAeroHUBApp(ctx)) msg = "AeroHUB is not installed."
    }

    fun restartOverlayIfOn() {
        if (overlayOn) {
            OverlayService.stop(ctx)
            OverlayService.start(ctx)
        }
    }

    fun setOverlay(on: Boolean) {
        scope.launch {
            if (on) {
                if (!Settings.canDrawOverlays(ctx) && Shell.ready) {
                    Shell.exec("appops set $pkg SYSTEM_ALERT_WINDOW allow")
                    delay(400)
                }
                if (!Settings.canDrawOverlays(ctx)) {
                    msg = "Allow “Display over other apps”, then return."
                    pendingOverlay = true
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
                    return@launch
                }
                pendingOverlay = false
                permTick++
                                prefs.edit().putBoolean("overlay_on", true).apply()
                overlayOn = true
                OverlayService.start(ctx)
                msg = "Enabled. Swipe down from the top edge."
            } else {
                // switch the lock off first so the phone is never left without a pull-down
                if (lockOn) {
                    Shell.setStatusBarLocked(false)
                    lockOn = false
                    prefs.edit().putBoolean("lock_stock", false).apply()
                }
                pendingOverlay = false
                prefs.edit().putBoolean("overlay_on", false).apply()
                overlayOn = false
                OverlayService.stop(ctx)
                msg = ""
            }
        }
    }

    // back from the system permission screen: finish what the user started
    LaunchedEffect(resumeTick) {
        if (pendingOverlay && Settings.canDrawOverlays(ctx)) setOverlay(true)
    }

    /** Split pull-down: right half = this Control Center, left half = the phone's own notification panel. */
    fun setSplit(on: Boolean) {
        split = on
        prefs.edit().putBoolean("split", on).apply()
        if (on && lockOn) {
            // the full lock would also block the left half, so it is released
            lockOn = false
            prefs.edit().putBoolean("lock_stock", false).apply()
            scope.launch { Shell.setStatusBarLocked(false) }
        }
        restartOverlayIfOn()
        msg = if (on) "Right: Aero Control Center. Left: notifications." else ""
    }

    fun setLock(on: Boolean) {
        scope.launch {
            val ok = Shell.setStatusBarLocked(on)
            if (ok) {
                lockOn = on
                prefs.edit().putBoolean("lock_stock", on).apply()
                msg = if (on) "System panels locked."
                else "The phone’s own pull-down is back."
            } else {
                msg = "Unable to change the lock. Check that the AeroHUB server is running."
            }
        }
    }

    /** Custom status bar on / off. Needs AeroHUB (it hides the phone's own status bar) and "Display over other apps". */
    fun setStatusBar(on: Boolean) {
        scope.launch {
            if (on) {
                if (!Shell.ready) {
                    msg = "AeroHUB is required to hide the system status bar."
                    return@launch
                }
                if (!Settings.canDrawOverlays(ctx)) {
                    Shell.exec("appops set $pkg SYSTEM_ALERT_WINDOW allow")
                    delay(400)
                    permTick++
                }
                if (!Settings.canDrawOverlays(ctx)) {
                    msg = "Allow “Display over other apps” in Permissions first."
                    return@launch
                }
                // mobile network type / signal for the bar
                Shell.exec("pm grant $pkg android.permission.READ_PHONE_STATE")
                                prefs.edit().putBoolean("cs_on", true).apply()
                statusOn = true
                StatusBarService.start(ctx)
                msg = "Custom status bar enabled. Use “Restore system bars” to undo."
            } else {
                prefs.edit().putBoolean("cs_on", false).apply()
                statusOn = false
                StatusBarService.stop(ctx)
                Shell.setStatusBarHidden(false)
                msg = "Custom status bar disabled."
            }
        }
    }

    fun setIsland(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(ctx)) {
                msg = "Allow “Display over other apps” first."
                grantOverlay()
                return
            }
            prefs.edit().putBoolean("isl_on", true).apply()
            islandOn = true
            IslandService.start(ctx)
            msg = "Dynamic Island is on. It only floats and does nothing."
        } else {
            prefs.edit().putBoolean("isl_on", false).apply()
            islandOn = false
            IslandService.stop(ctx)
            msg = ""
        }
    }

    /** One tap back to the phone's own status bar and Control Center: everything this app changes is switched off. */
    fun restorePhoneBars() {
        scope.launch {
            prefs.edit()
                .putBoolean("cs_on", false)
                .putBoolean("overlay_on", false)
                .putBoolean("lock_stock", false)
                .apply()
            statusOn = false
            overlayOn = false
            lockOn = false
            pendingOverlay = false
            StatusBarService.stop(ctx)
            OverlayService.stop(ctx)
            if (Shell.ready) {
                val a = Shell.setStatusBarHidden(false)
                val b = Shell.setStatusBarLocked(false)
                msg = if (a && b) "System bars restored."
                else "Restore incomplete. Try again or restart the AeroHUB server."
            } else {
                msg = "Custom bar and pull-down disabled."
            }
        }
    }

    val tileCount = remember(page) { Tiles.enabled(ctx).size }
    val permsOk = listOf(overlayPerm, listenerOn, writePerm, dndPerm, battPerm).count { it }

    if (!entered) {
        val aerohubOk = Shell.state == Shell.State.Ready
        val items = listOf(
            GateItem("AeroHUB", when (Shell.state) {
                Shell.State.Ready -> "Connected"
                Shell.State.Connecting -> "Connecting…"
                Shell.State.NoPermission -> "Access not granted"
                Shell.State.NotRunning -> "Not running"
            }, aerohubOk, if (Shell.state == Shell.State.NoPermission && !Shell.deniedForever) "Allow" else "Open", optional = true) { grantAeroHUB() },
            GateItem("Display over other apps", "Control Center panels", overlayPerm, "Allow") { grantOverlay() },
            GateItem("Notifications", "Optional: the app works without it", notifPerm, "Allow", optional = true) { grantNotifications() },
            GateItem("Notification access", "Notifications and media", listenerOn, "Allow") { grantListener() },
            GateItem("Modify system settings", "Brightness and rotation", writePerm, "Allow") { grantWrite() },
            GateItem("Do Not Disturb access", "Focus tile", dndPerm, "Allow") { grantDnd() },
            GateItem("Unrestricted battery", "Background reliability", battPerm, "Allow") { grantBattery() }
        )
        MaterialTheme(colorScheme = darkColorScheme()) {
            SetupGate(items, msg, onSkip = { entered = true }) { entered = true }
        }
        return
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {

            /* top bar: large title on the home page, iOS back button + centred title on every other page */
            if (page == Pg.Home) {
                Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 4.dp)) {
                    Text("Settings", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("Aero Control Center", color = DIM, fontSize = 13.sp)
                }
            } else {
                Box(Modifier.fillMaxWidth().height(56.dp)) {
                    Row(
                        Modifier.align(Alignment.CenterStart).height(48.dp).clickable(role = Role.Button, onClickLabel = "Back to settings") { page = Pg.Home }.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("‹", color = BLUE, fontSize = 34.sp)
                        Spacer(Modifier.width(4.dp))
                        Text("Settings", color = BLUE, fontSize = 17.sp)
                    }
                    Text(page.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Center))
                }
            }

            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (msg.isNotEmpty()) Text(msg, color = INFO, fontSize = 13.sp)

                val bodyPull: @Composable () -> Unit = {
                        Card("Control Center") {
                            SwitchRow(
                                "Top-edge Control Center",
                                "Open Aero Control Center from any app.",
                                overlayOn, true
                            ) { setOverlay(it) }
                            if (!overlayPerm && !overlayOn) {
                                Text("Requires “Display over other apps”.", color = DIM, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { if (!OverlayService.openNow()) msg = "Enable “Top-edge Control Center” first." },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Test Aero Control Center") }
                        }

                        Card("Layout") {
                            Choice(listOf("Split", "Full width"), if (split) 0 else 1) { setSplit(it == 0) }
                            Text(
                                if (split) "Right half opens Aero Control Center. Left half opens notifications (see Notification panel)."
                                else "The selected top edge opens Aero Control Center only.",
                                color = DIM, fontSize = 12.sp
                            )
                            Text(
                                if (split && Shell.ready) "AeroHUB suppresses the system pull-down while you swipe."
                                else if (split) "Without AeroHUB, the system panel may open together with this one."
                                else if (Shell.ready) "Enable the system panel lock below for best results."
                                else "Connect AeroHUB for reliable swipe detection.",
                                color = DIM, fontSize = 12.sp
                            )
                        }

                        Card("Trigger & startup") {
                            Text("Trigger height", color = Color.White, fontSize = 14.sp)
                            Choice(listOf("Small", "Normal", "Large"), triggerH) {
                                triggerH = it; prefs.edit().putInt("trigger_h", it).apply(); restartOverlayIfOn()
                            }
                            if (!split) {
                                Text("Trigger area", color = Color.White, fontSize = 14.sp)
                                Choice(listOf("Full width", "Left half", "Right half"), triggerSide) {
                                    triggerSide = it; prefs.edit().putInt("trigger_side", it).apply(); restartOverlayIfOn()
                                }
                            }
                            PrefSwitch(
                                prefs, "land_protect", false,
                                "Landscape protection (gaming)",
                                "Off by default. When on, in landscape you must start the pull very close to the top edge, drag farther, and pull twice to open. Stops accidental opens while gaming."
                            ) { restartOverlayIfOn() }
                            PrefSwitch(prefs, "boot_start", true, "Start at boot", "Restore Control Center after restart.")
                            if (!split) {
                                SwitchRow(
                                    "Lock system panels",
                                    "Only this Aero Control Center opens on swipe.",
                                    lockOn, Shell.ready && overlayOn
                                ) { setLock(it) }
                                if (!overlayOn) Text("Enable “Top-edge Control Center” first.", color = DIM, fontSize = 12.sp)
                                else if (!Shell.ready) Text("Requires AeroHUB.", color = DIM, fontSize = 12.sp)
                                Text(
                                    "The lock is released when the AeroHUB server stops or the device restarts.",
                                    color = DIM, fontSize = 12.sp
                                )
                            }
                        }
                    }
                val bodyNotif: @Composable () -> Unit = {
                        Card("Notification panel") {
                            if (split) {
                                SwitchRow(
                                    "Custom notification panel",
                                    "Replace the system panel on the left half.",
                                    notifOwn, true
                                ) {
                                    notifOwn = it
                                    prefs.edit().putBoolean("notif_own", it).apply()
                                    restartOverlayIfOn()
                                }
                            } else {
                                Text("Set Control Center layout to Split first.", color = INFO, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { if (!OverlayService.openNotifNow()) msg = "Enable “Top-edge Control Center” first." },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Open notification panel") }
                        }
                        Card("Access") {
                            PermRow(
                                "Notification access",
                                "Required to display notifications. Nothing is stored or shared.",
                                listenerOn
                            ) { grantListener() }
                        }
                        Card("What to show") {
                            PrefSwitch(prefs, "n_ongoing", true, "Ongoing notifications", "Timers, calls and active apps.") { MediaListener.refreshNow() }
                            PrefSwitch(prefs, "n_media", false, "Music players", "Player notifications.") { MediaListener.refreshNow() }
                            PrefSwitch(prefs, "n_hide", false, "Hide content", "Show the app name only.")
                            PrefSwitch(prefs, "n_date", true, "Show date", "")
                        }
                        Card("Gestures") {
                            Text(
                                "Tap to open. Long-press for that app's notification settings. Swipe sideways to dismiss. Swipe up to close.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                    }
                val bodyTheme: @Composable () -> Unit = {
                        Card("Style") {
                            Choice(listOf("iOS", "MIUI", "HyperOS"), uiStyle) {
                                uiStyle = it; prefs.edit().putInt("ui_style", it).apply(); lookChanged()
                                // the custom status bar follows the style (unless a bar style was picked by hand)
                                StatusBarService.reload()
                            }
                            Text(
                                when (uiStyle) {
                                    1 -> "Wide tiles and sliders."
                                    2 -> "Glass tiles with labels."
                                    else -> "Square tiles and tall sliders."
                                },
                                color = DIM, fontSize = 12.sp
                            )
                            Text("Mode", color = Color.White, fontSize = 14.sp)
                            Choice(listOf("Dark", "Light", "System"), themeMode) {
                                themeMode = it; prefs.edit().putInt("theme_mode", it).apply(); lookChanged()
                            }
                        }
                        Card("Accent") {
                            Text("Color of active tiles.", color = DIM, fontSize = 12.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Look.accents.forEachIndexed { i, c ->
                                    val sel = i == accent
                                    Box(
                                        Modifier.size(44.dp)
                                            .background(c ?: Color(0xFFF3F5F9), CircleShape)
                                            .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color(0x44FFFFFF), CircleShape)
                                            .semantics { contentDescription = Look.accentNames[i.coerceIn(0, Look.accentNames.size - 1)]; selected = sel }
                                            .clickable(role = Role.RadioButton) {
                                                accent = i; prefs.edit().putInt("accent", i).apply(); lookChanged()
                                            },
                                        contentAlignment = Alignment.Center
                                    ) { if (sel) SvgIcon(Ic.check, 18.dp, if (c == null) Color(0xFF1B1D22) else Color.White) }
                                }
                            }
                            Text(Look.accentNames[accent.coerceIn(0, Look.accentNames.size - 1)], color = Color.White, fontSize = 13.sp)
                        }
                        if (uiStyle == 0) Card("Tile shape") {
                            Choice(listOf("Soft", "Rounded", "Circle"), corner) {
                                corner = it; prefs.edit().putInt("corner", it).apply(); lookChanged()
                            }
                        }
                    }
                val bodyBlur: @Composable () -> Unit = {
                        Card("Background") {
                            Choice(listOf("Blurred screen", "Gradient"), bgStyle) {
                                bgStyle = it; prefs.edit().putInt("bg_style", it).apply(); lookChanged()
                            }
                            Text(
                                if (bgStyle == 0) "Blurs the app behind the panel."
                                else "Uses a gradient behind the panel.",
                                color = DIM, fontSize = 12.sp
                            )
                            if (bgStyle == 0 && !blurSupported) Text(
                                if (Build.VERSION.SDK_INT < 31)
                                    "Blur is unavailable: this phone runs Android ${Build.VERSION.RELEASE}, blur needs Android 12 or later."
                                else
                                    if (Shell.ready)
                                        "Blur is switched off by the system on this phone (Android ${Build.VERSION.RELEASE}). AeroHUB turns the window blur on automatically; if it stays off, battery saver may be on or the phone maker does not support window blur."
                                    else
                                        "Blur is switched off by the system on this phone (Android ${Build.VERSION.RELEASE}). Allow this app in AeroHUB and the window blur is turned on automatically. Other causes: battery saver is on or the phone maker does not support window blur.",
                                color = INFO, fontSize = 12.sp
                            )
                            SliderRow(
                                "Blur", "${blurAmt.toInt()}%", blurAmt, bgStyle == 0 && blurSupported,
                                { blurAmt = it },
                                { prefs.edit().putInt("blur_amt", blurAmt.toInt()).apply(); lookChanged() }
                            )
                            SliderRow(
                                "Tint", "${dimAmt.toInt()}%", dimAmt, true,
                                { dimAmt = it },
                                { prefs.edit().putInt("dim", dimAmt.toInt()).apply(); lookChanged() }
                            )
                        }
                        OutlinedButton(
                            onClick = {
                                blurAmt = Look.DEF_BLUR.toFloat(); dimAmt = Look.DEF_DIM.toFloat(); bgStyle = 0
                                prefs.edit().putInt("blur_amt", Look.DEF_BLUR).putInt("dim", Look.DEF_DIM).putInt("bg_style", 0).apply()
                                lookChanged()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Reset to default") }
                    }
                val bodyTiles: @Composable () -> Unit = { Card("Tiles") {
                        val state = remember {
                            mutableStateMapOf<String, Boolean>().apply {
                                // tiles of other apps are counted from the start too (they were only counted after being switched here)
                                val shown = Tiles.enabled(ctx).toSet()
                                Tiles.all.forEach { put(it.id, it.id in shown) }
                                QsTiles.installed(ctx).forEach { put(it.id, it.id in shown) }
                            }
                        }
                        val count = state.values.count { it }
                        Text("Select up to ${Tiles.MAX} tiles ($count selected).", color = DIM, fontSize = 12.sp)
                        Tiles.all.forEach { d ->
                            val on = state[d.id] == true
                            SwitchRow(d.label, "", on, on || count < Tiles.MAX) {
                                Tiles.setOn(ctx, d.id, it)
                                // show what was really saved (an add is refused when 16 are already on)
                                state[d.id] = d.id in Tiles.enabled(ctx)
                                lookChanged()
                            }
                        }
                        val qs = remember { QsTiles.installed(ctx) }
                        if (qs.isNotEmpty()) {
                            Text("Tiles of other apps (needs AeroHUB to press them)", color = DIM, fontSize = 12.sp)
                            qs.forEach { d ->
                                val on = state[d.id] == true
                                SwitchRow(d.label, "", on, on || count < Tiles.MAX) {
                                    Tiles.setOn(ctx, d.id, it)
                                    state[d.id] = d.id in Tiles.enabled(ctx)
                                    lookChanged()
                                }
                            }
                        }
                        Text("Wi-Fi, mobile data, brightness, volume and media are always shown.", color = DIM, fontSize = 12.sp)
                    }
}
                val bodyMedia: @Composable () -> Unit = {
                        Card("Background photo") {
                            val shot = remember(mediaV) { MediaBg.load(ctx) }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            Box(
                                Modifier.fillMaxWidth(0.62f)
                                    .aspectRatio(MediaBg.ASPECT)
                                    .clip(RoundedCornerShape(16.dp)).background(Color(0xFF2C2C2E)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (shot != null) {
                                    Image(shot, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = mediaDim / 100f)))
                                } else Text("No photo", color = DIM, fontSize = 14.sp)
                            }
                            }
                            Button(onClick = { pickPhoto.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (shot != null) "Choose another photo" else "Choose from gallery")
                            }
                            if (shot != null) OutlinedButton(onClick = {
                                MediaBg.clear(ctx)
                                mediaV = 0L
                                prefs.edit().putLong("media_bg_v", 0L).apply()
                                lookChanged()
                            }, modifier = Modifier.fillMaxWidth()) { Text("Remove photo") }
                            Text(
                                "Pick any big photo, then move and zoom it to choose the frame. The photo sits behind the previous, play and next buttons of the music tile.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                        Card("Dark layer") {
                            SliderRow(
                                "Darkness", "${mediaDim.toInt()}%", mediaDim, true,
                                { mediaDim = it },
                                { prefs.edit().putInt("media_bg_dim", mediaDim.toInt()).apply(); lookChanged() },
                                0f..80f
                            )
                            Text("A darker layer keeps the buttons easy to see on bright photos.", color = DIM, fontSize = 12.sp)
                        }
                    }
                val bodyBehavior: @Composable () -> Unit = {
                        Card("General") {
                            PrefSwitch(prefs, "haptic", true, "Haptic feedback", "")
                            PrefSwitch(prefs, "hints", true, "Status messages", "Show brief confirmations.")
                            Text("Long press on Wi-Fi and Data", color = Color.White, fontSize = 14.sp)
                            Choice(listOf("Internet panel", "Full settings"), longPress) {
                                longPress = it; prefs.edit().putInt("long_press", it).apply()
                            }
                            Text(
                                if (longPress == 0) "Opens the floating Internet panel."
                                else "Opens system network settings.",
                                color = DIM, fontSize = 12.sp
                            )
                            PrefSwitch(
                                prefs, "clock24", android.text.format.DateFormat.is24HourFormat(ctx),
                                "24-hour clock", "Applies to the notification panel."
                            )
                        }
                    }

                when (page) {

                    /* ================= HOME: one row per group ================= */
                    Pg.Home -> {
                        // One simple "what to do next" banner: it always shows the single next step.
                        val next: Triple<String, String, Pg?> = when {
                            permsOk < 5 -> Triple("Step 1: Allow permissions", "$permsOk of 5 allowed. Tap here to allow the rest.", Pg.Perms)
                            !overlayOn -> Triple("Step 2: Turn on Control Center", "One switch, then you are done. Tap here.", Pg.Pull)
                            else -> Triple("All set", "Swipe down from the top of the screen to try it.", null)
                        }
                        val ready = next.third == null
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .background(if (ready) Color(0x2230D158) else Color(0x33FF9F0A))
                                .clickable(enabled = !ready) { next.third?.let { page = it } }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(next.first, color = if (ready) OK else Color(0xFFFF9F0A), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                Text(next.second, color = DIM, fontSize = 13.sp)
                            }
                            if (!ready) SvgIcon(Ic.chevronRight, 14.dp, Color(0xFFFF9F0A))
                        }

                        Button(onClick = onOpenControlCenter, modifier = Modifier.fillMaxWidth()) { Text("Open Aero Control Center") }

                        val aerohubSummary = when (Shell.state) {
                            Shell.State.Ready -> "Connected"
                            Shell.State.Connecting -> "Connecting…"
                            Shell.State.NoPermission -> "Not allowed yet · tap to fix"
                            Shell.State.NotRunning -> "Not running · tap to fix"
                        }
                        val themeSummary = listOf("Dark", "Light", "System")[themeMode.coerceIn(0, 2)] + " · " +
                            Look.accentNames[accent.coerceIn(0, Look.accentNames.size - 1)]
                        val onOff = { b: Boolean -> if (b) "On" else "Off" }

                        // every setting page, so it can be found by typing a word
                        val index = listOf(
                            SearchItem(Ic.plug, Color(0xFF5E5CE6), "AeroHUB", aerohubSummary, "connect server shizuku adb allow access", Pg.AeroHUB),
                            SearchItem(Ic.shield, Color(0xFF30D158), "Permissions", "$permsOk of 5 allowed", "overlay display over other apps notifications access write system settings do not disturb dnd battery allow", Pg.Perms),
                            SearchItem(Ic.controlCenter, Color(0xFF0A84FF), "Pull-down trigger", onOff(overlayOn) + " · switch, layout, height, start at boot", "top edge swipe overlay split full width left right landscape gaming lock system panels boot startup test", Pg.Pull),
                            SearchItem(Ic.bellIos, Color(0xFFFF9F0A), "Notification panel", "Custom panel, what to show", "notifications ongoing music hide content date gestures access", Pg.Notif),
                            SearchItem(Ic.tilesIos, Color(0xFF0A84FF), "Tiles", "Choose up to ${Tiles.MAX} tiles", "wifi bluetooth hotspot flashlight airplane focus calculator camera timer qr choose select add remove", Pg.Tiles),
                            SearchItem(Ic.sliders, Color(0xFF8E8E93), "Behavior", "Haptics, messages, long press, clock", "vibrate haptic feedback hints status messages long press wifi data internet panel 24-hour clock time", Pg.Behavior),
                            SearchItem(Ic.cellIos, Color(0xFF30D158), "Status bar", if (statusOn) "Custom bar is on" else "Using the phone's own bar", "network speed notification icons volte size text colour dark light landscape hide restore", Pg.Status),
                            SearchItem(Ic.blur, Color(0xFF636366), "Dynamic Island", onOff(islandOn), "pill camera dot width height position size floating", Pg.Island),
                            SearchItem(Ic.palette, Color(0xFFBF5AF2), "Theme", themeSummary, "style ios miui hyperos dark light system mode accent colour color tile shape corner", Pg.Theme),
                            SearchItem(Ic.blur, Color(0xFF5AC8FA), "Blur & background", "Blur, tint, gradient", "blur tint dim gradient background wallpaper reset", Pg.Blur),
                            SearchItem(Ic.music, Color(0xFFFF2D55), "Music tile photo", "Background picture for the music tile", "music photo picture gallery crop darkness now playing", Pg.Media),
                            SearchItem(Ic.info, Color(0xFF0A84FF), "Help & About", "How to use, version, developer", "help guide setup version about developer contact email license", Pg.Help)
                        )

                        SearchField(query, { query = it })

                        if (query.isNotBlank()) {
                            val words = query.trim().lowercase().split(Regex("\\s+"))
                            val hits = index.filter { s ->
                                val hay = (s.title + " " + s.summary + " " + s.keywords).lowercase()
                                words.all { hay.contains(it) }
                            }
                            if (hits.isEmpty()) {
                                Text("No setting found for “${query.trim()}”.", color = DIM, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 16.dp))
                            } else Group {
                                hits.forEachIndexed { i, s ->
                                    NavRow(s.icon, s.tint, s.title, s.summary, last = i == hits.lastIndex) { query = ""; page = s.page }
                                }
                            }
                        } else {

                        SectionLabel("Setup")
                        Group {
                            NavRow(Ic.plug, Color(0xFF5E5CE6), "AeroHUB", aerohubSummary) { page = Pg.AeroHUB }
                            NavRow(Ic.shield, Color(0xFF30D158), "Permissions", "$permsOk of 5 allowed", last = true) { page = Pg.Perms }
                        }

                        SectionLabel("Control Center")
                        Group {
                            NavRow(Ic.controlCenter, Color(0xFF0A84FF), "Pull-down trigger", onOff(overlayOn) + " · switch, layout, height, start at boot") { page = Pg.Pull }
                            NavRow(Ic.bellIos, Color(0xFFFF9F0A), "Notification panel", "Custom panel, what to show") { page = Pg.Notif }
                            NavRow(Ic.tilesIos, Color(0xFF0A84FF), "Tiles", "$tileCount of ${Tiles.MAX} chosen") { page = Pg.Tiles }
                            NavRow(Ic.sliders, Color(0xFF8E8E93), "Behavior", "Haptics, messages, long press, clock", last = true) { page = Pg.Behavior }
                        }

                        SectionLabel("Screen")
                        Group {
                            NavRow(Ic.cellIos, Color(0xFF30D158), "Status bar", if (statusOn) "Custom bar is on" else "Using the phone's own bar") { page = Pg.Status }
                            NavRow(Ic.blur, Color(0xFF636366), "Dynamic Island", onOff(islandOn), last = true) { page = Pg.Island }
                        }

                        SectionLabel("Appearance")
                        Group {
                            NavRow(Ic.palette, Color(0xFFBF5AF2), "Theme", themeSummary) { page = Pg.Theme }
                            NavRow(Ic.blur, Color(0xFF5AC8FA), "Blur & background", "Blur, tint, gradient") { page = Pg.Blur }
                            NavRow(Ic.music, Color(0xFFFF2D55), "Music tile photo", "Background picture for the music tile", last = true) { page = Pg.Media }
                        }

                        SectionLabel("Help")
                        Group {
                            NavRow(Ic.info, Color(0xFF0A84FF), "Help & About", "How to use, version, developer", last = true) { page = Pg.Help }
                        }

                        SectionLabel("Something went wrong?")
                        Button(onClick = { restorePhoneBars() }, modifier = Modifier.fillMaxWidth(), bg = CARD, fg = RED) {
                            Text("Restore system bars")
                        }
                        Text(
                            "Turns off everything this app changed and gives you the phone's normal status bar and pull-down back.",
                            color = DIM, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        }
                    }

                    /* ================= SHIZUKU ================= */
                    Pg.AeroHUB -> Card("AeroHUB") {
                        val (text, ok) = when (Shell.state) {
                            Shell.State.Ready -> "Connected. System toggles run through AeroHUB." to true
                            Shell.State.Connecting -> "Connecting…" to false
                            Shell.State.NoPermission ->
                                (if (Shell.deniedForever) "AeroHUB blocked this app. In AeroHUB, open Apps and switch on Aero Control Center, then tap Allow here."
                                else "AeroHUB is running. Access has not been granted.") to false
                            Shell.State.NotRunning -> (when {
                                Shell.notInstalled -> "AeroHUB is not installed. Install the AeroHUB app first."
                                Shell.outdated -> "AeroHUB server is outdated. Open AeroHUB and tap Restart server."
                                else -> "AeroHUB server is not running. Open AeroHUB and start the server."
                            }) to false
                        }
                        Text(text, color = if (ok) OK else DIM, fontSize = 14.sp)
                        when (Shell.state) {
                            Shell.State.NoPermission -> if (!Shell.deniedForever) {
                                Button(onClick = { Shell.requestPermission(ctx) }) { Text("Allow") }
                            } else {
                                Button(onClick = { if (!Shell.launchAeroHUBApp(ctx)) msg = "AeroHUB is not installed." }) { Text("Open AeroHUB") }
                            }
                            Shell.State.NotRunning ->
                                Button(onClick = { if (!Shell.launchAeroHUBApp(ctx)) msg = "AeroHUB is not installed." }) { Text("Open AeroHUB") }
                            else -> {}
                        }
                        Text("Without AeroHUB, controls open the matching system screen.", color = DIM, fontSize = 12.sp)
                    }

                    /* ================= CONTROL CENTER (everything, by category) ================= */
                    Pg.Pull -> bodyPull()
                    Pg.Notif -> bodyNotif()
                    Pg.Tiles -> bodyTiles()
                    Pg.Behavior -> bodyBehavior()

                    /* ================= STATUS BAR ================= */
                    Pg.Status -> {
                        Card("Custom status bar") {
                            SwitchRow(
                                "Custom status bar",
                                "Replaces the system status bar.",
                                statusOn, true
                            ) { setStatusBar(it) }
                            if (Shell.state != Shell.State.Ready) {
                                Text("Requires AeroHUB.", color = INFO, fontSize = 12.sp)
                            }
                            Text(
                                "The system bar returns when the AeroHUB server stops or via “Restore system bars”.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                        Card("Bar style") {
                            Choice(listOf("Match", "iOS", "MIUI", "HyperOS"), csStyle) {
                                csStyle = it; prefs.edit().putInt("cs_style", it).apply(); StatusBarService.reload()
                            }
                            Text(
                                if (csStyle == 0)
                                    "The bar follows the Control Center style: " + listOf("iOS", "MIUI", "HyperOS")[uiStyle.coerceIn(0, 2)] + ". Change the style in Theme and the bar changes with it."
                                else "Fixed look, whatever the Control Center style is.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                        Card("What to show") {
                            PrefSwitch(prefs, "cs_speed", true, "Network speed", "Live upload and download.") { StatusBarService.reload() }
                            PrefSwitch(prefs, "cs_notif", true, "Notification icons", "Requires notification access.") { StatusBarService.reload() }
                            PrefSwitch(prefs, "cs_volte", true, "VoLTE badge", "Shown on LTE.") { StatusBarService.reload() }
                        }
                        Card("Look") {
                            SliderRow(
                                "Bar size", "${csScale.toInt()}%", csScale, true,
                                { csScale = it },
                                { prefs.edit().putInt("cs_scale", csScale.toInt()).apply(); StatusBarService.reload() },
                                range = 70f..150f
                            )
                            Text("Makes the text, icons and the bar itself smaller or bigger. 100% is normal.", color = DIM, fontSize = 12.sp)
                            Text("Text colour", color = Color.White, fontSize = 14.sp)
                            PrefSwitch(prefs, "cs_autoink", true, "Auto text colour", "Dark text on light apps, white text on dark apps.") { StatusBarService.reload() }
                            PrefSwitch(prefs, "cs_darkink", false, "Always dark text", "Used only when Auto text colour is off.") { StatusBarService.reload() }
                            Text("The background is transparent. The custom bar is drawn in portrait only.", color = DIM, fontSize = 12.sp)
                        }
                        Card("Landscape") {
                            PrefSwitch(
                                prefs, "cs_land_auto", true, "Auto-hide bars in landscape",
                                "Status bar and navigation buttons hide. Swipe from any screen edge to show them for 2 seconds. Needs the pull-down watcher (AeroHUB) to be on."
                            ) { StatusBarService.reload() }
                        }
                        Card("Troubleshooting") {
                            Text("Debug: " + prefs.getString("cs_dbg", "no reading yet"), color = DIM, fontSize = 11.sp)
                        }
                    }

                    /* ================= DYNAMIC ISLAND ================= */
                    Pg.Island -> {
                        Card("Dynamic Island") {
                            SwitchRow(
                                "Dynamic Island",
                                "A black pill that only floats at the top. No touch, no actions.",
                                islandOn, true
                            ) { setIsland(it) }
                            if (!overlayPerm) Text("Requires “Display over other apps”.", color = INFO, fontSize = 12.sp)
                            if (!islandOn) Text("Switch it on to see changes while you adjust.", color = DIM, fontSize = 12.sp)
                        }
                        Card("Size") {
                            SliderRow("Width", "$islW dp", islW.toFloat(), true,
                                { islW = it.toInt() }, { prefs.edit().putInt("isl_w", islW).apply() }, 40f..240f)
                            SliderRow("Height", "$islH dp", islH.toFloat(), true,
                                { islH = it.toInt() }, { prefs.edit().putInt("isl_h", islH).apply() }, 16f..70f)
                        }
                        Card("Position") {
                            SliderRow("Distance from top", "$islY dp", islY.toFloat(), true,
                                { islY = it.toInt() }, { prefs.edit().putInt("isl_y", islY).apply() }, 0f..80f)
                            SliderRow("Left / right", (if (islX > 0) "+" else "") + "$islX dp", islX.toFloat(), true,
                                { islX = it.toInt() }, { prefs.edit().putInt("isl_x", islX).apply() }, -160f..160f)
                            OutlinedButton(
                                onClick = {
                                    islW = IslandService.DEF_W; islH = IslandService.DEF_H
                                    islY = IslandService.DEF_Y; islX = IslandService.DEF_X
                                    prefs.edit().putInt("isl_w", islW).putInt("isl_h", islH)
                                        .putInt("isl_y", islY).putInt("isl_x", islX).apply()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Reset size and position") }
                        }
                        Card("Look") {
                            PrefSwitch(prefs, "isl_lens", true, "Camera dot", "A faint lens on the right side, like the real island.")
                            PrefSwitch(prefs, "isl_hide_land", true, "Hide in landscape", "")
                        }
                    }

                    /* ================= THEME (everything about the look) ================= */
                    Pg.Theme -> bodyTheme()
                    Pg.Blur -> bodyBlur()
                    Pg.Media -> bodyMedia()

                    /* ================= PERMISSIONS ================= */
                    Pg.Perms -> Card("Permissions") {
                        PermRow("Display over other apps", "Required for the Control Center panels.", overlayPerm) { grantOverlay() }
                        PermRow("Notifications (optional)", "Not needed: the app works with notifications off.", notifPerm) { grantNotifications() }
                        PermRow(
                            "Notification access",
                            "Notifications panel and media controls.",
                            listenerOn
                        ) { grantListener() }
                        PermRow("Modify system settings", "Smooth brightness control.", writePerm) { grantWrite() }
                        PermRow("Do Not Disturb access", "Focus tile without AeroHUB.", dndPerm) { grantDnd() }
                        PermRow("Unrestricted battery", "Keeps Control Center active in the background.", battPerm) { grantBattery() }
                        Text(
                            "To keep it running 24 hours: turn Autostart on for this app, set its battery saver to “No restrictions”, and lock the app in the recent apps list.",
                            color = DIM, fontSize = 12.sp
                        )
                        OutlinedButton(onClick = { openAutostart() }, small = true) { Text("Open Autostart settings") }
                    }

                    /* ================= HELP & ABOUT ================= */
                    Pg.Help -> {
                        Card("Setup") {
                            Text(
                                "1. Open Permissions and allow every item.\n" +
                                    "2. Open Control Center and turn the switch on.\n" +
                                    "3. Optional: open AeroHUB, start the server and tap Allow in this app for extra features.\n" +
                                    "4. Swipe down from the top of the screen. Right side opens Control Center, left side opens notifications.\n\n" +
                                    "Problem? Go back to Settings and tap Restore system bars.",
                                color = DIM, fontSize = 13.sp
                            )
                        }
                        Card("About") {
                            val ver = remember {
                                try { ctx.packageManager.getPackageInfo(pkg, 0).versionName ?: "" } catch (_: Exception) { "" }
                            }
                            Text("Aero Control Center $ver", color = Color.White, fontSize = 14.sp)
                            Text("MIT License", color = DIM, fontSize = 12.sp)
                        }
                        DeveloperCard("Foysal", "foysal.8575@gmail.com")
                    }
                }
                Box(Modifier.padding(8.dp))
            }
        }
    }
}

private enum class Pg(val title: String) {
    Home("Settings"),
    AeroHUB("AeroHUB"),
    Pull("Pull-down trigger"),
    Notif("Notification panel"),
    Tiles("Tiles"),
    Behavior("Behavior"),
    Status("Status bar"),
    Island("Dynamic Island"),
    Theme("Theme"),
    Blur("Blur & background"),
    Media("Music tile photo"),
    Perms("Permissions"),
    Help("Help & About")
}

/** iOS "inset grouped" section: small grey header above, rounded dark container below. */
@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(
            title.uppercase(), color = DIM, fontSize = 13.sp,
            modifier = Modifier.padding(start = 16.dp).semantics { heading() }
        )
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CARD).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) { content() }
    }
}

private class SearchItem(
    val icon: List<El>, val tint: Color, val title: String, val summary: String, val keywords: String, val page: Pg
)

/** Search box at the top of the settings home: type a word, jump straight to the page that has it. */
@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp)).background(CARD)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("🔍", fontSize = 16.sp, modifier = Modifier.clearAndSetSemantics { })
        Box(Modifier.weight(1f).padding(vertical = 12.dp)) {
            if (value.isEmpty()) Text("Search settings", color = DIM, fontSize = 17.sp, modifier = Modifier.clearAndSetSemantics { })
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                cursorBrush = SolidColor(BLUE),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Search settings" }
            )
        }
        if (value.isNotEmpty()) Box(
            Modifier.size(48.dp).clip(CircleShape)
                .clickable(role = Role.Button, onClickLabel = "Clear search") { onChange("") },
            contentAlignment = Alignment.Center
        ) { SvgIcon(Ic.close, 16.dp, DIM) }
    }
}

/** Small grey heading above a group on the settings home. */
@Composable
private fun SectionLabel(text: String) {
    Text(
        text.uppercase(), color = DIM, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 16.dp, top = 6.dp).offset(y = 4.dp).semantics { heading() }
    )
}

/** Rounded container for a block of [NavRow]s. */
@Composable
private fun Group(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CARD)) { content() }
}

/** Who made the app: round initial, role, name and a tappable e-mail address (opens the mail app). */
@Composable
private fun DeveloperCard(name: String, email: String) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(CARD)
            .clickable {
                try {
                    ctx.startActivity(
                        Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email"))
                            .putExtra(Intent.EXTRA_SUBJECT, "Aero Control Center")
                    )
                } catch (_: Exception) {
                }
            }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(Modifier.size(56.dp).background(Color(0xFF5E5CE6), CircleShape), contentAlignment = Alignment.Center) {
            Text(name.take(1).uppercase(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Developer", color = DIM, fontSize = 13.sp)
            Text(name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(email, color = BLUE, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** A row of the settings home: coloured rounded-square icon, title, summary, chevron, inset separator. */
@Composable
private fun NavRow(icon: List<El>, tint: Color, title: String, summary: String, last: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(role = Role.Button) { onClick() }.padding(start = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(30.dp).background(tint, RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
            SvgIcon(icon, 18.dp, Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(title, color = Color.White, fontSize = 17.sp)
                    Text(summary, color = DIM, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                SvgIcon(Ic.chevronRight, 14.dp, Color(0x4DEBEBF5))
            }
            if (!last) Box(Modifier.fillMaxWidth().height(0.5.dp).background(SEP))
        }
    }
}

/** iOS filled button (blue by default). */
@Composable
private fun Button(
    onClick: () -> Unit, modifier: Modifier = Modifier, bg: Color = BLUE, fg: Color = Color.White,
    content: @Composable () -> Unit
) {
    Row(
        modifier.heightIn(min = 50.dp).clip(RoundedCornerShape(12.dp)).background(bg).clickable(role = Role.Button) { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        CompositionLocalProvider(LocalContentColor provides fg) {
            ProvideTextStyle(TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)) { content() }
        }
    }
}

/** iOS secondary button: grey fill, blue text. */
@Composable
private fun OutlinedButton(onClick: () -> Unit, modifier: Modifier = Modifier, small: Boolean = false, content: @Composable () -> Unit) {
    Row(
        modifier.heightIn(min = 48.dp)
            .clip(if (small) CircleShape else RoundedCornerShape(10.dp)).background(Color(0xFF2C2C2E)).clickable(role = Role.Button) { onClick() }
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        CompositionLocalProvider(LocalContentColor provides BLUE) {
            ProvideTextStyle(TextStyle(fontSize = if (small) 15.sp else 17.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)) { content() }
        }
    }
}

/** iOS switch: 51 x 31 green pill with a white knob. */
@Composable
private fun Switch(checked: Boolean, enabled: Boolean = true) {
    val x by animateDpAsState(if (checked) 20.dp else 0.dp, tween(200), label = "sw")
    val bg by animateColorAsState(if (checked) OK else Color(0xFF39393D), tween(200), label = "swc")
    Box(
        Modifier.size(51.dp, 31.dp).alpha(if (enabled) 1f else 0.4f).background(bg, CircleShape)
            .padding(2.dp)
    ) {
        Box(Modifier.offset(x = x).size(27.dp).shadow(3.dp, CircleShape).background(Color.White, CircleShape))
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    // the whole row is the switch: a big target, and one "switch" item for screen readers
    Row(
        Modifier.fillMaxWidth().heightIn(min = 48.dp)
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChange),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp)
            if (sub.isNotEmpty()) Text(sub, color = DIM, fontSize = 13.sp)
        }
        Switch(checked = checked, enabled = enabled)
    }
}

/** A switch stored in the shared preferences. [onChange] runs after it was saved. */
@Composable
private fun PrefSwitch(
    prefs: SharedPreferences, key: String, def: Boolean, title: String, sub: String,
    onChange: (Boolean) -> Unit = {}
) {
    var on by remember { mutableStateOf(prefs.getBoolean(key, def)) }
    SwitchRow(title, sub, on, true) {
        on = it
        prefs.edit().putBoolean(key, it).apply()
        onChange(it)
    }
}

/** A slider with a title and the current value. [onDone] runs when the finger is lifted. */
@Composable
private fun SliderRow(
    title: String, valueText: String, value: Float, enabled: Boolean,
    onChange: (Float) -> Unit, onDone: () -> Unit,
    range: ClosedFloatingPointRange<Float> = 0f..100f
) {
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = if (enabled) Color.White else DIM, fontSize = 17.sp)
            Text(valueText, color = DIM, fontSize = 17.sp)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range, enabled = enabled,
            onValueChangeFinished = onDone,
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = BLUE, inactiveTrackColor = Color(0xFF3A3A3C),
                disabledThumbColor = Color(0xFFBDBDC2), disabledActiveTrackColor = Color(0xFF48484A), disabledInactiveTrackColor = Color(0xFF3A3A3C)
            )
        )
    }
}

@Composable
private fun PermRow(title: String, sub: String, granted: Boolean, onGrant: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 48.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp)
            Text(sub, color = DIM, fontSize = 13.sp)
        }
        if (granted) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Allowed", color = OK, fontSize = 15.sp)
            SvgIcon(Ic.check, 14.dp, OK)
        }
        else OutlinedButton(onClick = onGrant, small = true) { Text("Allow") }
    }
}

/** iOS segmented control: grey track, the selected segment is a lighter pill. */
@Composable
private fun Choice(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp)).background(Color(0xFF2C2C2E)).padding(2.dp)) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).heightIn(min = 44.dp).clip(RoundedCornerShape(7.dp))
                    .background(if (sel) Color(0xFF636366) else Color.Transparent)
                    .semantics { selected = sel }
                    .clickable(role = Role.RadioButton) { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = Color.White, fontSize = 15.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp))
            }
        }
    }
}

private class GateItem(val title: String, val sub: String, val ok: Boolean, val action: String, val optional: Boolean = false, val onGrant: () -> Unit)

/** First screen: everything must be granted before the app opens. */
@Composable
private fun SetupGate(items: List<GateItem>, msg: String, onSkip: () -> Unit, onContinue: () -> Unit) {
    val done = items.count { it.ok }
    val all = items.all { it.ok || it.optional }
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 8.dp)) {
            Text("Setup", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("$done of ${items.size} allowed · you can also skip and allow them later in Settings › Permissions", color = DIM, fontSize = 13.sp)
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (msg.isNotEmpty()) Text(msg, color = INFO, fontSize = 13.sp)
            Group {
                items.forEachIndexed { i, it ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Row(Modifier.fillMaxWidth().heightIn(min = 60.dp).padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f).padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                    Text(it.title, color = Color.White, fontSize = 17.sp)
                                    Text(it.sub, color = DIM, fontSize = 13.sp)
                                }
                                if (it.ok) SvgIcon(Ic.check, 18.dp, OK)
                                else OutlinedButton(onClick = it.onGrant, small = true) { Text(it.action) }
                            }
                            if (i < items.size - 1) Box(Modifier.fillMaxWidth().height(0.5.dp).background(SEP))
                        }
                    }
                }
            }
            Text("AeroHUB is optional. If its server is running, permissions are granted in one tap and extra features work.", color = DIM, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { if (all) onContinue() }, modifier = Modifier.fillMaxWidth(),
                bg = if (all) BLUE else Color(0xFF2C2C2E), fg = if (all) Color.White else DIM
            ) { Text("Continue") }
            if (!all) OutlinedButton(onClick = onSkip, modifier = Modifier.fillMaxWidth()) { Text("Skip for now") }
        }
    }
}
