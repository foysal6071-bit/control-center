package com.aerocontrolcenter.app

import android.app.Dialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import android.view.animation.DecelerateInterpolator
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.aerocontrolcenter.app.ui.ControlCenterApp
import com.aerocontrolcenter.app.ui.NotificationPanelApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Opens this app's Control Center as an overlay on top of every app when you pull down from the top.
 *
 *  - With AeroHUB the raw touch screen events are watched (see Shell), so the swipe is seen even
 *    where the phone's own status bar sits above every overlay. No accessibility service is used.
 *  - Without AeroHUB a thin invisible strip over the top edge catches the swipe (works where the phone
 *    lets an overlay sit on the status bar).
 *
 * The panel window is built once, in the background, and only shown / hidden afterwards, so pulling down
 * does not have to build the whole screen at that moment (this is what made it lag before).
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val owner = ViewOwner()
    private val strips = mutableListOf<View>()
    private val main = Handler(Looper.getMainLooper())

    /** One overlay window: the Control Center (notif = false) or the notification panel (notif = true). */
    private inner class Host(val notif: Boolean) {
        var frame: PanelFrame? = null
        var dialog: PanelDialog? = null
        var view: ComposeView? = null
        var rotation = -1
        var shown = false
        var builtBlur = false
        val active = mutableStateOf(false)
    }

    private val cc = Host(false)
    private val nt = Host(true)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val r = rotation()
            if (r == lastRotation) return
            lastRotation = r
            Shell.setPullRotation(r)
            // let the system finish the rotation first, then use the new screen size
            main.postDelayed({
                if (instance !== this@OverlayService) return@postDelayed
                rebuildStrips()
                // start the touch watcher again with the values of the new orientation
                startTouchWatch()
                // build the hidden panels again for the new orientation, so the first pull in it is instant
                if (!cc.shown && !nt.shown) rebuildLook()
            }, 250L)
        }
    }
    private var lastRotation = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // startForegroundService() requires startForeground() right away, even if we stop again below
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WindowManager::class.java)
        owner.resume()
        addStrips()
        instance = this
        running = true
        lastRotation = rotation()
        try {
            getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, main)
        } catch (_: Exception) {
        }
        startTouchWatch()
        // build the panels in the background so the first pull-down is instant
        main.postDelayed({
            if (instance === this) {
                ensure(cc)
                if (notifOwn()) ensure(nt)
                // never used for a while: free the memory (rebuilt on the next pull), like after every use
                main.removeCallbacks(idleFree)
                main.postDelayed(idleFree, 120_000L)
            }
        }, 600)
        val prefs = getSharedPreferences("cc", Context.MODE_PRIVATE)
        if (splitMode()) {
            // Split mode never keeps the phone's own pull-down locked: its left half must open the notification panel.
            if (prefs.getBoolean("lock_stock", false)) prefs.edit().putBoolean("lock_stock", false).apply()
            scope.launch { Shell.setStatusBarLocked(false) }
        } else if (prefs.getBoolean("lock_stock", false)) {
            // after a restart: put the lock of the phone's own pull-down back (no-op if AeroHUB is not ready yet)
            scope.launch { Shell.setStatusBarLocked(true) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        instance = null
        main.removeCallbacksAndMessages(null)
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener) } catch (_: Exception) {}
        Shell.unwatchPull()
        stopNavClose()
        try { destroy(cc) } catch (_: Exception) {}
        try { destroy(nt) } catch (_: Exception) {}
        removeStrips()
        owner.destroy()
        // Never leave the phone without any pull-down: when the trigger is gone, unlock the stock one.
        scope.launch { Shell.setStatusBarLocked(false) }
        super.onDestroy()
    }

    /* ---------- foreground notification ---------- */

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("cc_overlay", "Aero Control Center", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_SETTINGS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, "cc_overlay")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Aero Control Center is on")
            .setContentText(
                if (splitMode()) "Top right: Aero Control Center · top left: notifications"
                else "Pull down from the top of the screen · tap for settings"
            )
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    /* ---------- trigger ---------- */

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun systemDimen(name: String, fallbackDp: Float): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(fallbackDp).toInt()
    }

    private fun rotation(): Int = try {
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
    } catch (_: Exception) {
        Surface.ROTATION_0
    }

    /**
     * Split pull-down (on by default): a pull on the right half opens this Control Center, a pull on the left
     * half is left alone so the phone's own notification panel opens.
     */
    private fun splitMode(): Boolean = getSharedPreferences("cc", Context.MODE_PRIVATE).getBoolean("split", true)

    /** Split mode + "own notification panel": the left half opens this app's notification panel instead of the phone's. */
    private fun notifOwn(): Boolean =
        splitMode() && getSharedPreferences("cc", Context.MODE_PRIVATE).getBoolean("notif_own", true)

    /**
     * Which part of the top edge is watched: 0 = full width (the half is reported), 1 = left half, 2 = right half.
     * Split + own notification panel: both halves. Split only: the right half. Otherwise the "Trigger area" setting.
     */
    private fun triggerSide(): Int =
        if (splitMode()) (if (notifOwn()) 0 else 2)
        else getSharedPreferences("cc", Context.MODE_PRIVATE).getInt("trigger_side", 0)

    private fun isLandscape(): Boolean = rotation().let { it == Surface.ROTATION_90 || it == Surface.ROTATION_270 }

    /**
     * Optional landscape protection (gaming): the pull must start very close to the top edge, must be a long
     * deliberate drag, and has to be done twice (the first pull only arms it, the second one opens the panel).
     * OFF by default: in landscape the panels open with the same swipe as in portrait.
     * (New key "land_protect": the old "land_two_pull" default was ON, which made landscape almost impossible to open.)
     */
    private fun landTwoStep(): Boolean =
        isLandscape() && getSharedPreferences("cc", Context.MODE_PRIVATE).getBoolean("land_protect", false)

    /** Same switch: thin edge and long drag are used only while "Landscape protection" is on. */
    private fun landSafe(): Boolean = landTwoStep()

    private var armedUntil = 0L

    /** Returns true when the panel may open now. In landscape the first pull only arms it and shows a hint. */
    private fun passGate(): Boolean {
        if (!landTwoStep()) return true
        val now = android.os.SystemClock.elapsedRealtime()
        if (now < armedUntil) {
            armedUntil = 0L
            return true
        }
        armedUntil = now + 3000L
        try {
            android.widget.Toast.makeText(this, "Pull down again to open", android.widget.Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
        }
        return false
    }

    /** Height of the trigger area in px, from the "Trigger height" setting. */
    private fun triggerHeight(): Int {
        if (landSafe()) return dp(8f).toInt()   // very close to the screen edge
        val prefs = getSharedPreferences("cc", Context.MODE_PRIVATE)
        val base = systemDimen("status_bar_height", 26f).coerceAtLeast(dp(20f).toInt())
        return when (prefs.getInt("trigger_h", 1)) {
            0 -> dp(16f).toInt()
            2 -> dp(44f).toInt()
            else -> base
        }
    }

    /** AeroHUB: watch the touch screen itself. Starts by itself as soon as AeroHUB is connected. */
    private fun startTouchWatch() {
        val d = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        d?.getRealMetrics(dm)
        val rot = rotation()
        val land = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270
        val w = if (land) dm.heightPixels else dm.widthPixels
        val h = if (land) dm.widthPixels else dm.heightPixels
        if (w <= 0 || h <= 0) return
        // the touch starts a little lower than the very first pixel, so allow some room
        val top = (triggerHeight() * 1.25f).toInt()
        Shell.watchPull(
            Shell.PullCfg(w, h, rot, top, dp(if (landSafe()) 48f else 20f).toInt(), triggerSide(), autoLock = splitMode())
        ) { half -> onPull(half) }
    }

    /** half: 1 = the swipe started on the left half, 2 = on the right half. */
    private fun onPull(half: Int) {
        if (instance !== this) return
        val kg = getSystemService(KeyguardManager::class.java)
        if (kg != null && kg.isKeyguardLocked) return
        if (cc.shown || nt.shown) {
            // our panel is already open: make sure the phone's own one does not open underneath it
            if (Shell.ready) scope.launch { Shell.exec("cmd statusbar collapse") }
            return
        }
        // if the phone's own panel started to open under the same swipe, close it
        if (Shell.ready) scope.launch { Shell.exec("cmd statusbar collapse") }
        if (!passGate()) return
        if (notifOwn() && half == 1) show(nt) else show(cc)
    }

    /** Without AeroHUB: thin invisible strips over the top edge (left = notifications, right = Control Center). */
    private fun addStrips() {
        if (notifOwn()) {
            addStrip(1, true)
            addStrip(2, false)
        } else {
            addStrip(triggerSide(), false)
        }
    }

    private fun addStrip(side: Int, toNotif: Boolean) {
        val h = triggerHeight()
        val v = object : View(this) {
            private var downY = 0f
            private var fired = false
            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downY = e.rawY; fired = false }
                    MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - downY > dp(if (landSafe()) 48f else 22f)) {
                        fired = true
                        if (passGate()) show(if (toNotif) nt else cc)
                    }
                }
                return true
            }
        }
        val lp = WindowManager.LayoutParams(
            if (side == 0) ViewGroup.LayoutParams.MATCH_PARENT else screenWidthPx() / 2, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or (if (side == 2) Gravity.END else Gravity.START) }
        try {
            wm.addView(v, lp)
            strips.add(v)
        } catch (_: Exception) {
        }
    }

    /** Current screen width in px, read from the display itself (the app resources can lag behind a rotation). */
    @Suppress("DEPRECATION")
    private fun screenWidthPx(): Int = try {
        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.getRealMetrics(dm)
        if (dm.widthPixels > 0) dm.widthPixels else resources.displayMetrics.widthPixels
    } catch (_: Throwable) {
        resources.displayMetrics.widthPixels
    }

    private fun removeStrips() {
        strips.forEach { try { wm.removeViewImmediate(it) } catch (_: Exception) {} }
        strips.clear()
    }

    private fun rebuildStrips() {
        removeStrips()
        try { addStrips() } catch (_: Exception) {}
    }

    /* ---------- the panels (Control Center and notification panel) ---------- */

    /** True when the phone can blur what is behind the panel and the user chose "Blurred screen". */
    private fun blurWanted(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        if (getSharedPreferences("cc", Context.MODE_PRIVATE).getInt("bg_style", 0) != 0) return false
        return try { wm.isCrossWindowBlurEnabled } catch (_: Throwable) { false }
    }

    /** Blur radius in px from the "Blur strength" setting (0..100). */
    private fun blurRadiusPx(): Int {
        val amt = getSharedPreferences("cc", Context.MODE_PRIVATE).getInt("blur_amt", 60).coerceIn(0, 100)
        return (amt / 100f * 48f * resources.displayMetrics.density).toInt()
    }

    /** Builds one panel window. It stays attached but hidden (GONE) until it is needed. */
    private fun ensure(h: Host) {
        if (h.frame != null) return
        val themed = ContextThemeWrapper(this, R.style.Theme_ControlCenter)
        val top = systemDimen("status_bar_height", 26f)
        val bottom = systemDimen("navigation_bar_height", 0f)
        val density = resources.displayMetrics.density
        val blur = blurWanted()
        val radius = blurRadiusPx()

        val root = PanelFrame(themed) { hide(h, true) }
        val cv = ComposeView(themed)
        val openSettings = {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_SETTINGS, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            hide(h, true)
        }
        cv.setContent {
            if (h.notif) {
                NotificationPanelApp(
                    onOpenSettings = openSettings,
                    onClose = { hide(h, true) },
                    insetTop = androidx.compose.ui.unit.Dp(top / density),
                    insetBottom = androidx.compose.ui.unit.Dp(bottom / density),
                    active = h.active.value,
                    blurBehind = blur
                )
            } else {
                ControlCenterApp(
                    onOpenSettings = openSettings,
                    onClose = { hide(h, true) },
                    insetTop = androidx.compose.ui.unit.Dp(top / density),
                    insetBottom = androidx.compose.ui.unit.Dp(bottom / density),
                    active = h.active.value,
                    blurBehind = blur
                )
            }
        }
        root.addView(cv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.setViewTreeLifecycleOwner(owner)
        root.setViewTreeSavedStateRegistryOwner(owner)
        root.setViewTreeViewModelStoreOwner(owner)
        root.alpha = 0f

        // The panel lives in a Dialog window (a real window with its own decor). Only such a window can tell the
        // system "my navigation bar is transparent"; a bare overlay view leaves the bar black.
        val dlg = PanelDialog(themed) { hide(h, true) }
        dlg.setCancelable(false)
        dlg.setCanceledOnTouchOutside(false)
        val w = dlg.window ?: return
        w.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setWindowAnimations(0)
        w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        w.addFlags(
            // not focusable while it is only being built, so it never takes the keyboard / focus from the app below
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        )
        w.setFormat(PixelFormat.TRANSLUCENT)
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        // the notification panel has a text box (pairing code / reply): the keyboard must be able to open for it
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        WindowCompat.setDecorFitsSystemWindows(w, false)
        w.statusBarColor = Color.TRANSPARENT
        w.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            // no grey / black scrim behind the three navigation buttons
            w.isNavigationBarContrastEnforced = false
            w.isStatusBarContrastEnforced = false
        }
        val attrs = w.attributes
        if (Build.VERSION.SDK_INT >= 28) {
            attrs.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Build.VERSION.SDK_INT >= 31 && blur && radius > 0) {
            // real blur of whatever is behind the panel (the app you pulled down over)
            attrs.flags = attrs.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            attrs.blurBehindRadius = radius
        }
        w.attributes = attrs
        dlg.setContentView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        try {
            // built once while hidden, so the first pull-down does not have to create anything
            dlg.show()
            dlg.hide()
        } catch (_: Exception) {
            try { dlg.dismiss() } catch (_: Exception) {}
            return
        }
        h.dialog = dlg
        h.frame = root
        h.view = cv
        h.rotation = rotation()
        h.builtBlur = blur
    }

    private fun destroy(h: Host) {
        val p = h.frame ?: return
        val cv = h.view
        val d = h.dialog
        h.frame = null
        h.view = null
        h.dialog = null
        h.shown = false
        h.active.value = false
        p.animate().cancel()
        try { cv?.disposeComposition() } catch (_: Exception) {}
        try { d?.dismiss() } catch (_: Exception) {}
    }

    /** Theme / blur setting changed: throw the panels away and build them again with the new look. */
    private fun rebuildLook() {
        destroy(cc)
        destroy(nt)
        main.postDelayed({
            if (instance === this) {
                ensure(cc)
                if (notifOwn()) ensure(nt)
            }
        }, 300)
    }

    private fun show(h: Host) {
        if (h.shown || instance !== this) return
        main.removeCallbacks(idleFree)
        // the screen was rotated since the panel was built (or the blur support changed): build it again
        if (h.frame != null && (h.rotation != rotation() || h.builtBlur != blurWanted())) destroy(h)
        ensure(h)
        val p = h.frame ?: return
        h.shown = true
        StatusBarService.panelOpen(true)
        p.animate().cancel()
        p.alpha = 0f
        p.translationY = -resources.displayMetrics.heightPixels * 0.14f
        p.scaleX = 0.94f
        p.scaleY = 0.94f
        p.post { p.pivotX = p.width / 2f; p.pivotY = 0f }
        p.arm()
        h.active.value = true
        h.dialog?.window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        try { h.dialog?.show() } catch (_: Exception) { h.shown = false; StatusBarService.panelOpen(false); return }
        p.isFocusable = true
        p.isFocusableInTouchMode = true
        p.requestFocus()
        listenForNavClose()
        // soft spring: slides down with a small overshoot, grows from the top edge, fades in a little faster
        p.pivotX = p.width / 2f
        p.pivotY = 0f
        p.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(420)
            .setInterpolator(OvershootInterpolator(0.7f)).start()
    }

    /** Frees the hidden panel's memory when it has not been used for a while (it is rebuilt on the next pull). */
    private val idleFree = Runnable {
        if (!cc.shown) destroy(cc)
        if (!nt.shown) destroy(nt)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND && !cc.shown && !nt.shown) {
            main.removeCallbacks(idleFree)
            main.post(idleFree)
        }
    }

    private fun hide(h: Host, animated: Boolean) {
        val p = h.frame ?: return
        if (!h.shown) return
        h.shown = false
        main.removeCallbacks(idleFree)
        main.postDelayed(idleFree, 120_000L)
        p.animate().cancel()
        fun finish() {
            if (!cc.shown && !nt.shown) { StatusBarService.panelOpen(false); stopNavClose() }
            h.active.value = false
            try { h.dialog?.hide() } catch (_: Exception) {}
            p.alpha = 0f
            p.translationY = 0f
            p.scaleX = 1f
            p.scaleY = 1f
        }
        if (animated) {
            p.pivotX = p.width / 2f
            p.pivotY = 0f
            p.animate().alpha(0f).translationY(-p.height * 0.1f).scaleX(0.96f).scaleY(0.96f).setDuration(220)
                .setInterpolator(AccelerateInterpolator(1.3f)).withEndAction { finish() }.start()
        } else {
            finish()
        }
    }

    /* ---------- a navigation bar button (Back / Home / Recents) closes the open panel ---------- */

    private fun closePanels() {
        if (cc.shown) hide(cc, true)
        if (nt.shown) hide(nt, true)
    }

    /** Home and Recents: the system tells every app to close its dialogs. */
    private val closeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val reason = i?.getStringExtra("reason")
            if (reason == "homekey" || reason == "recentapps") closePanels()
        }
    }
    private var closeReceiverOn = false

    /**
     * While a panel is open: (1) the system "close dialogs" broadcast (Home, Recents) closes it, and (2) with AeroHUB
     * a touch that starts inside the navigation bar closes it too, whichever button it is (Back, Home, Recents).
     */
    private fun listenForNavClose() {
        if (!closeReceiverOn) {
            try {
                androidx.core.content.ContextCompat.registerReceiver(
                    this, closeReceiver, IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS),
                    androidx.core.content.ContextCompat.RECEIVER_EXPORTED
                )
                closeReceiverOn = true
            } catch (_: Exception) {
            }
        }
        // the window insets are known a moment after the panel window is on screen
        main.postDelayed({ armNavZone() }, 150L)
    }

    private fun armNavZone() {
        if (instance !== this || !(cc.shown || nt.shown)) return
        val frame = (if (cc.shown) cc.frame else nt.frame) ?: return
        var l = 0
        var r = 0
        var b = 0
        try {
            frame.rootWindowInsets?.let { ins ->
                val n = WindowInsetsCompat.toWindowInsetsCompat(ins, frame).getInsets(WindowInsetsCompat.Type.navigationBars())
                l = n.left; r = n.right; b = n.bottom
            }
        } catch (_: Throwable) {
        }
        if (l == 0 && r == 0 && b == 0 && !isLandscape()) b = systemDimen("navigation_bar_height", 0f)
        Shell.setNavZone(l, r, b) { closePanels() }
    }

    private fun stopNavClose() {
        Shell.setNavZone(0, 0, 0, null)
        if (closeReceiverOn) {
            try { unregisterReceiver(closeReceiver) } catch (_: Exception) {}
            closeReceiverOn = false
        }
    }

    /** The window of one panel. Back closes the panel instead of dismissing the dialog. */
    private class PanelDialog(ctx: Context, val close: () -> Unit) : Dialog(ctx, R.style.Theme_ControlCenter) {
        @Deprecated("Deprecated in Java")
        override fun onBackPressed() {
            close()
        }
    }

    /** Content root: Back key and losing focus (Home, Recents, another window) close the panel. */
    private class PanelFrame(ctx: Context, val close: () -> Unit) : FrameLayout(ctx) {
        private var hadFocus = false

        /** Called every time the panel is shown: losing focus only closes it after it had focus once. */
        fun arm() { hadFocus = false }

        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) close()
                return true
            }
            return super.dispatchKeyEvent(e)
        }

        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus) hadFocus = true
            else if (hadFocus) close()
        }
    }

    /** Lifecycle / saved state / view model owner that a ComposeView needs outside an Activity. */
    private class ViewOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = store

        init {
            controller.performAttach()
            controller.performRestore(null)
            registry.currentState = Lifecycle.State.CREATED
        }

        fun resume() {
            registry.currentState = Lifecycle.State.RESUMED
        }

        fun destroy() {
            registry.currentState = Lifecycle.State.DESTROYED
            store.clear()
        }
    }

    companion object {
        @Volatile
        var running = false
            private set

        /** The live service (null while the pull-down is off). */
        @Volatile
        var instance: OverlayService? = null
            private set

        /** Opens the Control Center right now (used by the Test button). Main thread only. */
        fun openNow(): Boolean {
            val s = instance ?: return false
            s.show(s.cc)
            return true
        }

        /** Opens the notification panel right now (used by the Test button). Main thread only. */
        fun openNotifNow(): Boolean {
            val s = instance ?: return false
            s.show(s.nt)
            return true
        }

        /** Call after a theme / blur setting changed: the panels are rebuilt with the new look. Main thread only. */
        fun rebuildLook() {
            instance?.rebuildLook()
        }

        fun start(ctx: Context) {
            androidx.core.content.ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
