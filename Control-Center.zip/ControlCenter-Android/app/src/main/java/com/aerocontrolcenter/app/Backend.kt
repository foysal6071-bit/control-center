package com.aerocontrolcenter.app

import android.content.Context
import android.content.pm.PackageManager
import android.os.Binder
import android.os.IBinder
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.IOException
import kotlin.concurrent.thread

/** Shizuku gives this app shell access. Every command goes through here. */
object Backend {
    const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

    private lateinit var ctx: Context
    fun init(c: Context) { ctx = c.applicationContext }

    const val name = "Shizuku"
    const val pkg = SHIZUKU_PKG

    // ---------------- Shizuku status ----------------
    fun shizukuInstalled(): Boolean = try { ctx.packageManager.getPackageInfo(SHIZUKU_PKG, 0); true } catch (_: Throwable) { false }

    /** -1 = Shizuku not running, 0 = running but this app is not allowed, 1 = allowed. */
    fun shizukuStatus(): Int = try {
        when {
            !Shizuku.pingBinder() || Shizuku.isPreV11() -> -1
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 1
            else -> 0
        }
    } catch (_: Throwable) { -1 }

    /** True when the user chose "deny and don't ask again". */
    fun shizukuDeniedForever(): Boolean = try { Shizuku.shouldShowRequestPermissionRationale() } catch (_: Throwable) { false }

    fun shizukuRequest(code: Int) { try { Shizuku.requestPermission(code) } catch (_: Throwable) {} }

    // ---------------- commands ----------------
    private fun proc(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    private fun shizukuRun(cmd: String, mergeErr: Boolean): Pair<Int, ByteArray> {
        val p = proc(cmd)
        runCatching { p.outputStream.close() }
        val out = ByteArrayOutputStream()
        val err = ByteArrayOutputStream()
        val t1 = thread(isDaemon = true) { readCapped(p.inputStream, out) }
        val t2 = thread(isDaemon = true) { readCapped(p.errorStream, err) }
        t1.join(60_000); t2.join(1_000)
        val code = try { p.exitValue() } catch (_: IllegalThreadStateException) { p.destroy(); -1 }
        val bytes = if (mergeErr) out.toByteArray() + err.toByteArray() else out.toByteArray()
        return code to bytes
    }

    private fun readCapped(i: java.io.InputStream, o: ByteArrayOutputStream) {
        try {
            val b = ByteArray(8192)
            while (true) {
                val n = i.read(b)
                if (n < 0) break
                synchronized(o) { val room = 512 * 1024 - o.size(); if (room > 0) o.write(b, 0, minOf(n, room)) }
            }
        } catch (_: Throwable) {}
    }

    fun exec(cmd: String): Pair<Int, String> =
        shizukuRun(cmd, true).let { it.first to String(it.second) }

    fun execBytes(cmd: String): Pair<Int, ByteArray> = shizukuRun(cmd, false)

    fun stream(cmd: String, onOpen: (Closeable) -> Unit, onLine: (String) -> Boolean) {
        val p = proc(cmd)
        runCatching { p.outputStream.close() }
        try {
            onOpen(Closeable { p.destroy() })
            val r = p.inputStream.bufferedReader()
            while (true) {
                val line = r.readLine() ?: break
                if (!onLine(line)) break
            }
        } finally { runCatching { p.destroy() } }
    }

    // ---------------- status bar flags ----------------
    // The token is a Binder of this app: if the app dies, the phone drops the flags by itself (no heartbeat needed).
    private val sbToken: IBinder = Binder()

    fun statusFlags(what: Int, what2: Int): Boolean {
        return try {
            val raw = SystemServiceHelper.getSystemService("statusbar") ?: return false
            val svc = Class.forName("com.android.internal.statusbar.IStatusBarService\$Stub")
                .getMethod("asInterface", IBinder::class.java).invoke(null, ShizukuBinderWrapper(raw))!!
            val a = call(svc, "disable", what)
            call(svc, "disable2", what2)
            a
        } catch (_: Throwable) { false }
    }

    private fun call(svc: Any, name: String, what: Int): Boolean {
        val c = svc.javaClass
        val int = Int::class.javaPrimitiveType
        try {
            c.getMethod(name, int, IBinder::class.java, String::class.java).invoke(svc, what, sbToken, "com.android.shell")
            return true
        } catch (_: NoSuchMethodException) {
        } catch (_: Throwable) { return false }
        return try {
            c.getMethod(name + "ForUser", int, IBinder::class.java, String::class.java, int)
                .invoke(svc, what, sbToken, "com.android.shell", 0)
            true
        } catch (_: Throwable) { false }
    }
}
