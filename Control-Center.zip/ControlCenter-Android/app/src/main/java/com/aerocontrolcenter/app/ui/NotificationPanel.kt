package com.aerocontrolcenter.app.ui

import android.app.ActivityOptions
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aerocontrolcenter.app.MediaListener
import com.aerocontrolcenter.app.NotifItem
import com.aerocontrolcenter.app.NotifStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * This app's own notification panel (pull down on the left half of the top edge).
 * Big clock, then one rounded card per notification: app icon, title, text and up to two action buttons.
 * Tap a card to open it, long-press it for that app's notification settings, swipe it sideways to dismiss it, "Clear all" removes every dismissable one.
 */
@Composable
fun NotificationPanelApp(
    onOpenSettings: () -> Unit,
    onClose: () -> Unit,
    insetTop: Dp,
    insetBottom: Dp,
    active: Boolean,
    blurBehind: Boolean
) {
    val ctx = LocalContext.current
    val th = rememberCCTheme(blurBehind)
    val prefs = remember { ctx.getSharedPreferences("cc", Context.MODE_PRIVATE) }

    // read again every time the panel is opened
    // on a secured lock screen the text of the notifications is always hidden
    val hide = remember(active) {
        prefs.getBoolean("n_hide", false) || try {
            val kg = ctx.getSystemService(android.app.KeyguardManager::class.java)
            kg != null && kg.isKeyguardLocked && kg.isKeyguardSecure
        } catch (_: Throwable) { false }
    }
    val h24 = remember(active) { prefs.getBoolean("clock24", android.text.format.DateFormat.is24HourFormat(ctx)) }
    val showDate = remember(active) { prefs.getBoolean("n_date", true) }
    val hasAccess = remember(active) { MediaListener.hasAccess(ctx) }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) {
        if (active) MediaListener.refreshNow()
        while (active) {
            now = System.currentTimeMillis()
            delay(10_000)
        }
    }

    val list = NotifStore.items
    val timeFmt = remember(h24) { SimpleDateFormat(if (h24) "HH:mm" else "h:mm", Locale.ENGLISH) }
    val dateFmt = remember { SimpleDateFormat("EEE, d MMM", Locale.ENGLISH) }

    /* entrance: restarted every time the panel opens; clock and cards read it in their draw layer only */
    val enter = remember { Animatable(0f) }
    LaunchedEffect(active) {
        enter.snapTo(0f)
        if (active) {
            if (PanelDrag.progress >= 0f) enter.snapTo(1f) else enter.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        }
    }

    val listState = rememberLazyListState()
    var listRect by remember { mutableStateOf(Rect.Zero) }

    // Tap = close. Swipe up = close from ANYWHERE on the panel (also over the notifications).
    // The gesture is only watched (Initial pass, nothing consumed), so scrolling and card swiping keep working.
    // Exception: a swipe that starts on the list while it can still scroll down just scrolls the list.
    val closeMod = Modifier
        .pointerInput(Unit) { detectTapGestures { onClose() } }
        .pointerInput(Unit) {
            val slop = viewConfiguration.touchSlop
            val need = maxOf(slop * 3f, 40.dp.toPx())
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val onScrollableList = listRect.contains(down.position) && listState.canScrollForward
                var dx = 0f
                var dy = 0f
                var done = false
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!ch.pressed) break
                    dx += ch.position.x - ch.previousPosition.x
                    dy += ch.position.y - ch.previousPosition.y
                    if (!done && !onScrollableList && -dy > need && -dy > abs(dx) * 1.4f) {
                        done = true
                        onClose()
                    }
                }
            }
        }

    CompositionLocalProvider(LocalCC provides th) {
        BoxWithConstraints(Modifier.fillMaxSize().then(closeMod)) {
            // landscape: the clock scrolls away with the notifications, so the list gets the whole panel
            val land = maxWidth > maxHeight
            CCWallpaper(th, true)
            // while the keyboard is open (typing a pairing code / reply) the panel sits above it
            val imeBottom = with(LocalDensity.current) { WindowInsets.ime.getBottom(this).toDp() }
            Column(Modifier.fillMaxSize().padding(top = insetTop + 12.dp, bottom = if (imeBottom > 0.dp) imeBottom else insetBottom)) {

                /* clock, date, Clear all (in landscape it is the first row of the scrolling list) */
                val header: @Composable () -> Unit = {
                Row(
                    Modifier.fillMaxWidth()
                        .graphicsLayer {
                            val t = (PanelDrag.progress.let { if (it >= 0f) it else enter.value }).coerceIn(0f, 1f)
                            alpha = t
                            translationY = (1f - t) * -28.dp.toPx()
                        }
                        .padding(start = 24.dp, end = 18.dp, top = 6.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            timeFmt.format(Date(now)), color = th.fg, fontSize = 54.sp,
                            fontWeight = FontWeight.Light, maxLines = 1
                        )
                        if (showDate) Text(
                            dateFmt.format(Date(now)), color = th.fgSub, fontSize = 15.sp,
                            fontWeight = FontWeight.Medium, maxLines = 1
                        )
                    }
                    if (list.any { it.clearable }) {
                        Pill("Clear all", th) { MediaListener.instance?.cancelAllNotifications() }
                    }
                }
                }
                if (!(land && hasAccess && list.isNotEmpty())) header()

                /* the notifications */
                when {
                    !hasAccess -> Column(
                        Modifier.weight(1f).fillMaxWidth().padding(horizontal = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "Allow Notification access to see your notifications here.",
                            color = th.fgSub, fontSize = 15.sp, textAlign = TextAlign.Center
                        )
                        Box(Modifier.padding(top = 14.dp)) { Pill("Open settings", th) { onOpenSettings() } }
                    }
                    list.isEmpty() && NotifStore.snoozed.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No notifications", color = th.fgSub, fontSize = 15.sp)
                    }
                    else -> LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f).fillMaxWidth().onGloballyPositioned { listRect = it.boundsInRoot() },
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (land) item(key = "header") { header() }
                        if (NotifStore.snoozed.isNotEmpty()) item(key = "muted") {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                NotifStore.snoozed.forEach { m ->
                                    val mins = ((m.until - now) / 60_000L).coerceAtLeast(1)
                                    val left = if (mins >= 60) "${(mins + 59) / 60}h" else "${mins}m"
                                    Row(
                                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(th.card)
                                            .padding(horizontal = 14.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text("${m.app} muted · $left left", color = th.fgSub, fontSize = 13.sp,
                                            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Pill("Resume", th) { NotifStore.resume(ctx, m.pkg) }
                                    }
                                }
                            }
                        }
                        itemsIndexed(list, key = { _, n -> n.key }) { i, n ->
                            Box(
                                Modifier
                                    .animateItem()
                                    .graphicsLayer {
                                        val t = (((PanelDrag.progress.let { if (it >= 0f) it else enter.value }) * 1.6f) - 0.12f * i.coerceAtMost(8)).coerceIn(0f, 1f)
                                        alpha = t
                                        translationY = (1f - t) * 36.dp.toPx()
                                        val k = 0.94f + 0.06f * t
                                        scaleX = k
                                        scaleY = k
                                    }
                            ) { NotifCard(n, th, hide, now, onClose) }
                        }
                    }
                }

                /* handle at the bottom closes the panel */
                Box(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
                        .semantics { contentDescription = "Close notification panel" },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(width = 110.dp, height = 20.dp), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(width = 36.dp, height = 4.dp)
                                .background(th.fg.copy(alpha = 0.45f), RoundedCornerShape(2.dp))
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NotifCard(n: NotifItem, th: CCTheme, hide: Boolean, now: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    var wPx by remember { mutableFloatStateOf(1f) }

    val title = if (hide) n.app else n.title.ifBlank { n.app }
    val text = if (hide) "Content hidden" else n.text

    // text-input action (Wireless debugging "Enter pairing code", Shizuku, chat reply)
    val typedA = n.actions.firstOrNull { it.inputs != null }
    var typing by remember(n.key) { mutableStateOf(false) }
    var menu by remember(n.key) { mutableStateOf(false) }
    var input by remember(n.key) { mutableStateOf("") }
    val numeric = remember(n.key) {
        val t = (n.title + " " + n.text + " " + (typedA?.title ?: "") + " " + (typedA?.inputLabel ?: "")).lowercase()
        n.pkg == "com.android.settings" || n.pkg.startsWith("moe.shizuku") || "pair" in t || "code" in t
    }
    val keyboard = LocalSoftwareKeyboardController.current

    fun send(pi: android.app.PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val o = ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                pi.send(ctx, 0, null, null, null, null, o.toBundle())
            } else {
                pi.send()
            }
        } catch (_: Exception) {
        }
    }

    /** Fills the typed text into the notification's RemoteInput and sends it back to the app that posted it. */
    fun submitInput() {
        val a = typedA ?: return
        val inputs = a.inputs ?: return
        val value = input.trim()
        if (value.isEmpty()) return
        try {
            val target = inputs.firstOrNull { it.allowFreeFormInput } ?: inputs[0]
            val results = Bundle().apply { putCharSequence(target.resultKey, value) }
            val fill = Intent().addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
            RemoteInput.addResultsToIntent(inputs, fill, results)
            if (Build.VERSION.SDK_INT >= 28) {
                RemoteInput.setResultsSource(fill, RemoteInput.SOURCE_FREE_FORM_INPUT)
            }
            if (Build.VERSION.SDK_INT >= 34) {
                val o = ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                a.intent.send(ctx, 0, fill, null, null, null, o.toBundle())
            } else {
                a.intent.send(ctx, 0, fill, null, null)
            }
            input = ""
            typing = false
            keyboard?.hide()
        } catch (_: Exception) {
        }
    }

    Box(
        Modifier.fillMaxWidth()
            .onSizeChanged { wPx = it.width.toFloat().coerceAtLeast(1f) }
            .graphicsLayer {
                translationX = off.value
                alpha = 1f - (abs(off.value) / wPx).coerceIn(0f, 1f) * 0.85f
            }
            .pointerInput(n.key, n.clearable) {
                if (!n.clearable) {
                    /* can't be dismissed: it follows the finger a little (rubber band), then bounces back */
                    var buzzed = false
                    detectHorizontalDragGestures(
                        onDragStart = { buzzed = false },
                        onDragEnd = { scope.launch { off.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 500f)) } },
                        onDragCancel = { scope.launch { off.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 500f)) } }
                    ) { change, dx ->
                        change.consume()
                        val max = wPx * 0.12f
                        val pull = (abs(off.value) / max).coerceIn(0f, 1f)
                        val next = (off.value + dx * (0.5f * (1f - pull) + 0.05f)).coerceIn(-max, max)
                        if (!buzzed && abs(next) > max * 0.6f) {
                            buzzed = true
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                        scope.launch { off.snapTo(next) }
                    }
                } else detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (abs(off.value) > wPx * 0.35f) {
                                off.animateTo(if (off.value > 0) wPx else -wPx, tween(140))
                                MediaListener.instance?.cancelNotification(n.key)
                            } else {
                                off.animateTo(0f, spring())
                            }
                        }
                    },
                    onDragCancel = { scope.launch { off.animateTo(0f, spring()) } }
                ) { change, dx ->
                    change.consume()
                    scope.launch { off.snapTo(off.value + dx) }
                }
            }
            .clip(RoundedCornerShape(22.dp))
            .background(th.card)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {
                    n.content?.let { send(it) }
                    if (n.autoCancel && n.clearable) MediaListener.instance?.cancelNotification(n.key)
                    onClose()
                },
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    menu = !menu
                }
            )
    ) {
      Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AppIcon(n, th)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    title, color = th.fg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (text.isNotBlank()) Text(
                    text, color = th.fgSub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                if (n.actions.size > 1 || typedA != null) {
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        n.actions.forEach { a ->
                            if (a.inputs != null) {
                                Pill(a.title.ifBlank { if (numeric) "Enter code" else "Reply" }, th) { typing = !typing }
                            } else {
                                Pill(a.title.ifBlank { "Open" }, th) { runAction(a.intent, { p -> send(p) }, onClose) }
                            }
                        }
                    }
                }
            }
            if (n.actions.size == 1 && typedA == null) {
                val a = n.actions[0]
                Pill(a.title.ifBlank { "Open" }, th) { runAction(a.intent, { p -> send(p) }, onClose) }
            } else if (!n.ongoing) {
                Text(ago(now, n.time), color = th.fgSub, fontSize = 11.sp, maxLines = 1)
            }
        }

        /* long press: mute this app for a while (like HyperOS) */
        if (menu) {
            Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Mute ${n.app} for", color = th.fgSub, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("1 hour" to 1, "3 hours" to 3, "8 hours" to 8, "24 hours" to 24).forEach { (label, h) ->
                        Pill(label, th) {
                            NotifStore.snooze(ctx, n.pkg, h * 3_600_000L)
                            menu = false
                        }
                    }
                }
                Pill("App notification settings", th) {
                    if (openAppNotificationSettings(ctx, n.pkg)) onClose()
                }
            }
        }

        /* inline text box for the text-input action */
        if (typing && typedA != null) {
            val focus = remember { FocusRequester() }
            LaunchedEffect(Unit) {
                try { focus.requestFocus() } catch (_: Throwable) {}
                keyboard?.show()
            }
            Row(
                Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(50)).background(th.pill)
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    if (input.isEmpty()) {
                        Text(
                            typedA.inputLabel.ifBlank { if (numeric) "Pairing code" else "Reply" },
                            color = th.fgSub, fontSize = 14.sp, maxLines = 1
                        )
                    }
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        singleLine = true,
                        textStyle = TextStyle(color = th.fg, fontSize = 14.sp),
                        cursorBrush = SolidColor(th.fg),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text,
                            imeAction = ImeAction.Send
                        ),
                        keyboardActions = KeyboardActions(onSend = { submitInput() }),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus)
                    )
                }
                Pill("Send", th) { submitInput() }
            }
        }
      }
    }
}

/** Opens the system "Notifications" settings page of the app that posted the notification. Returns true if a page was opened. */
private fun openAppNotificationSettings(ctx: Context, pkg: String): Boolean {
    val attempts = listOf(
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null))
    )
    for (i in attempts) {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return true
        } catch (_: Exception) {
        }
    }
    return false
}

/** Sends the action. Closes the panel when the action opens an app (Android 12+ can tell), otherwise leaves it open. */
private fun runAction(pi: android.app.PendingIntent, send: (android.app.PendingIntent) -> Unit, onClose: () -> Unit) {
    send(pi)
    val keepOpen = Build.VERSION.SDK_INT >= 31 && try { !pi.isActivity } catch (_: Throwable) { false }
    if (!keepOpen) onClose()
}

@Composable
private fun AppIcon(n: NotifItem, th: CCTheme) {
    val icon = n.icon
    if (icon != null) {
        Image(
            bitmap = icon, contentDescription = n.app,
            modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
        )
    } else {
        Box(Modifier.size(38.dp).background(th.pill, CircleShape), contentAlignment = Alignment.Center) {
            Text(n.app.take(1).uppercase(), color = th.fg, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Pill(text: String, th: CCTheme, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(th.pill)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = th.fg, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

private fun ago(now: Long, t: Long): String {
    val m = ((now - t) / 60_000L).coerceAtLeast(0)
    return when {
        m < 1 -> "now"
        m < 60 -> "${m}m"
        m < 24 * 60 -> SimpleDateFormat("HH:mm", Locale.ENGLISH).format(Date(t))
        else -> SimpleDateFormat("d MMM", Locale.ENGLISH).format(Date(t))
    }
}
