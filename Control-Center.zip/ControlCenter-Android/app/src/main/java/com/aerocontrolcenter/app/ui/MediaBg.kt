package com.aerocontrolcenter.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Background picture of the music (Now Playing) tile: picked from the gallery, cropped, saved in the app's own folder. */
object MediaBg {
    /** Width / height of the music tile in the Control Center (96 x 86 units): the crop frame has the same shape. */
    const val ASPECT = 96f / 86f

    private fun file(ctx: Context) = File(ctx.filesDir, "media_bg.jpg")

    fun exists(ctx: Context) = file(ctx).exists()

    fun load(ctx: Context): ImageBitmap? = try {
        val f = file(ctx)
        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() else null
    } catch (_: Throwable) {
        null
    }

    /** Reads a (large) picture from the gallery, shrunk to at most [maxSide] px and turned upright by its EXIF tag. */
    fun decode(ctx: Context, uri: Uri, maxSide: Int = 2048): Bitmap? = try {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val raw = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        val turn = try {
            cr.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Throwable) {
            0f
        }
        if (raw != null && turn != 0f) {
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(turn) }, true)
        } else raw
    } catch (_: Throwable) {
        null
    }

    fun save(ctx: Context, bmp: Bitmap) {
        try {
            file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        } catch (_: Throwable) {
        }
    }

    fun clear(ctx: Context) {
        try { file(ctx).delete() } catch (_: Throwable) {}
    }
}

/**
 * Full screen crop: the big picture can be moved with one finger and zoomed with two; the bright frame is the part
 * that will be used. [aspect] = frame width / height.
 */
@Composable
fun ImageCropDialog(bitmap: Bitmap, aspect: Float, onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        val img = remember(bitmap) { bitmap.asImageBitmap() }
        val bw = bitmap.width.toFloat()
        val bh = bitmap.height.toFloat()
        // picture centre relative to the frame centre, and screen px per picture px
        var scale by remember(bitmap) { mutableFloatStateOf(0f) }
        var off by remember(bitmap) { mutableStateOf(Offset.Zero) }
        var frame by remember { mutableStateOf(Size.Zero) }
        val frameNow by rememberUpdatedState(frame)

        fun minScale(f: Size) = max(f.width / bw, f.height / bh)
        fun clampOff(o: Offset, s: Float, f: Size): Offset {
            val mx = max(0f, bw * s / 2f - f.width / 2f)
            val my = max(0f, bh * s / 2f - f.height / 2f)
            return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
        }

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Text(
                "Move and zoom the photo. The frame is what will be used.",
                color = Color(0xFFBDBDC2), fontSize = 14.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp, start = 24.dp, end = 24.dp)
            )
            BoxWithConstraints(Modifier.fillMaxSize().padding(top = 96.dp, bottom = 104.dp)) {
                val d = LocalDensity.current
                val availW = with(d) { maxWidth.toPx() }
                val availH = with(d) { maxHeight.toPx() }
                var fw = availW * 0.9f
                var fh = fw / aspect
                if (fh > availH * 0.95f) { fh = availH * 0.95f; fw = fh * aspect }
                val f = Size(fw, fh)
                if (frame != f) {
                    frame = f
                    if (scale == 0f) scale = minScale(f) else scale = scale.coerceAtLeast(minScale(f))
                    off = clampOff(off, scale, f)
                }
                Canvas(
                    Modifier.fillMaxSize().pointerInput(bitmap) {
                        detectTransformGestures { centroid, pan, zoom, _ ->
                            val fr = frameNow
                            if (fr.width <= 0f) return@detectTransformGestures
                            val c = Offset(centroid.x - size.width / 2f, centroid.y - size.height / 2f)
                            val ns = (scale * zoom).coerceIn(minScale(fr), minScale(fr) * 8f)
                            val k = ns / scale
                            off = clampOff((off - c) * k + c + pan, ns, fr)
                            scale = ns
                        }
                    }
                ) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val sc = scale
                    withTransform({
                        translate(cx + off.x, cy + off.y)
                        scale(sc, sc, Offset.Zero)
                    }) { drawImage(img, Offset(-bw / 2f, -bh / 2f)) }
                    val r = Rect(cx - fw / 2f, cy - fh / 2f, cx + fw / 2f, cy + fh / 2f)
                    clipPath(Path().apply { addRect(r) }, ClipOp.Difference) {
                        drawRect(Color.Black.copy(alpha = 0.7f))
                    }
                    drawRoundRect(
                        Color.White, r.topLeft, r.size, CornerRadius(4.dp.toPx()),
                        style = Stroke(2.dp.toPx())
                    )
                }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2C2C2E))
                        .clickable { onCancel() }.padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Cancel", color = Color.White, fontSize = 17.sp) }
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF0A84FF))
                        .clickable {
                            val fr = frame
                            val s = scale
                            if (fr.width <= 0f || s <= 0f) { onCancel(); return@clickable }
                            val left = (bw / 2f + (-fr.width / 2f - off.x) / s).toInt().coerceIn(0, bitmap.width - 1)
                            val top = (bh / 2f + (-fr.height / 2f - off.y) / s).toInt().coerceIn(0, bitmap.height - 1)
                            val w = (fr.width / s).toInt().coerceIn(1, bitmap.width - left)
                            val h = (fr.height / s).toInt().coerceIn(1, bitmap.height - top)
                            val crop = Bitmap.createBitmap(bitmap, left, top, w, h)
                            val outW = min(640, w)
                            val outH = (outW / aspect).toInt().coerceAtLeast(1)
                            onDone(Bitmap.createScaledBitmap(crop, outW, outH, true))
                        }.padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Done", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}
