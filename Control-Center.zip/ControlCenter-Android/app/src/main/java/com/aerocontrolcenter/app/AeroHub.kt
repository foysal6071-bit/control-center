package com.aerocontrolcenter.app

import android.content.Context
import android.net.Uri
import android.os.IBinder
import android.os.Parcel
import android.os.ParcelFileDescriptor
import android.os.RemoteException
import java.io.BufferedReader
import java.io.Closeable
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Base64

/** Client for the AeroHUB app (package com.example.mykuzu). All calls block: run them off the main thread. */
object AeroHub {
    const val PKG = "com.example.mykuzu"
    const val ACTION_REQUEST = "com.example.mykuzu.action.REQUEST_PERMISSION"
    private const val PORT = 27183
    const val MIN_SERVER_VERSION = 4
    const val ACTION_WAKE = "com.example.mykuzu.action.WAKE"
    private const val AUTHORITY = "com.example.mykuzu.binder"
    private const val DESCRIPTOR = "com.example.mykuzu.IServer"
    private const val TX_REQUEST = 1
    private const val TX_STREAM = 2

    @Volatile private var server: IBinder? = null
    @Volatile private var appCtx: Context? = null
    @Volatile private var lastLookup = 0L

    /** Call once in Application.onCreate: turns on the Binder link (no network, so Doze / screen off cannot cut it). */
    fun init(c: Context) { appCtx = c.applicationContext }

    fun transport(): String = if (server?.isBinderAlive == true) "Binder" else "TCP"

    private fun binder(token: String): IBinder? {
        server?.let { if (it.isBinderAlive) return it }
        val c = appCtx ?: return null
        val now = System.currentTimeMillis()
        if (now - lastLookup < 3000) return null
        lastLookup = now
        return try {
            val b = c.contentResolver.call(Uri.parse("content://$AUTHORITY"), "getBinder", token, null)?.getBinder("b")
            if (b != null && b.isBinderAlive) {
                server = b
                try { b.linkToDeath({ if (server === b) server = null }, 0) } catch (_: Throwable) { server = null }
                server
            } else null
        } catch (_: Throwable) { null }
    }

    private fun request(token: String, line: String, timeoutMs: Int = 90_000): String {
        val b = binder(token)
        if (b != null) {
            val d = Parcel.obtain(); val r = Parcel.obtain()
            try {
                d.writeInterfaceToken(DESCRIPTOR)
                d.writeString("$token $line")
                b.transact(TX_REQUEST, d, r, 0)
                r.readException()
                return if (r.readInt() == 1) {
                    val pfd = ParcelFileDescriptor.CREATOR.createFromParcel(r)
                    String(ParcelFileDescriptor.AutoCloseInputStream(pfd).use { it.readBytes() })
                } else r.readString() ?: throw IOException("No reply from AeroHUB")
            } catch (_: RemoteException) {
                if (server === b) server = null
            } catch (_: Exception) {
                if (server === b) server = null
            } finally { d.recycle(); r.recycle() }
        }
        return tcp(token, line, timeoutMs)
    }

    private fun tcp(token: String, line: String, timeoutMs: Int): String {
        val s = Socket()
        try {
            s.connect(InetSocketAddress("127.0.0.1", PORT), 2000)
            s.soTimeout = timeoutMs
            s.getOutputStream().apply { write("$token $line\n".toByteArray()); flush() }
            return BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: throw IOException("No reply from AeroHUB")
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
    }

    /** -1 = server not running, 0 = running but this app is not allowed, 1 = allowed. [version] is the server version. */
    class Status(val code: Int, val version: Int)

    fun status(token: String): Status = try {
        val r = request(token, "PING", 3000)
        when {
            r == "DENIED" -> Status(0, 0)
            r.startsWith("OK ") -> Status(1, r.split(" ").getOrNull(2)?.toIntOrNull() ?: 1)
            else -> Status(-1, 0)
        }
    } catch (_: Exception) { Status(-1, 0) }

    private fun split(r: String): Pair<Int, ByteArray> {
        if (r == "DENIED") throw SecurityException("AeroHUB denied this app")
        val p = r.split(" ", limit = 2)
        return p[0].toInt() to Base64.getDecoder().decode(p.getOrElse(1) { "" })
    }

    fun exec(token: String, cmd: String): Pair<Int, String> {
        val (c, b) = split(request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray())))
        return c to String(b)
    }

    fun execBytes(token: String, cmd: String): Pair<Int, ByteArray> =
        split(request(token, "EXEC " + Base64.getEncoder().encodeToString(cmd.toByteArray())))

    fun statusFlags(token: String, what: Int, what2: Int): Boolean =
        request(token, "SBFLAGS $what $what2").startsWith("OK")

    fun beat(token: String) { request(token, "BEAT", 5000) }

    /** Runs [cmd] and calls [onLine] for each output line until it returns false or the command ends. Blocks. */
    fun stream(token: String, cmd: String, onOpen: (Closeable) -> Unit, onLine: (String) -> Boolean) {
        val b = binder(token)
        if (b != null) {
            var pfd: ParcelFileDescriptor? = null
            val d = Parcel.obtain(); val r = Parcel.obtain()
            try {
                d.writeInterfaceToken(DESCRIPTOR)
                d.writeString("$token STREAM ${Base64.getEncoder().encodeToString(cmd.toByteArray())}")
                b.transact(TX_STREAM, d, r, 0)
                r.readException()
                if (r.readInt() == 0) throw IOException("AeroHUB refused the stream")
                pfd = ParcelFileDescriptor.CREATOR.createFromParcel(r)
            } catch (_: RemoteException) {
                if (server === b) server = null
            } finally { d.recycle(); r.recycle() }
            if (pfd != null) {
                val ins = ParcelFileDescriptor.AutoCloseInputStream(pfd)
                try {
                    onOpen(ins)
                    val rd = BufferedReader(InputStreamReader(ins))
                    while (true) { val line = rd.readLine() ?: break; if (!onLine(line)) break }
                } finally { try { ins.close() } catch (_: Exception) {} }
                return
            }
        }
        val s = Socket()
        try {
            s.connect(InetSocketAddress("127.0.0.1", PORT), 2000)
            s.soTimeout = 0
            s.getOutputStream().apply {
                write("$token STREAM ${Base64.getEncoder().encodeToString(cmd.toByteArray())}\n".toByteArray()); flush()
            }
            val r = BufferedReader(InputStreamReader(s.getInputStream()))
            if (r.readLine() != "OK") throw IOException("AeroHUB refused the stream")
            onOpen(s)
            while (true) {
                val line = r.readLine() ?: break
                if (!onLine(line)) break
            }
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
    }
}
