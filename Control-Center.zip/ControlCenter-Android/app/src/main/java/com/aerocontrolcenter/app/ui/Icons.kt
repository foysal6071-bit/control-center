package com.aerocontrolcenter.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp

/** Tiny vector-icon model that reuses the SVG path data of the web version (24 x 24 view box). */
sealed interface El {
    val fill: Boolean
    val sw: Float
    val color: Color?
    val a: Float get() = 1f
}

data class Pa(
    val d: String,
    override val fill: Boolean = false,
    override val sw: Float = 2f,
    override val color: Color? = null,
    override val a: Float = 1f
) : El

data class Ci(
    val cx: Float, val cy: Float, val r: Float,
    override val fill: Boolean = true,
    override val sw: Float = 2f,
    override val color: Color? = null,
    override val a: Float = 1f
) : El

data class Re(
    val x: Float, val y: Float, val w: Float, val h: Float, val rx: Float,
    override val fill: Boolean = true,
    override val sw: Float = 2f,
    override val color: Color? = null,
    override val a: Float = 1f
) : El

@Composable
fun SvgIcon(els: List<El>, dp: Dp, tint: Color, modifier: Modifier = Modifier) {
    val paths = remember(els) {
        els.map { if (it is Pa) PathParser().parsePathString(it.d).toPath() else null }
    }
    Canvas(modifier.size(dp)) {
        val k = this.size.minDimension / 24f
        withTransform({ scale(k, k, Offset.Zero) }) {
            els.forEachIndexed { i, e ->
                val c0 = e.color ?: tint
                val c = if (e.a < 1f) c0.copy(alpha = c0.alpha * e.a) else c0
                val style: DrawStyle =
                    if (e.fill) Fill else Stroke(width = e.sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
                when (e) {
                    is Pa -> drawPath(paths[i]!!, c, style = style)
                    is Ci -> drawCircle(c, radius = e.r, center = Offset(e.cx, e.cy), style = style)
                    is Re -> drawRoundRect(
                        c,
                        topLeft = Offset(e.x, e.y),
                        size = Size(e.w, e.h),
                        cornerRadius = CornerRadius(e.rx, e.rx),
                        style = style
                    )
                }
            }
        }
    }
}

@Composable
fun BatteryIcon(level: Float, charging: Boolean, w: Dp, h: Dp) {
    val bolt = remember { PathParser().parsePathString("M12.4 2.2 8.2 6.6h2.6l-.9 3.2 4.3-4.6h-2.6z").toPath() }
    Canvas(Modifier.size(w, h)) {
        val k = this.size.width / 26f
        withTransform({ scale(k, k, Offset.Zero) }) {
            drawRoundRect(
                Color.White.copy(alpha = 0.5f), Offset(0.6f, 0.6f), Size(21.6f, 10.8f),
                CornerRadius(3.4f, 3.4f), style = Stroke(width = 1f)
            )
            val l = level.coerceIn(0f, 1f)
            val col = when {
                charging -> Color(0xFF34C759)
                l <= 0.2f -> Color(0xFFFF453A)
                else -> Color.White
            }
            drawRoundRect(col, Offset(2f, 2f), Size(maxOf(1.6f, 19.6f * l), 8f), CornerRadius(2f, 2f))
            if (charging) drawPath(bolt, Color(0xFF20242C))
            drawRoundRect(
                Color.White.copy(alpha = 0.5f), Offset(23.4f, 3.8f), Size(2f, 4.4f), CornerRadius(1f, 1f)
            )
        }
    }
}

object Ic {
    /** 0 = iOS, 1 = MIUI, 2 = HyperOS. Set when the panel theme is built; the style-dependent icons follow it. */
    @Volatile var style: Int = 2

    /** Hexagon gear (MIUI settings button) and square with a pencil (MIUI edit button). */
    val hex = listOf<El>(
        Pa("M12 2.8l7.6 4.4v9.6L12 21.2l-7.6-4.4V7.2z"),
        Ci(12f, 12f, 3.2f, fill = false)
    )
    val pencil = listOf<El>(
        Pa("M11 4H6.5A2.5 2.5 0 0 0 4 6.5v11A2.5 2.5 0 0 0 6.5 20h11a2.5 2.5 0 0 0 2.5-2.5V13"),
        Pa("M18.3 3.7l2 2L12 14l-3 1 1-3z")
    )
    val plus = listOf<El>(Pa("M12 4v16M4 12h16"))
    val power = listOf<El>(Pa("M12 3v8M6.8 6.6a8 8 0 1 0 10.4 0"))
    val close = listOf<El>(Pa("M6 6l12 12M18 6L6 18"))
    val gearIos = listOf<El>(
        Ci(12f, 12f, 3.2f, fill = false),
        Ci(12f, 12f, 6.8f, fill = false),
        Pa("M12 2.6v3M12 18.4v3M2.6 12h3M18.4 12h3M5.4 5.4l2.1 2.1M16.5 16.5l2.1 2.1M18.6 5.4l-2.1 2.1M7.5 16.5l-2.1 2.1")
    )

    // ---- Settings / status-bar icons (replace the old emoji) ----
    val plug = listOf<El>(Pa("M9 2v6M15 2v6M6 8h12v4a6 6 0 0 1-12 0zM12 18v4"))
    val pull = listOf<El>(Pa("M12 4v12M7 11l5 5 5-5M5 20h14"))
    /** Control Center: two toggle switches, one on (knob right, filled) and one off (knob left). */
    val controlCenter = listOf<El>(
        Re(3f, 4.5f, 18f, 7f, 3.5f, fill = true, a = 0.3f),
        Re(3f, 4.5f, 18f, 7f, 3.5f, fill = false, sw = 1.8f),
        Ci(17.5f, 8f, 2.3f),
        Re(3f, 13.5f, 18f, 7f, 3.5f, fill = false, sw = 1.8f),
        Ci(6.5f, 17f, 2.3f)
    )
    val palette = listOf<El>(
        Pa("M12 3a9 9 0 1 0 0 18c1.4 0 2-1 1.6-2.2-.4-1.2.3-2.3 1.6-2.3H17a4 4 0 0 0 4-4C21 6.9 17 3 12 3z"),
        Ci(7.5f, 11f, 1.1f), Ci(10.5f, 7f, 1.1f), Ci(15f, 7.5f, 1.1f)
    )
    val blur = listOf<El>(Pa("M12 3s6 6.2 6 10.5a6 6 0 0 1-12 0C6 9.2 12 3 12 3z"))
    val tilesIos = listOf<El>(
        Re(4f, 4f, 7f, 7f, 1.6f, fill = false), Re(13f, 4f, 7f, 7f, 1.6f, fill = false),
        Re(4f, 13f, 7f, 7f, 1.6f, fill = false), Re(13f, 13f, 7f, 7f, 1.6f, fill = false)
    )
    val sliders = listOf<El>(
        Pa("M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"),
        Ci(15f, 6f, 2f, fill = false), Ci(9f, 12f, 2f, fill = false), Ci(17f, 18f, 2f, fill = false)
    )
    val shield = listOf<El>(Pa("M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6zM9 12l2.2 2.2L15.5 10"))
    val info = listOf<El>(Ci(12f, 12f, 9f, fill = false), Pa("M12 11v6"), Ci(12f, 7.5f, 1.2f))
    val check = listOf<El>(Pa("M5 12.5l4.5 4.5L19 7.5", sw = 2.6f))
    val chevronRight = listOf<El>(Pa("M9 5l7 7-7 7"))
    val triUp = listOf<El>(Pa("M12 5l7 11H5z", fill = true))
    val triDown = listOf<El>(Pa("M12 19L5 8h14z", fill = true))

    val airplaneIos = listOf<El>(
        Pa("M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z", fill = true)
    )
    val shareIos = listOf<El>(
        Ci(12f, 12f, 3.2f, a = 0.3f),
        Ci(12f, 12f, 1.8f),
        Pa("M8.4 15.6a5.2 5.2 0 1 1 7.2 0M5.4 18.6a9.4 9.4 0 1 1 13.2 0", sw = 1.9f)
    )
    val wifiIos = listOf<El>(
        Pa("M12 20.4 2.4 9.6a14 14 0 0 1 19.2 0z", fill = true, a = 0.3f),
        Pa("M2.6 9.4a14 14 0 0 1 18.8 0M5.9 12.9a9.4 9.4 0 0 1 12.2 0M9.1 16.2a4.8 4.8 0 0 1 5.8 0", sw = 1.9f),
        Ci(12f, 19.4f, 1.5f)
    )
    val cellIos = listOf<El>(
        Re(3f, 15f, 3.4f, 5f, 1.2f, a = 0.35f),
        Re(8.2f, 11f, 3.4f, 9f, 1.2f, a = 0.55f),
        Re(13.4f, 7f, 3.4f, 13f, 1.2f, a = 0.8f),
        Re(18.6f, 3f, 3.4f, 17f, 1.2f)
    )
    val bluetoothIos = listOf<El>(
        Pa("M12 3v18l5.2-4.6-4.6-4.4 4.6-4.4z", fill = true, a = 0.3f),
        Pa("M6.5 7.6 17.2 16.4 12 21V3l5.2 4.6L6.5 16.4", sw = 1.9f)
    )
    val hotspot = listOf<El>(
        Pa("M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1")
    )
    val internet = listOf<El>(
        Ci(12f, 12f, 8.6f, a = 0.25f),
        Ci(12f, 12f, 8.6f, fill = false, sw = 1.8f),
        Pa("M3.6 12h16.8M12 3.4c3 2.6 3 14.6 0 17.2M12 3.4c-3 2.6-3 14.6 0 17.2", sw = 1.6f)
    )

    val music = listOf<El>(
        Pa("M9 17.5V6l10-2v11.5", sw = 1.9f),
        Ci(6.8f, 17.8f, 2.7f), Ci(16.8f, 15.8f, 2.7f),
        Pa("M9 6l10-2v3.5L9 9.5z", fill = true, a = 0.35f)
    )
    val airplayIos = listOf<El>(
        Pa("M6 17H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-1"),
        Pa("M12 14l5.5 6.5h-11z", fill = true)
    )
    val prevIos = listOf<El>(Pa("M12.5 6v12l-8-6zM21 6v12l-8-6z", fill = true))
    val nextIos = listOf<El>(Pa("M11.5 6v12l8-6zM3 6v12l8-6z", fill = true))
    val playIos = listOf<El>(Pa("M7 4v16l13-8z", fill = true))
    val pauseIos = listOf<El>(
        Re(6f, 4f, 4.2f, 16f, 1.2f),
        Re(13.8f, 4f, 4.2f, 16f, 1.2f)
    )

    val lockIos = listOf<El>(
        Pa("M20 12a8 8 0 1 1-2.4-5.7M18 3.2v3.8h-3.8", sw = 1.9f),
        Re(8.8f, 11.2f, 6.4f, 5.2f, 1.4f, a = 0.35f),
        Re(8.8f, 11.2f, 6.4f, 5.2f, 1.4f, fill = false, sw = 1.6f),
        Pa("M10.3 11.2V10a1.7 1.7 0 0 1 3.4 0v1.2", sw = 1.6f)
    )
    val mirror = listOf<El>(
        Re(3f, 8.5f, 12.5f, 10f, 2.4f, a = 0.3f),
        Re(3f, 8.5f, 12.5f, 10f, 2.4f, fill = false, sw = 1.8f),
        Re(8.5f, 5f, 12.5f, 10f, 2.4f, fill = false, sw = 1.8f)
    )
    val moonIos = listOf<El>(
        Pa("M20 14.6A8.6 8.6 0 1 1 9.4 4a7.1 7.1 0 0 0 10.6 10.6z", fill = true),
        Ci(17.2f, 5.6f, 1.1f), Ci(20.2f, 9f, 0.8f)
    )
    val chevrons = listOf<El>(Pa("M8 9l4-4 4 4M8 15l4 4 4-4"))

    val brightnessIos = listOf<El>(
        Ci(12f, 12f, 5.6f, a = 0.3f),
        Ci(12f, 12f, 3.2f),
        Pa("M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7", sw = 1.9f)
    )

    /** tier 0 = muted, 1 = one wave, 2 = two waves */
    fun volumeIos(tier: Int): List<El> = buildList<El> {
        add(Pa("M3 9.5v5h4l5 4v-13l-5 4z", fill = true))
        if (tier >= 1) add(Pa("M15.6 9a4 4 0 0 1 0 6"))
        if (tier >= 2) add(Pa("M18.2 6.4a7.6 7.6 0 0 1 0 11.2"))
        if (tier == 0) add(Pa("M15.5 9.5l5 5M20.5 9.5l-5 5"))
    }

    val flashIos = listOf<El>(
        Pa("M8 2.5h8v3.8L14.5 8v12a1.6 1.6 0 0 1-1.6 1.6h-1.8A1.6 1.6 0 0 1 9.5 20V8L8 6.3z", fill = true),
        Re(11f, 10.6f, 2f, 3.6f, 1f, color = Color(0x993C282D)),
        Pa("M4.5 4.5 3 3M19.5 4.5 21 3M20 9.5h2M2 9.5h2", sw = 1.6f, a = 0.7f)
    )
    val timerIos = listOf<El>(
        Ci(12f, 13.4f, 7.8f, a = 0.25f),
        Ci(12f, 13.4f, 7.8f, fill = false, sw = 1.9f),
        Pa("M9.6 2.8h4.8M12 13.4V9M18.4 6.4l1.5-1.5", sw = 1.9f)
    )
    val calcIos = listOf<El>(
        Re(5f, 3f, 14f, 18f, 3f, fill = false, sw = 1.9f),
        Re(7.6f, 5.8f, 8.8f, 3.4f, 1f, a = 0.35f),
        Pa("M8.5 12.5h.01M12 12.5h.01M15.5 12.5h.01M8.5 16.5h.01M12 16.5h.01M15.5 16.5h.01", sw = 2.2f)
    )
    val cameraIos = listOf<El>(
        Pa("M4 7.5h3l1.5-2.5h7L17 7.5h3a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H4A1.5 1.5 0 0 1 2.5 18V9A1.5 1.5 0 0 1 4 7.5z", sw = 1.9f),
        Ci(12f, 13.2f, 3.5f, fill = false, sw = 1.9f)
    )
    val qrIos = listOf<El>(
        Pa("M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2", sw = 1.9f),
        Re(8f, 8f, 3f, 3f, 0.8f), Re(13f, 8f, 3f, 3f, 0.8f), Re(8f, 13f, 3f, 3f, 0.8f),
        Ci(14.5f, 14.5f, 1.4f, a = 0.7f)
    )

    /* ---- icons for the tile-style layout ---- */
    val cellOffIos = listOf<El>(
        Re(3f, 15f, 3.2f, 5f, 1f),
        Re(8.4f, 11f, 3.2f, 9f, 1f),
        Re(13.8f, 7f, 3.2f, 13f, 1f),
        Re(19.2f, 3f, 3.2f, 17f, 1f),
        Pa("M3 3l18 18", sw = 2.4f)
    )
    val bellIos = listOf<El>(
        Pa("M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5z", fill = true, a = 0.3f),
        Pa("M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5zM10 20.5a2 2 0 0 0 4 0", sw = 1.9f)
    )
    val bellOffIos = listOf<El>(
        Pa("M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5z", fill = true, a = 0.3f),
        Pa("M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5zM10 20.5a2 2 0 0 0 4 0M3.5 3.5l17 17", sw = 1.9f)
    )
    val boltRingIos = listOf<El>(
        Ci(12f, 12f, 9.6f, a = 0.25f),
        Ci(12f, 12f, 9.6f, fill = false, sw = 1.8f),
        Pa("M13.2 5.8 8.2 12.8h3.4l-.8 5.4 5-7h-3.4z", fill = true)
    )
    val scissorsIos = listOf<El>(
        Ci(6f, 6.4f, 2.7f, a = 0.3f), Ci(6f, 17.6f, 2.7f, a = 0.3f),
        Ci(6f, 6.4f, 2.7f, fill = false, sw = 1.8f), Ci(6f, 17.6f, 2.7f, fill = false, sw = 1.8f),
        Pa("M8 8.2 20 18M8 15.8 20 6", sw = 1.9f)
    )
    val video = listOf<El>(
        Re(3f, 6.5f, 13f, 11f, 2.8f, a = 0.3f),
        Re(3f, 6.5f, 13f, 11f, 2.8f, fill = false, sw = 1.9f),
        Pa("M16 10.6l5-3v8.8l-5-3z", fill = true)
    )
    val castIos = listOf<El>(
        Pa("M3 8V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-5", sw = 1.9f),
        Pa("M3 12a9 9 0 0 1 9 9M3 16.5a4.5 4.5 0 0 1 4.5 4.5", sw = 1.9f),
        Ci(3.8f, 20.2f, 1.3f)
    )
    val calcMono = listOf<El>(
        Re(5f, 3f, 14f, 18f, 3f, fill = false),
        Pa("M8.5 7.5h7M8.5 12.5h.01M12 12.5h.01M15.5 12.5h.01M8.5 16.5h.01M12 16.5h.01M15.5 16.5h.01", sw = 2.2f)
    )

    val heart = listOf<El>(
        Pa("M12 20.6s-8.2-5-8.2-11.2A4.6 4.6 0 0 1 12 7a4.6 4.6 0 0 1 8.2 2.4c0 6.2-8.2 11.2-8.2 11.2z", fill = true)
    )
    val wavesIos = listOf<El>(
        Ci(12f, 12f, 1.8f),
        Pa("M8.2 8.2a5.4 5.4 0 0 0 0 7.6M15.8 8.2a5.4 5.4 0 0 1 0 7.6M5.2 5.2a9.6 9.6 0 0 0 0 13.6M18.8 5.2a9.6 9.6 0 0 1 0 13.6")
    )
    val locationIos = listOf<El>(
        Pa("M12 21s-6.6-5.6-6.6-11a6.6 6.6 0 0 1 13.2 0c0 5.4-6.6 11-6.6 11z", fill = true, a = 0.3f),
        Pa("M12 21s-6.6-5.6-6.6-11a6.6 6.6 0 0 1 13.2 0c0 5.4-6.6 11-6.6 11z", sw = 1.9f),
        Ci(12f, 10f, 2.4f)
    )
    val nfcIos = listOf<El>(
        Pa("M7 7.5a6 6 0 0 1 0 9M11 5a9.5 9.5 0 0 1 0 14M15 2.8a13 13 0 0 1 0 18.4")
    )
    val darkModeIos = listOf<El>(
        Ci(12f, 12f, 8.6f, fill = false, sw = 1.9f),
        Pa("M12 3.4a8.6 8.6 0 0 1 0 17.2z", fill = true)
    )
    val dataSaverIos = listOf<El>(
        Pa("M4 14a8 8 0 0 1 16 0z", fill = true, a = 0.3f),
        Pa("M4 14a8 8 0 0 1 16 0M12 14l4-4M5 20h14", sw = 1.9f)
    )
    val syncIos = listOf<El>(
        Pa("M20 12a8 8 0 0 0-14-5.3L4 9M4 4v5h5M4 12a8 8 0 0 0 14 5.3L20 15M20 20v-5h-5", sw = 1.9f),
        Ci(12f, 12f, 2.2f, a = 0.5f)
    )

    /* ---- style-dependent icons: iOS = *Ios above, MIUI = IcMi, HyperOS = IcHy ---- */
    val wifi: List<El> get() = when (style) { 1 -> IcMi.wifi; 2 -> IcHy.wifi; else -> wifiIos }
    val cell: List<El> get() = when (style) { 1 -> IcMi.cell; 2 -> IcHy.cell; else -> cellIos }
    val cellOff: List<El> get() = when (style) { 1 -> IcMi.cellOff; 2 -> IcHy.cellOff; else -> cellOffIos }
    val bluetooth: List<El> get() = when (style) { 1 -> IcMi.bluetooth; 2 -> IcHy.bluetooth; else -> bluetoothIos }
    val airplane: List<El> get() = when (style) { 1 -> IcMi.airplane; 2 -> IcHy.airplane; else -> airplaneIos }
    val bell: List<El> get() = when (style) { 1 -> IcMi.bell; 2 -> IcHy.bell; else -> bellIos }
    val bellOff: List<El> get() = when (style) { 1 -> IcMi.bellOff; 2 -> IcHy.bellOff; else -> bellOffIos }
    val flash: List<El> get() = when (style) { 1 -> IcMi.flash; 2 -> IcHy.flash; else -> flashIos }
    val scissors: List<El> get() = when (style) { 1 -> IcMi.scissors; 2 -> IcHy.scissors; else -> scissorsIos }
    val boltRing: List<El> get() = when (style) { 1 -> IcMi.boltRing; 2 -> IcHy.boltRing; else -> boltRingIos }
    val lock: List<El> get() = when (style) { 1 -> IcMi.lock; 2 -> IcHy.lock; else -> lockIos }
    val cast: List<El> get() = when (style) { 1 -> IcMi.cast; 2 -> IcHy.cast; else -> castIos }
    val waves: List<El> get() = when (style) { 1 -> IcMi.waves; 2 -> IcHy.waves; else -> wavesIos }
    val timer: List<El> get() = when (style) { 1 -> IcMi.timer; 2 -> IcHy.timer; else -> timerIos }
    val moon: List<El> get() = when (style) { 1 -> IcMi.moon; 2 -> IcHy.moon; else -> moonIos }
    val location: List<El> get() = when (style) { 1 -> IcMi.location; 2 -> IcHy.location; else -> locationIos }
    val nfc: List<El> get() = when (style) { 1 -> IcMi.nfc; 2 -> IcHy.nfc; else -> nfcIos }
    val darkMode: List<El> get() = when (style) { 1 -> IcMi.darkMode; 2 -> IcHy.darkMode; else -> darkModeIos }
    val dataSaver: List<El> get() = when (style) { 1 -> IcMi.dataSaver; 2 -> IcHy.dataSaver; else -> dataSaverIos }
    val sync: List<El> get() = when (style) { 1 -> IcMi.sync; 2 -> IcHy.sync; else -> syncIos }
    val camera: List<El> get() = when (style) { 1 -> IcMi.camera; 2 -> IcHy.camera; else -> cameraIos }
    val calc: List<El> get() = when (style) { 1 -> IcMi.calc; 2 -> IcHy.calc; else -> calcIos }
    val qr: List<El> get() = when (style) { 1 -> IcMi.qr; 2 -> IcHy.qr; else -> qrIos }
    val gear: List<El> get() = when (style) { 1 -> IcMi.gear; 2 -> IcHy.gear; else -> gearIos }
    val share: List<El> get() = when (style) { 1 -> IcMi.share; 2 -> IcHy.share; else -> shareIos }
    val airplay: List<El> get() = when (style) { 1 -> IcMi.airplay; 2 -> IcHy.airplay; else -> airplayIos }
    val tiles: List<El> get() = when (style) { 1 -> IcMi.tiles; 2 -> IcHy.tiles; else -> tilesIos }
    val brightness: List<El> get() = when (style) { 1 -> IcMi.brightness; 2 -> IcHy.brightness; else -> brightnessIos }
    val prev: List<El> get() = when (style) { 1 -> IcMi.prev; 2 -> IcHy.prev; else -> prevIos }
    val next: List<El> get() = when (style) { 1 -> IcMi.next; 2 -> IcHy.next; else -> nextIos }
    val play: List<El> get() = when (style) { 1 -> IcMi.play; 2 -> IcHy.play; else -> playIos }
    val pause: List<El> get() = when (style) { 1 -> IcMi.pause; 2 -> IcHy.pause; else -> pauseIos }
    fun volume(tier: Int): List<El> = when (style) { 1 -> IcMi.volume(tier); 2 -> IcHy.volume(tier); else -> volumeIos(tier) }
}

/**
 * MIUI icons: heavy, solid glyphs with round ends, no see-through "ghost" layers.
 * Filled shapes where MIUI uses them (airplane, bell, torch, moon), thick 2.3 strokes elsewhere.
 */
object IcMi {
    private const val S = 2.3f
    private const val BELL = "M12 3a6 6 0 0 0-6 6c0 4.5-1.6 5.8-2.2 7.2h16.4C19.6 14.8 18 13.5 18 9a6 6 0 0 0-6-6z"
    private const val TRI_PREV = "M12.5 6.2v11.6L4.6 12zM21 6.2v11.6L13.1 12z"
    private const val TRI_NEXT = "M11.5 6.2v11.6L19.4 12zM3 6.2v11.6L10.9 12z"
    private const val TRI_PLAY = "M7.5 4.8v14.4L19.5 12z"

    val wifi = listOf<El>(
        Pa("M2.2 9.2a14.2 14.2 0 0 1 19.6 0M5.6 12.8a9.4 9.4 0 0 1 12.8 0M8.9 16.3a4.7 4.7 0 0 1 6.2 0", sw = 2.6f),
        Ci(12f, 19.6f, 1.9f)
    )
    val cell = listOf<El>(
        Re(3f, 14.5f, 3.6f, 5.5f, 1.3f), Re(8.4f, 10.5f, 3.6f, 9.5f, 1.3f),
        Re(13.8f, 6.5f, 3.6f, 13.5f, 1.3f), Re(19.2f, 2.5f, 3.4f, 17.5f, 1.3f)
    )
    val cellOff = listOf<El>(
        Re(3f, 14.5f, 3.6f, 5.5f, 1.3f), Re(8.4f, 10.5f, 3.6f, 9.5f, 1.3f),
        Re(13.8f, 6.5f, 3.6f, 13.5f, 1.3f), Re(19.2f, 2.5f, 3.4f, 17.5f, 1.3f),
        Pa("M3.5 3.5l17 17", sw = 2.6f)
    )
    val bluetooth = listOf<El>(Pa("M6.8 7.8 17 16.2 12 20.6V3.4l5 4.4L6.8 16.2", sw = 2.4f))
    val airplane = listOf<El>(
        Pa("M21.5 15.8v-1.9l-8.2-5.1V3.6a1.3 1.3 0 0 0-2.6 0v5.2L2.5 13.9v1.9l8.2-2.3v4.4l-2.2 1.7v1.6l3.5-.9 3.5.9v-1.6l-2.2-1.7v-4.4z", fill = true),
        Pa("M21.5 15.8v-1.9l-8.2-5.1V3.6a1.3 1.3 0 0 0-2.6 0v5.2L2.5 13.9v1.9l8.2-2.3v4.4l-2.2 1.7v1.6l3.5-.9 3.5.9v-1.6l-2.2-1.7v-4.4z", sw = 0.8f)
    )
    val bell = listOf<El>(Pa(BELL, fill = true), Pa("M9.8 19.2a2.3 2.3 0 0 0 4.4 0z", fill = true))
    val bellOff = listOf<El>(Pa("$BELL M9.8 19.5a2.3 2.3 0 0 0 4.4 0", sw = 2.1f), Pa("M3.8 3.8l16.4 16.4", sw = 2.6f))
    val flash = listOf<El>(
        Pa("M8.2 2.6h7.6v4L14 8.4V20a2 2 0 0 1-2 2 2 2 0 0 1-2-2V8.4L8.2 6.6z", fill = true),
        Pa("M8.2 2.6h7.6v4L14 8.4V20a2 2 0 0 1-2 2 2 2 0 0 1-2-2V8.4L8.2 6.6z", sw = 0.8f)
    )
    val scissors = listOf<El>(
        Ci(6f, 6.2f, 2.6f, fill = false, sw = 2.2f), Ci(6f, 17.8f, 2.6f, fill = false, sw = 2.2f),
        Pa("M8 8l12 9.2M8 16l12-9.2", sw = 2.4f)
    )
    val boltRing = listOf<El>(
        Re(2.8f, 7f, 16.4f, 10f, 2.8f, fill = false, sw = 2.2f),
        Re(20.4f, 10.2f, 1.8f, 3.6f, 0.9f),
        Pa("M11.4 9.4l-2.4 3.2h2.8l-.6 2.6 3-3.8h-2.8z", fill = true)
    )
    val lock = listOf<El>(
        Re(6f, 10.5f, 12f, 9.5f, 2.6f),
        Pa("M8.6 10.5V8a3.4 3.4 0 0 1 6.8 0v2.5", sw = 2.4f)
    )
    val cast = listOf<El>(
        Pa("M3 8V6.2A2.2 2.2 0 0 1 5.2 4h13.6A2.2 2.2 0 0 1 21 6.2v11.6a2.2 2.2 0 0 1-2.2 2.2H14", sw = S),
        Pa("M3 12.2a8.8 8.8 0 0 1 8.8 8.8M3 16.6a4.4 4.4 0 0 1 4.4 4.4", sw = S),
        Ci(3.9f, 20.1f, 1.4f)
    )
    val waves = listOf<El>(
        Ci(12f, 12f, 2.5f),
        Pa("M8 8a5.7 5.7 0 0 0 0 8M16 8a5.7 5.7 0 0 1 0 8M4.9 4.9a10 10 0 0 0 0 14.2M19.1 4.9a10 10 0 0 1 0 14.2", sw = S)
    )
    val timer = listOf<El>(
        Ci(12f, 13.4f, 7.8f, fill = false, sw = 2.4f),
        Pa("M9.5 2.8h5M12 13.4V9.2M18.4 6.2l1.6-1.6", sw = 2.4f)
    )
    val moon = listOf<El>(Pa("M20.5 14.4A8.7 8.7 0 1 1 9.6 3.5a7.2 7.2 0 0 0 10.9 10.9z", fill = true))
    val location = listOf<El>(
        Pa("M12 21.5s-6.8-5.8-6.8-11.3a6.8 6.8 0 0 1 13.6 0c0 5.5-6.8 11.3-6.8 11.3z", sw = S),
        Ci(12f, 10.2f, 2.5f)
    )
    val nfc = listOf<El>(Pa("M7 7.6a6 6 0 0 1 0 8.8M11.2 5a9.6 9.6 0 0 1 0 14M15.4 2.6a13.2 13.2 0 0 1 0 18.8", sw = 2.4f))
    val darkMode = listOf<El>(
        Ci(12f, 12f, 8.5f, fill = false, sw = S),
        Pa("M12 3.5a8.5 8.5 0 0 1 0 17z", fill = true)
    )
    val dataSaver = listOf<El>(Pa("M4 15a8 8 0 0 1 16 0M12 15l4-4.5M5 20h14", sw = S))
    val sync = listOf<El>(Pa("M20 12a8 8 0 0 0-14-5.3L4 9M4 4v5h5M4 12a8 8 0 0 0 14 5.3L20 15M20 20v-5h-5", sw = S))
    val camera = listOf<El>(
        Pa("M4 7.5h3l1.5-2.5h7L17 7.5h3a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H4A1.5 1.5 0 0 1 2.5 18V9A1.5 1.5 0 0 1 4 7.5z", sw = 2.2f),
        Ci(12f, 13.2f, 3.5f, fill = false, sw = 2.2f)
    )
    val calc = listOf<El>(
        Re(5f, 3f, 14f, 18f, 3f, fill = false, sw = 2.2f),
        Pa("M8.5 7.5h7M8.5 12.5h.01M12 12.5h.01M15.5 12.5h.01M8.5 16.5h.01M12 16.5h.01M15.5 16.5h.01", sw = 2.6f)
    )
    val qr = listOf<El>(
        Pa("M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2", sw = 2.2f),
        Re(8f, 8f, 3f, 3f, 0.8f), Re(13f, 8f, 3f, 3f, 0.8f), Re(8f, 13f, 3f, 3f, 0.8f), Re(13.2f, 13.2f, 2.8f, 2.8f, 0.8f)
    )
    /** MIUI settings = the hexagon. */
    val gear get() = Ic.hex
    val share = listOf<El>(
        Ci(6.2f, 12f, 2.8f), Ci(17.6f, 5.8f, 2.8f), Ci(17.6f, 18.2f, 2.8f),
        Pa("M8.6 10.7l6.6-3.8M8.6 13.3l6.6 3.8", sw = 2.2f)
    )
    val airplay = listOf<El>(
        Pa("M3.5 9.6v4.8h3.9l5 4V5.6l-5 4z", fill = true),
        Pa("M16 9.2a4 4 0 0 1 0 5.6M18.7 6.6a7.7 7.7 0 0 1 0 10.8", sw = S)
    )
    val tiles = listOf<El>(Re(3.5f, 3.5f, 7.5f, 7.5f, 2.2f), Re(13f, 3.5f, 7.5f, 7.5f, 2.2f), Re(3.5f, 13f, 7.5f, 7.5f, 2.2f), Re(13f, 13f, 7.5f, 7.5f, 2.2f))
    val brightness = listOf<El>(
        Ci(12f, 12f, 4.3f),
        Pa("M12 2.6v2.6M12 18.8v2.6M2.6 12h2.6M18.8 12h2.6M5.4 5.4l1.9 1.9M16.7 16.7l1.9 1.9M5.4 18.6l1.9-1.9M16.7 7.3l1.9-1.9", sw = 2.4f)
    )
    val prev = listOf<El>(Pa(TRI_PREV, fill = true), Pa(TRI_PREV, sw = 1.8f))
    val next = listOf<El>(Pa(TRI_NEXT, fill = true), Pa(TRI_NEXT, sw = 1.8f))
    val play = listOf<El>(Pa(TRI_PLAY, fill = true), Pa(TRI_PLAY, sw = 1.8f))
    val pause = listOf<El>(Re(5.8f, 4.2f, 4.4f, 15.6f, 1.8f), Re(13.8f, 4.2f, 4.4f, 15.6f, 1.8f))

    fun volume(tier: Int): List<El> = buildList<El> {
        add(Pa("M3 9.6v4.8h4l5.2 4.2V5.4L7 9.6z", fill = true))
        if (tier >= 1) add(Pa("M15.6 9.2a4 4 0 0 1 0 5.6", sw = S))
        if (tier >= 2) add(Pa("M18.4 6.5a7.8 7.8 0 0 1 0 11", sw = S))
        if (tier == 0) add(Pa("M15.5 9.5l5 5M20.5 9.5l-5 5", sw = S))
    }
}

/**
 * HyperOS icons: light, geometric outlines on a thin 1.6 line with round ends. Nothing is filled
 * except small details, so they look airy next to the glass tiles.
 */
object IcHy {
    private const val S = 1.6f
    private const val BELL = "M6 10a6 6 0 0 1 12 0c0 5 1.6 6.4 2 7.5H4c.4-1.1 2-2.5 2-7.5z"
    private const val BAT = "M3 7h16a2.4 2.4 0 0 1 2.4 2.4v5.2A2.4 2.4 0 0 1 19 17H3z"

    val wifi = listOf<El>(
        Pa("M2.8 9.4a13.6 13.6 0 0 1 18.4 0M6 12.8a9 9 0 0 1 12 0M9.2 16.1a4.4 4.4 0 0 1 5.6 0", sw = 1.7f),
        Ci(12f, 19.4f, 1.3f)
    )
    /** four thin upright bars of growing height */
    val cell = listOf<El>(Pa("M5 19v-3M9.7 19v-6M14.3 19V9.5M19 19V5", sw = 2.4f))
    val cellOff = listOf<El>(Pa("M5 19v-3M9.7 19v-6M14.3 19V9.5M19 19V5", sw = 2.4f), Pa("M3.5 3.5l17 17", sw = 2.2f))
    val bluetooth = listOf<El>(Pa("M6.8 7.8 17 16.2 12 20.6V3.4l5 4.4L6.8 16.2", sw = 1.7f))
    val airplane = listOf<El>(
        Pa("M21 15.5v-1.6l-7.6-4.7V4a1.4 1.4 0 0 0-2.8 0v5.2L3 13.9v1.6l7.6-2.1v4.6l-1.8 1.5V21l3.2-.9 3.2.9v-1.5l-1.8-1.5v-4.6z", sw = S)
    )
    val bell = listOf<El>(Pa("$BELL M10 20.5a2 2 0 0 0 4 0", sw = 1.7f))
    val bellOff = listOf<El>(Pa("$BELL M10 20.5a2 2 0 0 0 4 0", sw = 1.7f), Pa("M3.5 3.5l17 17", sw = 1.7f))
    val flash = listOf<El>(
        Pa("M8.2 2.8h7.6v3.5L14.2 8v11.6a1.8 1.8 0 0 1-1.8 1.8h-.8a1.8 1.8 0 0 1-1.8-1.8V8L8.2 6.3z", sw = 1.7f),
        Pa("M12 11v2.8", sw = 1.7f)
    )
    val scissors = listOf<El>(
        Ci(6f, 6.4f, 2.5f, fill = false, sw = 1.7f), Ci(6f, 17.6f, 2.5f, fill = false, sw = 1.7f),
        Pa("M8 8.2 20 18M8 15.8 20 6", sw = 1.7f)
    )
    val boltRing = listOf<El>(
        Pa(BAT, sw = 1.7f),
        Pa("M22 10.4v3.2", sw = 1.7f),
        Pa("M11.6 9.2 8.8 12.6h3l-.8 3 3.2-3.8h-3z", sw = 1.4f)
    )
    val lock = listOf<El>(
        Pa("M20 12a8 8 0 1 1-2.4-5.7M18 3.2v3.8h-3.8", sw = S),
        Re(8.8f, 11.2f, 6.4f, 5.2f, 1.4f, fill = false, sw = 1.5f),
        Pa("M10.3 11.2V10a1.7 1.7 0 0 1 3.4 0v1.2", sw = 1.5f)
    )
    val cast = listOf<El>(
        Pa("M3 8V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-5", sw = 1.7f),
        Pa("M3 12a9 9 0 0 1 9 9M3 16.5a4.5 4.5 0 0 1 4.5 4.5", sw = 1.7f),
        Ci(3.8f, 20.2f, 1f)
    )
    val waves = listOf<El>(
        Ci(12f, 12f, 1.6f),
        Pa("M8.2 8.2a5.4 5.4 0 0 0 0 7.6M15.8 8.2a5.4 5.4 0 0 1 0 7.6M5.2 5.2a9.6 9.6 0 0 0 0 13.6M18.8 5.2a9.6 9.6 0 0 1 0 13.6", sw = S)
    )
    val timer = listOf<El>(
        Ci(12f, 13.4f, 7.8f, fill = false, sw = 1.7f),
        Pa("M9.6 2.8h4.8M12 13.4V9M18.4 6.4l1.5-1.5", sw = 1.7f)
    )
    val moon = listOf<El>(Pa("M20 14.6A8.6 8.6 0 1 1 9.4 4a7.1 7.1 0 0 0 10.6 10.6z", sw = 1.7f))
    val location = listOf<El>(
        Pa("M12 21s-6.6-5.6-6.6-11a6.6 6.6 0 0 1 13.2 0c0 5.4-6.6 11-6.6 11z", sw = 1.7f),
        Ci(12f, 10f, 2.4f, fill = false, sw = 1.7f)
    )
    val nfc = listOf<El>(Pa("M7 7.5a6 6 0 0 1 0 9M11 5a9.5 9.5 0 0 1 0 14M15 2.8a13 13 0 0 1 0 18.4", sw = 1.7f))
    val darkMode = listOf<El>(
        Ci(12f, 12f, 8.6f, fill = false, sw = 1.7f),
        Pa("M12 3.4a8.6 8.6 0 0 1 0 17.2z", fill = true, a = 0.55f)
    )
    val dataSaver = listOf<El>(Pa("M4 14a8 8 0 0 1 16 0M12 14l4-4M5 20h14", sw = 1.7f))
    val sync = listOf<El>(Pa("M20 12a8 8 0 0 0-14-5.3L4 9M4 4v5h5M4 12a8 8 0 0 0 14 5.3L20 15M20 20v-5h-5", sw = 1.7f))
    val camera = listOf<El>(
        Pa("M4 7.5h3l1.5-2.5h7L17 7.5h3a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H4A1.5 1.5 0 0 1 2.5 18V9A1.5 1.5 0 0 1 4 7.5z", sw = 1.7f),
        Ci(12f, 13.2f, 3.5f, fill = false, sw = 1.7f)
    )
    val calc = listOf<El>(
        Re(5f, 3f, 14f, 18f, 3f, fill = false, sw = 1.7f),
        Pa("M8.5 7.8h7M8.5 12.5h.01M12 12.5h.01M15.5 12.5h.01M8.5 16.5h.01M12 16.5h.01M15.5 16.5h.01", sw = 2f)
    )
    val qr = listOf<El>(
        Pa("M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2", sw = 1.7f),
        Re(8f, 8f, 3f, 3f, 0.8f, fill = false, sw = 1.4f), Re(13f, 8f, 3f, 3f, 0.8f, fill = false, sw = 1.4f),
        Re(8f, 13f, 3f, 3f, 0.8f, fill = false, sw = 1.4f), Pa("M13.5 14.5h2.5M14.8 13v3.5", sw = 1.4f)
    )
    val gear = listOf<El>(
        Ci(12f, 12f, 3f, fill = false, sw = 1.7f),
        Ci(12f, 12f, 7.2f, fill = false, sw = 1.7f),
        Pa("M12 2.8v2M12 19.2v2M2.8 12h2M19.2 12h2M5.5 5.5l1.4 1.4M17.1 17.1l1.4 1.4M18.5 5.5l-1.4 1.4M6.9 17.1l-1.4 1.4", sw = 1.7f)
    )
    val share = listOf<El>(
        Ci(6.2f, 12f, 2.5f, fill = false, sw = 1.6f), Ci(17.6f, 5.8f, 2.5f, fill = false, sw = 1.6f), Ci(17.6f, 18.2f, 2.5f, fill = false, sw = 1.6f),
        Pa("M8.5 10.8l6.8-3.9M8.5 13.2l6.8 3.9", sw = 1.6f)
    )
    val airplay = listOf<El>(
        Pa("M3.5 9.8v4.4h3.8l4.9 3.9V5.9L7.3 9.8z", sw = 1.7f),
        Pa("M15.8 9.4a3.8 3.8 0 0 1 0 5.2M18.4 6.8a7.4 7.4 0 0 1 0 10.4", sw = 1.7f)
    )
    val tiles = listOf<El>(
        Re(4f, 4f, 7f, 7f, 2f, fill = false, sw = 1.6f), Re(13f, 4f, 7f, 7f, 2f, fill = false, sw = 1.6f),
        Re(4f, 13f, 7f, 7f, 2f, fill = false, sw = 1.6f), Re(13f, 13f, 7f, 7f, 2f, fill = false, sw = 1.6f)
    )
    val brightness = listOf<El>(
        Ci(12f, 12f, 4f, fill = false, sw = 1.7f),
        Pa("M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7", sw = 1.7f)
    )
    val prev = listOf<El>(Pa("M12.5 6.4v11.2L5 12zM21 6.4v11.2L13.5 12z", fill = true), Pa("M12.5 6.4v11.2L5 12zM21 6.4v11.2L13.5 12z", sw = 1.2f))
    val next = listOf<El>(Pa("M11.5 6.4v11.2L19 12zM3 6.4v11.2L10.5 12z", fill = true), Pa("M11.5 6.4v11.2L19 12zM3 6.4v11.2L10.5 12z", sw = 1.2f))
    val play = listOf<El>(Pa("M8 5.2v13.6L19 12z", fill = true), Pa("M8 5.2v13.6L19 12z", sw = 1.4f))
    val pause = listOf<El>(Re(6.4f, 4.6f, 3.6f, 14.8f, 1.8f), Re(14f, 4.6f, 3.6f, 14.8f, 1.8f))

    fun volume(tier: Int): List<El> = buildList<El> {
        add(Pa("M3.5 9.8v4.4h3.8l4.9 3.9V5.9L7.3 9.8z", sw = 1.7f))
        if (tier >= 1) add(Pa("M15.6 9.2a4 4 0 0 1 0 5.6", sw = 1.7f))
        if (tier >= 2) add(Pa("M18.2 6.6a7.6 7.6 0 0 1 0 10.8", sw = 1.7f))
        if (tier == 0) add(Pa("M15.5 9.6l5 4.8M20.5 9.6l-5 4.8", sw = 1.7f))
    }
}
