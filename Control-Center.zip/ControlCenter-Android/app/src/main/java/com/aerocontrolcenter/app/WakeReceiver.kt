package com.aerocontrolcenter.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** AeroHUB sends this when Control Center was closed: bring the services and the AeroHUB link back. */
class WakeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != AeroHub.ACTION_WAKE) return
        try { KeepAlive.ensureRunning(c.applicationContext) } catch (_: Throwable) {}
        try { Shell.onScreenOn() } catch (_: Throwable) {}
    }
}
