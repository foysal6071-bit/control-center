package com.aerocontrolcenter.app.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role

/**
 * Everything the user can change under Settings > Theme and Settings > Blur & background.
 * The panels are built once and rebuilt when one of these settings changes (see OverlayService.rebuildLook).
 */
@Immutable
class CCTheme(
    val light: Boolean,
    /** corner radius of tiles, in grid units */
    val radius: Float,
    /** text / icons that sit directly on the background or on a card */
    val fg: Color,
    val fgSub: Color,
    val tile: Color,
    val tileOn: Color,
    val tileOnFg: Color,
    val tileOnSub: Color,
    val tileBad: Color,
    val edge: Color,
    /** notification cards, small pills and chips */
    val card: Color,
    val pill: Color,
    /** tint over the background; with blurBehind this is the only thing drawn behind the panel */
    val scrim: Color,
    val blurBehind: Boolean,
    val bgTop: Color,
    val bgMid: Color,
    val bgBot: Color,
    val sheet: Color,
    /** 0 = iOS, 1 = MIUI, 2 = HyperOS */
    val style: Int = 2
)

val LocalCC = compositionLocalOf { buildTheme(null, true, false) }

object Look {
    /** null = classic (white tiles on dark theme, black tiles on light theme) */
    val accents: List<Color?> = listOf(
        null,
        Color(0xFF0A84FF), // blue
        Color(0xFF30D158), // green
        Color(0xFFFF9F0A), // orange
        Color(0xFFFF375F), // pink
        Color(0xFFBF5AF2), // purple
        Color(0xFF40C8E0)  // teal
    )
    val accentNames = listOf("Classic", "Blue", "Green", "Orange", "Pink", "Purple", "Teal")

    const val DEF_BLUR = 60
    const val DEF_DIM = 25
}

private val INK = Color(0xFF1B1D22)

fun buildTheme(p: SharedPreferences?, systemDark: Boolean, blurBehind: Boolean): CCTheme {
    val mode = p?.getInt("theme_mode", 0) ?: 0
    val light = when (mode) {
        1 -> true
        2 -> !systemDark
        else -> false
    }
    val acc = Look.accents.getOrNull(p?.getInt("accent", 0) ?: 0)
    val style = (p?.getInt("ui_style", 2) ?: 2).coerceIn(0, 2)
    val radius = when (style) {
        1 -> 12f
        2 -> 20f
        else -> when (p?.getInt("corner", 1) ?: 1) {
            0 -> 8f
            2 -> 20f
            else -> 14f
        }
    }
    val dim = ((p?.getInt("dim", Look.DEF_DIM) ?: Look.DEF_DIM).coerceIn(0, 80)) / 100f

    return if (!light) {
        CCTheme(
            light = false, radius = radius,
            fg = Color.White, fgSub = Color(0xA6FFFFFF),
            tile = when (style) { 1 -> Color(0x38FFFFFF); 2 -> Color(0x30FFFFFF); else -> Color(0xDB2B2E35) },
            tileOn = acc?.copy(alpha = 0.96f) ?: if (style == 1) Color(0xFF0F73DD) else Color(0xF2F3F5F9),
            tileOnFg = if (acc != null || style == 1) Color.White else INK,
            tileOnSub = if (acc != null || style == 1) Color(0xCCFFFFFF) else Color(0xFF6B6F78),
            tileBad = Color(0xE0402A30),
            edge = when (style) { 1 -> Color.Transparent; 2 -> Color.White.copy(alpha = 0.30f); else -> Color.White.copy(alpha = 0.10f) },
            card = Color(0xD92B2E35), pill = Color(0x26FFFFFF),
            scrim = if (blurBehind) Color.Black.copy(alpha = dim) else Color.Black.copy(alpha = 0.08f + dim * 0.4f),
            blurBehind = blurBehind,
            bgTop = if (style == 1) Color(0xFF6C6C6E) else Color(0xFF566080),
            bgMid = if (style == 1) Color(0xFF6C6C6E) else Color(0xFF626E90),
            bgBot = if (style == 1) Color(0xFF6C6C6E) else Color(0xFF4B5675),
            sheet = Color(0xCC080A10),
            style = style
        )
    } else {
        CCTheme(
            light = true, radius = radius,
            fg = INK, fgSub = Color(0x99000000),
            tile = if (style == 2) Color(0x73FFFFFF) else Color(0xCCFFFFFF),
            tileOn = acc?.copy(alpha = 0.96f) ?: if (style == 1) Color(0xFF0F73DD) else Color(0xF21B1D22),
            tileOnFg = Color.White,
            tileOnSub = Color(0xB3FFFFFF),
            tileBad = Color(0xE6FFD6D9),
            edge = Color.Black.copy(alpha = 0.07f),
            card = Color(0xE6FFFFFF), pill = Color(0x1A000000),
            scrim = if (blurBehind) Color.White.copy(alpha = dim) else Color.White.copy(alpha = 0.04f + dim * 0.3f),
            blurBehind = blurBehind,
            bgTop = Color(0xFFC9D3EA), bgMid = Color(0xFFDDE4F4), bgBot = Color(0xFFB9C4E0),
            sheet = Color(0xE6F2F4F8),
            style = style
        )
    }
}

@Composable
fun rememberCCTheme(blurBehind: Boolean): CCTheme {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val theme = remember(blurBehind, dark) {
        buildTheme(ctx.getSharedPreferences("cc", Context.MODE_PRIVATE), dark, blurBehind)
    }
    // the style-dependent icons (Ic.wifi, Ic.bell, ...) follow the chosen style
    Ic.style = theme.style
    return theme
}

/**
 * The background behind the panel. With real blur (window blur-behind) only the tint is drawn and the
 * phone's own screen shows through, blurred. Otherwise a soft gradient is painted in its own offscreen
 * layer so moving a slider does not repaint it every frame.
 */
@Composable
internal fun CCWallpaper(th: CCTheme, overlay: Boolean) {
    if (overlay && th.blurBehind) {
        Box(Modifier.fillMaxSize().background(th.scrim))
        return
    }
    Box(
        Modifier.fillMaxSize()
            .graphicsLayer {
                this.alpha = if (overlay) 0.97f else 1f
                compositingStrategy = CompositingStrategy.Offscreen
            }
            .background(Brush.verticalGradient(0f to th.bgTop, 0.55f to th.bgMid, 1f to th.bgBot))
            .drawBehind {
                fun orb(c: Color, cx: Float, cy: Float, r: Float) = drawRect(
                    Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(size.width * cx, size.height * cy), radius = size.width * r)
                )
                if (th.style != 1) {
                    orb(Color(0x99DCE8FF), 0.2f, 0.08f, 0.9f)
                    orb(Color(0x6685B7FF), 0.95f, 0.3f, 0.8f)
                    orb(Color(0x8059D27A), 0.12f, 0.92f, 0.7f)
                    orb(Color(0x80F0545C), 0.75f, 0.96f, 0.65f)
                }
                drawRect(th.scrim)
            }
    )
}

/** Press-and-bounce tap. [onLong] (optional) is the tap-and-hold action. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun Modifier.ccTap(onLong: (() -> Unit)? = null, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.92f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "press")
    val haptic = LocalHapticFeedback.current
    val ctx = LocalContext.current
    val hapticOn = remember { ctx.getSharedPreferences("cc", Context.MODE_PRIVATE).getBoolean("haptic", true) }
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            role = Role.Button,
            onLongClick = if (onLong == null) null else ({
                if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onLong()
            }),
            onClick = {
                if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
        )
}
