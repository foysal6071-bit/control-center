package com.aerocontrolcenter.app

import android.content.Context
import android.provider.Settings

/**
 * Tiles of the phone's own Quick Settings panel (Internet, Night Light, Color inversion, Extra dim, ...).
 * Id in the grid: "sys:<spec>", where spec is the name Android uses inside `sysui_qs_tiles`.
 *
 * Which tiles exist is taken from two places, so that Edit shows everything the real panel has:
 *  1. a catalogue of the standard Android tiles (also the ones that are not in the panel right now), and
 *  2. the real panel list (Settings.Secure "sysui_qs_tiles"), so phone-specific tiles are listed too.
 * Tiles that this app already draws itself (Bluetooth, Flashlight, ...) keep their own ids ([ALIAS]).
 */
object SysTiles {
    const val PREFIX = "sys:"

    /** [key] = Settings.Secure switch that can be flipped with Shizuku (null = only opens [action]). */
    data class Def(
        val spec: String, val label: String, val icon: String,
        val key: String? = null, val action: String? = null, val pkg: String? = null
    ) {
        val id get() = PREFIX + spec
    }

    /** Spec of the real panel -> id of the tile this app already has for it. */
    val ALIAS = mapOf(
        "bt" to "bluetooth", "flashlight" to "torch", "dnd" to "focus", "airplane" to "airplane",
        "rotation" to "rotation", "cast" to "cast", "hotspot" to "hotspot", "battery" to "battery",
        "saver" to "datasaver", "location" to "location", "nfc" to "nfc", "dark" to "dark",
        "qr_code_scanner" to "qr"
    )

    val catalog = listOf(
        Def("internet", "Internet", "wifi", action = "internet"),
        Def("wifi", "Wi-Fi", "wifi", action = "wifi"),
        Def("cell", "Mobile data", "cell", action = "cell"),
        Def("night", "Night Light", "moon", key = "night_display_activated", action = "android.settings.NIGHT_DISPLAY_SETTINGS"),
        Def("inversion", "Color inversion", "dark", key = "accessibility_display_inversion_enabled", action = Settings.ACTION_ACCESSIBILITY_SETTINGS),
        Def("color_correction", "Color correction", "bright", key = "accessibility_display_daltonizer_enabled", action = Settings.ACTION_ACCESSIBILITY_SETTINGS),
        Def("reduce_brightness", "Extra dim", "bright", key = "reduce_bright_colors_activated", action = Settings.ACTION_DISPLAY_SETTINGS),
        Def("onehanded", "One-handed mode", "mirror", key = "one_handed_mode_enabled", action = Settings.ACTION_ACCESSIBILITY_SETTINGS),
        Def("alarm", "Alarm", "timer", action = "alarm"),
        Def("screenrecord", "Screen recorder", "video", action = Settings.ACTION_SETTINGS),
        Def("mictoggle", "Mic access", "sliders", action = Settings.ACTION_PRIVACY_SETTINGS),
        Def("cameratoggle", "Camera access", "camera", action = Settings.ACTION_PRIVACY_SETTINGS),
        Def("work", "Work mode", "lock", action = Settings.ACTION_SETTINGS),
        Def("font_scaling", "Font size", "sliders", action = Settings.ACTION_DISPLAY_SETTINGS),
        Def("live_caption", "Live Caption", "bell", action = Settings.ACTION_SOUND_SETTINGS),
        Def("hearing_devices", "Hearing devices", "bell", action = Settings.ACTION_ACCESSIBILITY_SETTINGS),
        Def("dream", "Screen saver", "dark", action = Settings.ACTION_DREAM_SETTINGS),
        Def("controls", "Device controls", "tiles", action = Settings.ACTION_SETTINGS),
        Def("wallet", "Wallet", "tiles", pkg = "com.google.android.apps.walletnfcrel"),
        Def("record_issue", "Record issue", "video", action = Settings.ACTION_SETTINGS),
        Def("fgsmanager", "Active apps", "tiles", action = Settings.ACTION_SETTINGS)
    )

    fun isSys(id: String) = id.startsWith(PREFIX)

    fun spec(id: String) = id.removePrefix(PREFIX)

    /** The panel's real tile list, e.g. "internet,bt,flashlight,custom(pkg/cls)". Empty when the phone does not tell. */
    fun panelSpecs(c: Context): List<String> = try {
        Settings.Secure.getString(c.contentResolver, "sysui_qs_tiles").orEmpty()
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }
    } catch (_: Throwable) { emptyList() }

    /** Components of the app tiles that sit in the real panel: custom(pkg/cls). */
    fun panelCustom(c: Context): List<String> =
        panelSpecs(c).filter { it.startsWith("custom(") && it.endsWith(")") }.map { it.substring(7, it.length - 1) }

    private fun pretty(spec: String): String =
        spec.replace('_', ' ').replace('-', ' ').trim().replaceFirstChar { it.uppercase() }

    /** Every system tile the Edit screen offers (catalogue + whatever else the real panel contains). */
    fun all(c: Context): List<Def> {
        val known = catalog.map { it.spec }.toSet()
        val extra = panelSpecs(c)
            .filter { !it.startsWith("custom(") && it !in known && it !in ALIAS }
            .distinct()
            .map { Def(it, pretty(it), "tiles", action = Settings.ACTION_SETTINGS) }
        return catalog + extra
    }

    fun def(c: Context, id: String): Def? = if (isSys(id)) all(c).firstOrNull { it.id == id } else null

    fun label(c: Context, id: String): String = def(c, id)?.label ?: pretty(spec(id))

    fun exists(c: Context, id: String): Boolean = def(c, id) != null

    /** On/off of a tile that has a Settings.Secure switch. */
    fun isOn(c: Context, d: Def): Boolean = d.key?.let {
        try { Settings.Secure.getInt(c.contentResolver, it, 0) == 1 } catch (_: Throwable) { false }
    } ?: false
}
