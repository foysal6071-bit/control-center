package com.aerocontrolcenter.app.ui

/** Own vector icons (24 x 24) for the tiles of the phone's Quick Settings panel that had no icon in the app. */
object SysIcons {
    private const val W = 1.9f

    val internet = listOf<El>(
        Ci(12f, 12f, 8.6f, a = 0.25f),
        Ci(12f, 12f, 8.6f, fill = false, sw = W),
        Pa("M3.4 12h17.2M12 3.4c2.6 2.4 3.8 5.3 3.8 8.6s-1.2 6.2-3.8 8.6c-2.6-2.4-3.8-5.3-3.8-8.6s1.2-6.2 3.8-8.6z", sw = W)
    )
    val night = listOf<El>(
        Pa("M19.5 14.6A8 8 0 1 1 9.4 4.5a6.6 6.6 0 0 0 10.1 10.1z", fill = true, a = 0.3f),
        Pa("M19.5 14.6A8 8 0 1 1 9.4 4.5a6.6 6.6 0 0 0 10.1 10.1z", sw = W),
        Pa("M17 3.5v3M15.5 5h3", sw = 1.6f)
    )
    val inversion = listOf<El>(
        Re(3.5f, 3.5f, 17f, 17f, 4f, fill = false, sw = W),
        Pa("M20.5 3.5v17h-17z", fill = true, a = 0.85f)
    )
    val colorCorrection = listOf<El>(
        Ci(9.2f, 9.2f, 5.4f, a = 0.4f), Ci(14.8f, 9.2f, 5.4f, a = 0.4f), Ci(12f, 14.8f, 5.4f, a = 0.4f),
        Ci(9.2f, 9.2f, 5.4f, fill = false, sw = 1.5f), Ci(14.8f, 9.2f, 5.4f, fill = false, sw = 1.5f),
        Ci(12f, 14.8f, 5.4f, fill = false, sw = 1.5f)
    )
    val extraDim = listOf<El>(
        Ci(12f, 12f, 6.2f, a = 0.25f),
        Ci(12f, 12f, 6.2f, fill = false, sw = W),
        Pa("M9.4 12h5.2", sw = W),
        Pa("M12 2.8v1.8M12 19.4v1.8M2.8 12h1.8M19.4 12h1.8M5.5 5.5l1.2 1.2M17.3 17.3l1.2 1.2M5.5 18.5l1.2-1.2M17.3 6.7l1.2-1.2", sw = 1.7f)
    )
    val oneHanded = listOf<El>(
        Re(8f, 3f, 11f, 18f, 2.6f, fill = false, sw = W),
        Pa("M3.5 14.5 6 17.5 8.5 14.5M6 7.5v10", sw = W),
        Pa("M13.5 18h.01", sw = 2.4f)
    )
    val alarm = listOf<El>(
        Ci(12f, 13.2f, 7.4f, a = 0.25f),
        Ci(12f, 13.2f, 7.4f, fill = false, sw = W),
        Pa("M12 9.4v4l2.6 1.6M4 6.2 7.2 3.4M20 6.2l-3.2-2.8", sw = W)
    )
    val screenRecord = listOf<El>(
        Ci(12f, 12f, 8.6f, fill = false, sw = W),
        Ci(12f, 12f, 4.2f)
    )
    val mic = listOf<El>(
        Re(9f, 3f, 6f, 11.5f, 3f, a = 0.3f),
        Re(9f, 3f, 6f, 11.5f, 3f, fill = false, sw = W),
        Pa("M5.5 11.2a6.5 6.5 0 0 0 13 0M12 17.8V21M9 21h6", sw = W)
    )
    val cameraAccess = listOf<El>(
        Re(3f, 6.5f, 18f, 12f, 3f, fill = false, sw = W),
        Ci(12f, 12.5f, 3.3f, fill = false, sw = W),
        Ci(17.6f, 9.5f, 0.9f)
    )
    val work = listOf<El>(
        Re(3f, 7.5f, 18f, 12.5f, 2.6f, a = 0.25f),
        Re(3f, 7.5f, 18f, 12.5f, 2.6f, fill = false, sw = W),
        Pa("M9 7.5V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v1.5M3 13.2h18", sw = W)
    )
    val fontSize = listOf<El>(
        Pa("M2.8 19 8.2 5l5.4 14M4.7 14.4h7", sw = W),
        Pa("M15.6 19l2.9-7.2 2.9 7.2M16.7 16.8h3.6", sw = W)
    )
    val liveCaption = listOf<El>(
        Re(3f, 5f, 18f, 14f, 3.2f, a = 0.25f),
        Re(3f, 5f, 18f, 14f, 3.2f, fill = false, sw = W),
        Pa("M7 10.6h4M13 10.6h4M7 14.4h2.6M11.6 14.4H17", sw = W)
    )
    val hearing = listOf<El>(
        Pa("M6.8 9.6a5.2 5.2 0 0 1 10.4 0c0 3.2-3.3 3.8-3.3 6.8a2.6 2.6 0 0 1-5.2 0", sw = W),
        Pa("M10.2 9.6a1.8 1.8 0 0 1 3.6 0", sw = W)
    )
    val screenSaver = listOf<El>(
        Re(3f, 4f, 18f, 12.5f, 2.6f, fill = false, sw = W),
        Pa("M9 20h6M12 16.5V20", sw = W),
        Pa("M13.8 8.2a3 3 0 1 1-3.2-1.8 2.4 2.4 0 0 0 3.2 1.8z", fill = true)
    )
    val deviceControls = listOf<El>(
        Pa("M4 11 12 4l8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z", fill = true, a = 0.25f),
        Pa("M4 11 12 4l8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z", sw = W),
        Pa("M12 12.2v2.8M9.6 13.2a3 3 0 1 0 4.8 0", sw = 1.6f)
    )
    val wallet = listOf<El>(
        Pa("M4 7.5A2.5 2.5 0 0 1 6.5 5H17v3", sw = W),
        Pa("M4 7.5V17a2.5 2.5 0 0 0 2.5 2.5H19a1.5 1.5 0 0 0 1.5-1.5V9.5A1.5 1.5 0 0 0 19 8H6.5A2.5 2.5 0 0 1 4 7.5z", sw = W),
        Ci(16.4f, 13.7f, 1.3f)
    )
    val recordIssue = listOf<El>(
        Pa("M9 8.5a3 3 0 0 1 6 0v7a3 3 0 0 1-6 0z", fill = true, a = 0.3f),
        Pa("M9 8.5a3 3 0 0 1 6 0v7a3 3 0 0 1-6 0zM3.5 11.5H7M17 11.5h3.5M4.5 18.5 7.5 16.5M19.5 18.5l-3-2M4.5 4.8 7.5 7M19.5 4.8 16.5 7M12 9v8", sw = 1.7f)
    )
    val activeApps = listOf<El>(
        Pa("M9 6.5h11M9 12h11M9 17.5h11", sw = W),
        Ci(4.8f, 6.5f, 1.5f), Ci(4.8f, 12f, 1.5f), Ci(4.8f, 17.5f, 1.5f)
    )

    /** Icon for a spec (see SysTiles.catalog); null = no own icon (the caller uses the style's icon). */
    fun of(spec: String): List<El>? = when (spec) {
        "internet" -> internet
        "night" -> night
        "inversion" -> inversion
        "color_correction" -> colorCorrection
        "reduce_brightness" -> extraDim
        "onehanded" -> oneHanded
        "alarm" -> alarm
        "screenrecord" -> screenRecord
        "mictoggle" -> mic
        "cameratoggle" -> cameraAccess
        "work" -> work
        "font_scaling" -> fontSize
        "live_caption" -> liveCaption
        "hearing_devices" -> hearing
        "dream" -> screenSaver
        "controls" -> deviceControls
        "wallet" -> wallet
        "record_issue" -> recordIssue
        "fgsmanager" -> activeApps
        else -> null
    }
}
