package com.aerocontrolcenter.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/**
 * Quick Settings tiles that other apps provide (Cloudflare 1.1.1.1, Shizuku, scanners, ...).
 * They are found through PackageManager (every app declares a TileService), shown in the grid with the id
 * "qs:<package>/<class>" and pressed through Shizuku with `cmd statusbar click-tile`.
 */
object QsTiles {
    const val PREFIX = "qs:"

    data class Info(val id: String, val label: String, val component: ComponentName)

    fun isQs(id: String) = id.startsWith(PREFIX)

    fun component(id: String): ComponentName? =
        if (isQs(id)) ComponentName.unflattenFromString(id.removePrefix(PREFIX)) else null

    @Volatile private var cache: List<Info>? = null
    @Volatile private var cacheAt = 0L

    /**
     * Every tile service installed on the phone, sorted by name. The scan asks PackageManager for every app and
     * label()/shortLabel() call it for each tile while drawing, so the answer is kept for 30 seconds.
     */
    fun installed(c: Context): List<Info> {
        val now = android.os.SystemClock.elapsedRealtime()
        val hit = cache
        if (hit != null && now - cacheAt < 30_000L) return hit
        val fresh = scan(c)
        cache = fresh
        cacheAt = now
        return fresh
    }

    /** False when the app of this tile was uninstalled (its tile must not stay on the grid as an empty square). */
    fun exists(c: Context, id: String): Boolean {
        val cn = component(id) ?: return false
        return try {
            c.packageManager.getApplicationInfo(cn.packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        } catch (_: Throwable) {
            true   // cannot tell: keep the tile
        }
    }

    private fun scan(c: Context): List<Info> {
        val pm = c.packageManager
        val i = Intent("android.service.quicksettings.action.QS_TILE")
        val list = try {
            pm.queryIntentServices(i, PackageManager.GET_META_DATA)
        } catch (_: Throwable) {
            emptyList()
        }
        val found = list.mapNotNull { r ->
            val si = r.serviceInfo ?: return@mapNotNull null
            if (si.packageName == c.packageName) return@mapNotNull null
            val cn = ComponentName(si.packageName, si.name)
            val tile = try { si.loadLabel(pm).toString() } catch (_: Throwable) { "" }
            val app = try { si.applicationInfo.loadLabel(pm).toString() } catch (_: Throwable) { si.packageName }
            // many apps call the tile just "VPN" or "Scan": add the app name so that it can be told apart
            val label = if (tile.isBlank() || tile.equals(app, true)) app else "$tile ($app)"
            Info(PREFIX + cn.flattenToString(), label, cn)
        }
        // tiles that sit in the phone's real panel but were not returned by the scan (hidden from the query)
        val have = found.map { it.id }.toSet()
        val extra = SysTiles.panelCustom(c).mapNotNull { flat ->
            val cn = ComponentName.unflattenFromString(flat) ?: return@mapNotNull null
            if (cn.packageName == c.packageName || PREFIX + cn.flattenToString() in have) return@mapNotNull null
            try {
                val si = pm.getServiceInfo(cn, 0)
                val tile = try { si.loadLabel(pm).toString() } catch (_: Throwable) { "" }
                val app = try { si.applicationInfo.loadLabel(pm).toString() } catch (_: Throwable) { cn.packageName }
                Info(PREFIX + cn.flattenToString(), if (tile.isBlank() || tile.equals(app, true)) app else "$tile ($app)", cn)
            } catch (_: Throwable) { null }
        }
        return (found + extra).distinctBy { it.id }.sortedBy { it.label.lowercase() }
    }

    fun label(c: Context, id: String): String =
        installed(c).firstOrNull { it.id == id }?.label ?: component(id)?.packageName ?: id

    /** Short name for the tile under the icon: the tile name without the app name in brackets. */
    fun shortLabel(c: Context, id: String): String = label(c, id).substringBefore(" (")

    private val iconCache = HashMap<String, ImageBitmap?>()

    /** The app icon of the tile's app (the tile's own icon is only known to the app while it runs). */
    fun icon(c: Context, id: String): ImageBitmap? = synchronized(iconCache) {
        iconCache.getOrPut(id) {
            try {
                val cn = component(id) ?: return@getOrPut null
                val d = c.packageManager.getApplicationIcon(cn.packageName)
                val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
                val cv = Canvas(bmp)
                d.setBounds(0, 0, 96, 96)
                d.draw(cv)
                bmp.asImageBitmap()
            } catch (_: Throwable) {
                null
            }
        }
    }
}
