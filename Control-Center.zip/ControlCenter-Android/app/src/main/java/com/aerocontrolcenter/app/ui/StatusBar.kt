package com.aerocontrolcenter.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aerocontrolcenter.app.NotifStore
import com.aerocontrolcenter.app.SimInfo
import com.aerocontrolcenter.app.StatusData

/** Colour of the icons and text: white on dark apps, near black on light apps (set from [StatusData.dark]). */
private val LocalInk = compositionLocalOf { Color.White }
private val LocalInkInverse = compositionLocalOf { Color.Black }
private val DARK_INK = Color(0xFF16181D)
private val SAVER = Color(0xFFFFD60A)
private val GREEN = Color(0xFF34C759)
private val RED = Color(0xFFFF453A)

/**
 * The custom status bar: time and notification icons on the left; network speed, alarm, VoLTE, Wi-Fi, mobile
 * signal and a battery pill with the percentage on the right. Nothing is drawn until the phone's own bar is hidden.
 */
@Composable
fun StatusBarContent(d: StatusData) {
    if (!d.active) return

    // slow ease-in-out fade so the colour glides between white and dark instead of snapping
    val fade = tween<Color>(durationMillis = 300, easing = androidx.compose.animation.core.FastOutSlowInEasing)
    val ink by animateColorAsState(if (d.dark) DARK_INK else Color.White, animationSpec = fade, label = "ink")
    val inverse by animateColorAsState(if (d.dark) Color.White else Color.Black, animationSpec = fade, label = "inverse")
    // a faint soft shadow under white text keeps it crisp on bright wallpapers (dark ink needs none)
    val shade = androidx.compose.ui.graphics.Shadow(
        color = Color.Black.copy(alpha = if (d.dark) 0f else 0.35f),
        offset = Offset(0f, 1f), blurRadius = 3f
    )
    // the size setting: every dp and sp inside the bar grows or shrinks together
    val base = LocalDensity.current
    val k = d.scale.coerceIn(0.7f, 1.5f)
    CompositionLocalProvider(
        LocalInk provides ink, LocalInkInverse provides inverse,
        LocalDensity provides Density(base.density * k, base.fontScale)
    ) {
    androidx.compose.material3.ProvideTextStyle(androidx.compose.ui.text.TextStyle(shadow = shade)) {
    val dim = ink.copy(alpha = 0.33f)
    Box(Modifier.fillMaxSize().background(if (d.black) Color.Black else Color.Transparent)) {
        Row(
            Modifier.fillMaxSize().padding(start = (d.padStart / k).dp, end = (d.padEnd / k).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            /* ---------- left: clock + notification icons ---------- */
            Text(d.time, color = ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp, maxLines = 1, softWrap = false)
            if (d.showNotif) {
                val icons = NotifStore.statusIcons
                if (icons.isNotEmpty()) {
                    Spacer(Modifier.width(6.dp))
                    icons.take(3).forEach {
                        Image(
                            bitmap = it, contentDescription = null,
                            colorFilter = ColorFilter.tint(ink),
                            modifier = Modifier.padding(horizontal = 2.dp).size(15.dp)
                        )
                    }
                    if (icons.size > 3) Text("···", color = ink, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }

            Spacer(Modifier.weight(1f))

            /* ---------- right (iPhone order): status icons, SIM signal, Wi-Fi, battery ---------- */
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                if (d.showSpeed) {
                    Column(Modifier.widthIn(min = 28.dp), horizontalAlignment = Alignment.End) {
                        Text(d.speed, color = ink, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp, maxLines = 1, softWrap = false)
                        Text(d.speedUnit, color = ink, fontSize = 8.sp, fontWeight = FontWeight.SemiBold, lineHeight = 9.sp, maxLines = 1, softWrap = false)
                    }
                }
                // whatever is switched on shows here: location, alarm, Bluetooth, VPN, hotspot, airplane mode
                if (d.location) SvgIcon(IcLocation, 12.dp, ink)
                if (d.alarm) AlarmIcon()
                if (d.bluetooth) SvgIcon(IcBluetooth, 13.dp, ink)
                if (d.vpn) VpnBadge()
                if (d.hotspot) HotspotIcon()
                if (d.airplane) AirplaneIcon()
                if (!d.airplane && d.showVolte && d.volte && d.netType.isNotEmpty()) VolteBadge()

                // SIM cards: one signal group, or two stacked ones for dual SIM
                if (!d.airplane) SimSignals(d.sims)

                if (d.wifiLevel >= 0) WifiIcon(d.wifiLevel)
                BatteryPill(d.battery, d.charging, d.saver)
            }
        }
    }
    }
    }
}

private val IcLocation = listOf<El>(Pa("M3 11l19-9-9 19-2-8-8-2z", fill = true))
private val IcBluetooth = listOf<El>(Pa("M7 7.5l10 9-5 4.5V3l5 4.5-10 9", sw = 2.2f))

/**
 * Mobile signal, iPhone style. One SIM: four bars with the network label ("5G", "4G"...) on the right.
 * Two SIMs: two small rows stacked on top of each other, each with its own bars and label.
 * A SIM without service shows empty bars (single SIM: "No Service").
 */
@Composable
private fun SimSignals(sims: List<SimInfo>) {
    val ink = LocalInk.current
    when (sims.size) {
        0 -> {}
        1 -> {
            val s = sims[0]
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                if (s.noService) {
                    Text("No Service", color = ink, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                } else {
                    SignalBars(s.level, 12.dp, 3.dp, 1.5.dp)
                    if (s.net.isNotEmpty()) Text(s.net, color = ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                }
            }
        }
        else -> {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp), horizontalAlignment = Alignment.Start) {
                sims.take(2).forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        SignalBars(if (s.noService) 0 else s.level, 7.dp, 2.dp, 1.dp)
                        Text(
                            if (s.noService) "×" else s.net, color = ink, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                            lineHeight = 8.sp, maxLines = 1, softWrap = false, modifier = Modifier.widthIn(min = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

/** Alarm clock: ring, two hands and the two bells. */
@Composable
private fun AlarmIcon() {
    val ink = LocalInk.current
    Canvas(Modifier.size(13.dp)) {
        val w = size.width
        val sw = w * 0.12f
        val c = Offset(w / 2f, w * 0.56f)
        val r = w * 0.34f
        drawCircle(ink, r, c, style = Stroke(sw))
        drawLine(ink, c, Offset(c.x, c.y - r * 0.6f), sw, StrokeCap.Round)
        drawLine(ink, c, Offset(c.x + r * 0.45f, c.y + r * 0.2f), sw, StrokeCap.Round)
        drawCircle(ink, w * 0.15f, Offset(w * 0.17f, w * 0.2f))
        drawCircle(ink, w * 0.15f, Offset(w * 0.83f, w * 0.2f))
    }
}

/** Airplane mode: the plane glyph, nose pointing right like on iPhone. */
@Composable
private fun AirplaneIcon() {
    val ink = LocalInk.current
    val path = remember {
        PathParser().parsePathString(
            "M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"
        ).toPath()
    }
    Canvas(Modifier.size(15.dp)) {
        val k = size.minDimension / 24f
        withTransform({
            rotate(90f, Offset(size.width / 2f, size.height / 2f))
            scale(k, k, Offset.Zero)
        }) { drawPath(path, ink) }
    }
}

/** Personal hotspot: two interlocked links, like the iPhone one. */
@Composable
private fun HotspotIcon() {
    val ink = LocalInk.current
    Canvas(Modifier.size(14.dp)) {
        val w = size.width
        val sw = w * 0.13f
        withTransform({ rotate(-45f, Offset(w / 2f, w / 2f)) }) {
            val r = w * 0.2f
            drawRoundRect(ink, Offset(w * 0.04f, w / 2f - r), Size(w * 0.58f, r * 2f), CornerRadius(r, r), style = Stroke(sw))
            drawRoundRect(ink, Offset(w * 0.38f, w / 2f - r), Size(w * 0.58f, r * 2f), CornerRadius(r, r), style = Stroke(sw))
        }
    }
}

/** "VPN" in a small outlined pill. */
@Composable
private fun VpnBadge() {
    val ink = LocalInk.current
    Box(
        Modifier.border(1.dp, ink, RoundedCornerShape(4.dp)).padding(horizontal = 3.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("VPN", color = ink, fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 8.sp, maxLines = 1, softWrap = false)
    }
}

/** White "Vo LTE" badge. */
@Composable
private fun VolteBadge() {
    val ink = LocalInk.current
    val inverse = LocalInkInverse.current
    Box(
        Modifier.background(ink, RoundedCornerShape(3.dp)).padding(horizontal = 3.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Vo", color = inverse, fontSize = 6.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 6.sp, maxLines = 1)
            Text("LTE", color = inverse, fontSize = 6.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 6.sp, maxLines = 1)
        }
    }
}

/** Wi-Fi: four rounded bars that grow in height, lit by signal level 0..4 (0 = none lit, 4 = all four). */
@Composable
private fun WifiIcon(level: Int) {
    SignalBars(level, 13.dp, 3.dp, 1.5.dp)
}

/** Four rounded bars that grow in height; the first [level] are lit. */
@Composable
private fun SignalBars(level: Int, height: androidx.compose.ui.unit.Dp, barWidth: androidx.compose.ui.unit.Dp, gap: androidx.compose.ui.unit.Dp) {
    val ink = LocalInk.current
    val dim = ink.copy(alpha = 0.33f)
    Row(
        Modifier.height(height),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(gap)
    ) {
        for (i in 1..4) {
            Box(
                Modifier.width(barWidth).height(height * (0.35f + 0.2167f * (i - 1)))
                    .background(if (i <= level) ink else dim, RoundedCornerShape(barWidth / 2.2f))
            )
        }
    }
}

/** iPhone battery: pill with the percentage inside; green while charging (with a bolt), yellow in saver, red when low. */
@Composable
private fun BatteryPill(level: Int, charging: Boolean, saver: Boolean) {
    val ink = LocalInk.current
    val inverse = LocalInkInverse.current
    val dim = ink.copy(alpha = 0.35f)
    val fill = when {
        charging -> GREEN
        saver -> SAVER
        level <= 20 -> RED
        else -> ink
    }
    val text = if (fill == ink) inverse else Color.White
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(27.dp).height(13.dp).clip(RoundedCornerShape(4.5.dp)).background(dim)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(level.coerceIn(0, 100) / 100f).background(fill))
            Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
                if (charging) SvgIcon(IcBolt, 8.dp, text)
                Text(
                    level.toString(), color = text, fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold,
                    lineHeight = 10.sp, maxLines = 1, softWrap = false
                )
            }
        }
        Box(Modifier.padding(start = 1.dp).width(2.dp).height(4.5.dp).background(dim, RoundedCornerShape(topEnd = 1.5.dp, bottomEnd = 1.5.dp)))
    }
}

private val IcBolt = listOf<El>(Pa("M13 2L5 14h6l-1 8 8-12h-6z", fill = true))
