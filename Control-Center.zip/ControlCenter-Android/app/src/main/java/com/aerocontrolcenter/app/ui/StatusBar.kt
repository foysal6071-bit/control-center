package com.aerocontrolcenter.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aerocontrolcenter.app.NotifStore
import com.aerocontrolcenter.app.SimInfo
import com.aerocontrolcenter.app.StatusData

/** Colour of the icons and text: white on dark apps, near black on light apps (set from [StatusData.dark]). */
private val LocalInk = compositionLocalOf { Color.White }
private val LocalInkInverse = compositionLocalOf { Color.Black }
private val DARK_INK = Color(0xFF16181D)
private val SAVER = Color(0xFFFFD60A)
private val GREEN = Color(0xFF34C759)
private val RED = Color(0xFFFF453A)

/**
 * The custom status bar: time and notification icons on the left; network speed, alarm, VoLTE, Wi-Fi, mobile
 * signal and a battery pill with the percentage on the right. Nothing is drawn until the phone's own bar is hidden.
 */
@Composable
fun StatusBarContent(d: StatusData) {
    if (!d.active) return

    // slow ease-in-out fade so the colour glides between white and dark instead of snapping
    val fade = tween<Color>(durationMillis = 300, easing = androidx.compose.animation.core.FastOutSlowInEasing)
    val ink by animateColorAsState(if (d.dark) DARK_INK else Color.White, animationSpec = fade, label = "ink")
    val inverse by animateColorAsState(if (d.dark) Color.White else Color.Black, animationSpec = fade, label = "inverse")
    // a faint soft shadow under white text keeps it crisp on bright wallpapers (dark ink needs none)
    val shade = androidx.compose.ui.graphics.Shadow(
        color = Color.Black.copy(alpha = if (d.dark) 0f else 0.35f),
        offset = Offset(0f, 1f), blurRadius = 3f
    )
    // the size setting: every dp and sp inside the bar grows or shrinks together
    val base = LocalDensity.current
    val k = d.scale.coerceIn(0.7f, 1.5f)
    CompositionLocalProvider(
        LocalInk provides ink, LocalInkInverse provides inverse,
        LocalDensity provides Density(base.density * k, base.fontScale)
    ) {
    androidx.compose.material3.ProvideTextStyle(androidx.compose.ui.text.TextStyle(shadow = shade)) {
    val dim = ink.copy(alpha = 0.33f)
    Box(Modifier.fillMaxSize().background(if (d.black) Color.Black else Color.Transparent)) {
        Row(
            Modifier.fillMaxSize().padding(start = (d.padStart / k).dp, end = (d.padEnd / k).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            when (d.style) {
                1 -> MiuiLeft(d)
                2 -> HyperLeft(d)
                else -> IosLeft(d)
            }

            Spacer(Modifier.weight(1f))

            when (d.style) {
                1 -> MiuiRight(d)
                2 -> HyperRight(d)
                else -> IosRight(d)
            }
        }
    }
    }
    }
}

private val IcLocation = listOf<El>(Pa("M3 11l19-9-9 19-2-8-8-2z", fill = true))
private val IcBluetooth = listOf<El>(Pa("M7 7.5l10 9-5 4.5V3l5 4.5-10 9", sw = 2.2f))

/**
 * Mobile signal, iPhone style. One SIM: four bars with the network label ("5G", "4G"...) on the right.
 * Two SIMs: two small rows stacked on top of each other, each with its own bars and label.
 * A SIM without service shows empty bars (single SIM: "No Service").
 */
@Composable
private fun SimSignals(sims: List<SimInfo>) {
    val ink = LocalInk.current
    when (sims.size) {
        0 -> {}
        1 -> {
            val s = sims[0]
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                if (s.noService) {
                    Text("No Service", color = ink, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                } else {
                    SignalBars(s.level, 12.dp, 3.dp, 1.5.dp)
                    if (s.net.isNotEmpty()) Text(s.net, color = ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                }
            }
        }
        else -> {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp), horizontalAlignment = Alignment.Start) {
                sims.take(2).forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        SignalBars(if (s.noService) 0 else s.level, 7.dp, 2.dp, 1.dp)
                        Text(
                            if (s.noService) "×" else s.net, color = ink, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                            lineHeight = 8.sp, maxLines = 1, softWrap = false, modifier = Modifier.widthIn(min = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

/** Alarm clock: ring, two hands and the two bells. */
@Composable
private fun AlarmIcon() {
    val ink = LocalInk.current
    Canvas(Modifier.size(13.dp)) {
        val w = size.width
        val sw = w * 0.12f
        val c = Offset(w / 2f, w * 0.56f)
        val r = w * 0.34f
        drawCircle(ink, r, c, style = Stroke(sw))
        drawLine(ink, c, Offset(c.x, c.y - r * 0.6f), sw, StrokeCap.Round)
        drawLine(ink, c, Offset(c.x + r * 0.45f, c.y + r * 0.2f), sw, StrokeCap.Round)
        drawCircle(ink, w * 0.15f, Offset(w * 0.17f, w * 0.2f))
        drawCircle(ink, w * 0.15f, Offset(w * 0.83f, w * 0.2f))
    }
}

/** Airplane mode: the plane glyph, nose pointing right like on iPhone. */
@Composable
private fun AirplaneIcon() {
    val ink = LocalInk.current
    val path = remember {
        PathParser().parsePathString(
            "M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"
        ).toPath()
    }
    Canvas(Modifier.size(15.dp)) {
        val k = size.minDimension / 24f
        withTransform({
            rotate(90f, Offset(size.width / 2f, size.height / 2f))
            scale(k, k, Offset.Zero)
        }) { drawPath(path, ink) }
    }
}

/** Personal hotspot: two interlocked links, like the iPhone one. */
@Composable
private fun HotspotIcon() {
    val ink = LocalInk.current
    Canvas(Modifier.size(14.dp)) {
        val w = size.width
        val sw = w * 0.13f
        withTransform({ rotate(-45f, Offset(w / 2f, w / 2f)) }) {
            val r = w * 0.2f
            drawRoundRect(ink, Offset(w * 0.04f, w / 2f - r), Size(w * 0.58f, r * 2f), CornerRadius(r, r), style = Stroke(sw))
            drawRoundRect(ink, Offset(w * 0.38f, w / 2f - r), Size(w * 0.58f, r * 2f), CornerRadius(r, r), style = Stroke(sw))
        }
    }
}

/** "VPN" in a small outlined pill. */
@Composable
private fun VpnBadge() {
    val ink = LocalInk.current
    Box(
        Modifier.border(1.dp, ink, RoundedCornerShape(4.dp)).padding(horizontal = 3.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("VPN", color = ink, fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 8.sp, maxLines = 1, softWrap = false)
    }
}

/** White "Vo LTE" badge. */
@Composable
private fun VolteBadge() {
    val ink = LocalInk.current
    val inverse = LocalInkInverse.current
    Box(
        Modifier.background(ink, RoundedCornerShape(3.dp)).padding(horizontal = 3.dp, vertical = 1.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Vo", color = inverse, fontSize = 6.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 6.sp, maxLines = 1)
            Text("LTE", color = inverse, fontSize = 6.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 6.sp, maxLines = 1)
        }
    }
}

/** Wi-Fi: the classic fan (dot + three arcs), lit by signal level 0..4 (0-1 = dot only, 4 = dot and all three arcs). */
@Composable
private fun WifiIcon(level: Int, thickness: Float = 0.15f, cap: StrokeCap = StrokeCap.Round) {
    val ink = LocalInk.current
    val dim = ink.copy(alpha = 0.33f)
    Canvas(Modifier.size(width = 15.dp, height = 12.dp)) {
        val w = size.width
        val h = size.height
        val sw = h * thickness
        val c = Offset(w / 2f, h - sw * 0.6f)
        // dot at the bottom centre
        drawCircle(if (level >= 1) ink else dim, sw * 0.85f, c)
        // three arcs, inner to outer; each one lights up at a higher level
        val radii = floatArrayOf(h * 0.42f, h * 0.72f, h * 0.98f - sw)
        for (i in 0..2) {
            val r = radii[i]
            drawArc(
                color = if (level >= i + 2) ink else dim,
                startAngle = 225f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2f, r * 2f),
                style = Stroke(sw, cap = cap)
            )
        }
    }
}

/** Four rounded bars that grow in height; the first [level] are lit. */
@Composable
private fun SignalBars(level: Int, height: androidx.compose.ui.unit.Dp, barWidth: androidx.compose.ui.unit.Dp, gap: androidx.compose.ui.unit.Dp) {
    val ink = LocalInk.current
    val dim = ink.copy(alpha = 0.33f)
    Row(
        Modifier.height(height),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(gap)
    ) {
        for (i in 1..4) {
            Box(
                Modifier.width(barWidth).height(height * (0.35f + 0.2167f * (i - 1)))
                    .background(if (i <= level) ink else dim, RoundedCornerShape(barWidth / 2.2f))
            )
        }
    }
}

/** iPhone battery: pill with the percentage inside; green while charging (with a bolt), yellow in saver, red when low. */
@Composable
private fun BatteryPill(level: Int, charging: Boolean, saver: Boolean) {
    val ink = LocalInk.current
    val inverse = LocalInkInverse.current
    val dim = ink.copy(alpha = 0.35f)
    val fill = when {
        charging -> GREEN
        saver -> SAVER
        level <= 20 -> RED
        else -> ink
    }
    val text = if (fill == ink) inverse else Color.White
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(27.dp).height(13.dp).clip(RoundedCornerShape(4.5.dp)).background(dim)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(level.coerceIn(0, 100) / 100f).background(fill))
            Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
                if (charging) SvgIcon(IcBolt, 8.dp, text)
                Text(
                    level.toString(), color = text, fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold,
                    lineHeight = 10.sp, maxLines = 1, softWrap = false
                )
            }
        }
        Box(Modifier.padding(start = 1.dp).width(2.dp).height(4.5.dp).background(dim, RoundedCornerShape(topEnd = 1.5.dp, bottomEnd = 1.5.dp)))
    }
}

private val IcBolt = listOf<El>(Pa("M13 2L5 14h6l-1 8 8-12h-6z", fill = true))

/* ================= iOS ================= */

@Composable
private fun IosLeft(d: StatusData) {
    val ink = LocalInk.current
    /* ---------- left: clock + notification icons ---------- */
    Text(d.time, color = ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp, maxLines = 1, softWrap = false)
    if (d.showNotif) {
        val icons = NotifStore.statusIcons
        if (icons.isNotEmpty()) {
            Spacer(Modifier.width(6.dp))
            icons.take(3).forEach {
                Image(
                    bitmap = it, contentDescription = null,
                    colorFilter = ColorFilter.tint(ink),
                    modifier = Modifier.padding(horizontal = 2.dp).size(15.dp)
                )
            }
            if (icons.size > 3) Text("···", color = ink, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }

}

@Composable
private fun IosRight(d: StatusData) {
    val ink = LocalInk.current
    /* ---------- right (iPhone order): status icons, SIM signal, Wi-Fi, battery ---------- */
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        if (d.showSpeed) {
            Column(Modifier.widthIn(min = 28.dp), horizontalAlignment = Alignment.End) {
                Text(d.speed, color = ink, fontSize = 9.sp, fontWeight = FontWeight.Bold, lineHeight = 10.sp, maxLines = 1, softWrap = false)
                Text(d.speedUnit, color = ink, fontSize = 8.sp, fontWeight = FontWeight.SemiBold, lineHeight = 9.sp, maxLines = 1, softWrap = false)
            }
        }
        StatusIcons(d)

        // SIM cards: one signal group, or two stacked ones for dual SIM
        if (!d.airplane) SimSignals(d.sims)

        if (d.wifiLevel >= 0) WifiIcon(d.wifiLevel)
        BatteryPill(d.battery, d.charging, d.saver)
    }
}

/** Whatever is switched on: location, alarm, Bluetooth, VPN, hotspot, airplane mode, VoLTE. */
@Composable
private fun StatusIcons(d: StatusData) {
    val ink = LocalInk.current
    run {
        if (d.location) SvgIcon(IcLocation, 12.dp, ink)
        if (d.alarm) AlarmIcon()
        if (d.bluetooth) SvgIcon(IcBluetooth, 13.dp, ink)
        if (d.vpn) VpnBadge()
        if (d.hotspot) HotspotIcon()
        if (d.airplane) AirplaneIcon()
        if (!d.airplane && d.showVolte && d.volte && d.netType.isNotEmpty()) if (d.style == 0) VolteBadge() else HdBadge()

    }
}

/* ================= shared bits of the MIUI and HyperOS bars ================= */

/** Small "HD" badge (MIUI / HyperOS show it while VoLTE is on). */
@Composable
private fun HdBadge() {
    val ink = LocalInk.current
    Box(
        Modifier.border(0.8.dp, ink, RoundedCornerShape(2.5.dp)).padding(horizontal = 2.5.dp, vertical = 0.5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("HD", color = ink, fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 8.sp, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun NotifIcons(max: Int, size: androidx.compose.ui.unit.Dp) {
    val ink = LocalInk.current
    val icons = NotifStore.statusIcons
    if (icons.isEmpty()) return
    Spacer(Modifier.width(5.dp))
    icons.take(max).forEach {
        Image(
            bitmap = it, contentDescription = null, colorFilter = ColorFilter.tint(ink),
            modifier = Modifier.padding(horizontal = 1.5.dp).size(size)
        )
    }
    if (icons.size > max) Text("···", color = ink, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
}

@Composable
private fun SpeedText(d: StatusData, weight: FontWeight, top: androidx.compose.ui.unit.TextUnit, bottom: androidx.compose.ui.unit.TextUnit) {
    val ink = LocalInk.current
    Column(Modifier.widthIn(min = 26.dp), horizontalAlignment = Alignment.End) {
        Text(d.speed, color = ink, fontSize = top, fontWeight = weight, lineHeight = top, maxLines = 1, softWrap = false)
        Text(d.speedUnit, color = ink.copy(alpha = 0.85f), fontSize = bottom, fontWeight = FontWeight.Normal, lineHeight = bottom, maxLines = 1, softWrap = false)
    }
}

/** Fill colour of a battery: green charging, yellow saver, red low, else the ink colour. */
private fun batteryFill(level: Int, charging: Boolean, saver: Boolean, ink: Color) = when {
    charging -> GREEN
    saver -> SAVER
    level <= 20 -> RED
    else -> ink
}

/* ================= MIUI ================= */

@Composable
private fun MiuiLeft(d: StatusData) {
    val ink = LocalInk.current
    Text(d.time, color = ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
    if (d.showNotif) NotifIcons(4, 14.dp)
}

@Composable
private fun MiuiRight(d: StatusData) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (d.showSpeed) SpeedText(d, FontWeight.Medium, 8.5.sp, 7.5.sp)
        StatusIcons(d)
        if (!d.airplane) MiuiSims(d.sims)
        if (d.wifiLevel >= 0) WifiIcon(d.wifiLevel, thickness = 0.2f, cap = StrokeCap.Butt)
        MiuiBattery(d.battery, d.charging, d.saver)
    }
}

/** MIUI signal: the network label sits left of slim stepped bars; dual SIM stacks two small rows. */
@Composable
private fun MiuiSims(sims: List<SimInfo>) {
    val ink = LocalInk.current
    when (sims.size) {
        0 -> {}
        1 -> {
            val s = sims[0]
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(1.5.dp)) {
                if (s.noService) Text("×", color = ink, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                else {
                    if (s.net.isNotEmpty()) Text(s.net, color = ink, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    SignalBars(s.level, 11.dp, 2.5.dp, 1.5.dp)
                }
            }
        }
        else -> Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            sims.take(2).forEach { s ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(1.5.dp)) {
                    SignalBars(if (s.noService) 0 else s.level, 6.dp, 2.dp, 1.dp)
                    Text(if (s.noService) "×" else s.net, color = ink, fontSize = 6.5.sp, fontWeight = FontWeight.Bold, lineHeight = 7.sp, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

/** MIUI battery: thin outlined cell with a fill, and the percentage written to the right of it. */
@Composable
private fun MiuiBattery(level: Int, charging: Boolean, saver: Boolean) {
    val ink = LocalInk.current
    val inverse = LocalInkInverse.current
    val fill = batteryFill(level, charging, saver, ink)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.width(21.dp).height(11.dp).border(1.dp, ink.copy(alpha = 0.75f), RoundedCornerShape(3.dp)).padding(1.5.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(level.coerceIn(0, 100) / 100f).clip(RoundedCornerShape(1.5.dp)).background(fill))
                if (charging) Box(Modifier.align(Alignment.Center)) { SvgIcon(IcBolt, 7.dp, if (fill == ink) inverse else Color.White) }
            }
            Box(Modifier.padding(start = 0.5.dp).width(1.5.dp).height(4.dp).background(ink.copy(alpha = 0.75f), RoundedCornerShape(topEnd = 1.dp, bottomEnd = 1.dp)))
        }
        Text("$level%", color = ink, fontSize = 10.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
    }
}

/* ================= HyperOS ================= */

@Composable
private fun HyperLeft(d: StatusData) {
    val ink = LocalInk.current
    Text(d.time, color = ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.sp, maxLines = 1, softWrap = false)
    if (d.showNotif) NotifIcons(3, 13.dp)
}

@Composable
private fun HyperRight(d: StatusData) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (d.showSpeed) SpeedText(d, FontWeight.SemiBold, 8.sp, 7.sp)
        StatusIcons(d)
        if (!d.airplane) HyperSims(d.sims)
        if (d.wifiLevel >= 0) WifiIcon(d.wifiLevel, thickness = 0.1f, cap = StrokeCap.Round)
        HyperBattery(d.battery, d.charging, d.saver)
    }
}

/** HyperOS signal: four thin upright lines of growing height and a small network label. */
@Composable
private fun LineBars(level: Int, height: androidx.compose.ui.unit.Dp) {
    val ink = LocalInk.current
    val dim = ink.copy(alpha = 0.3f)
    Canvas(Modifier.size(width = height * 1.15f, height = height)) {
        val w = size.width
        val h = size.height
        val sw = w * 0.15f
        for (i in 1..4) {
            val x = w * (0.1f + 0.267f * (i - 1))
            val top = h * (1f - (0.3f + 0.2333f * (i - 1)))
            drawLine(if (i <= level) ink else dim, Offset(x, h - sw / 2f), Offset(x, top + sw / 2f), sw, StrokeCap.Round)
        }
    }
}

@Composable
private fun HyperSims(sims: List<SimInfo>) {
    val ink = LocalInk.current
    when (sims.size) {
        0 -> {}
        1 -> {
            val s = sims[0]
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                if (s.noService) Text("No SIM", color = ink, fontSize = 9.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
                else {
                    LineBars(s.level, 11.dp)
                    if (s.net.isNotEmpty()) Text(s.net, color = ink, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                }
            }
        }
        else -> Column(verticalArrangement = Arrangement.spacedBy(0.5.dp), horizontalAlignment = Alignment.Start) {
            sims.take(2).forEach { s ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    LineBars(if (s.noService) 0 else s.level, 7.dp)
                    Text(if (s.noService) "×" else s.net, color = ink, fontSize = 6.5.sp, fontWeight = FontWeight.SemiBold, lineHeight = 7.sp, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

/** HyperOS battery: a round pill with a thin edge, the fill inside and the number in the middle. */
@Composable
private fun HyperBattery(level: Int, charging: Boolean, saver: Boolean) {
    val ink = LocalInk.current
    val inverse = LocalInkInverse.current
    val fill = batteryFill(level, charging, saver, ink)
    val text = if (fill != ink) Color.White else if (level >= 45) inverse else ink
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.width(26.dp).height(13.dp).border(1.dp, ink.copy(alpha = 0.55f), CircleShape).padding(1.5.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(level.coerceIn(0, 100) / 100f).clip(CircleShape).background(fill))
            Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
                if (charging) SvgIcon(IcBolt, 7.dp, text)
                Text(level.toString(), color = text, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, lineHeight = 9.sp, maxLines = 1, softWrap = false)
            }
        }
        Box(Modifier.padding(start = 1.dp).width(1.5.dp).height(4.dp).background(ink.copy(alpha = 0.55f), CircleShape))
    }
}
