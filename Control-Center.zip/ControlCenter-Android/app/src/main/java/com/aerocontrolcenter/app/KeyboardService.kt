package com.aerocontrolcenter.app

import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * A tiny keyboard that only has to be switched on in the system settings. While it is enabled
 * the system keeps this app's process bound, so the app is not stopped. It is never meant to be
 * used for typing: its only button opens the keyboard picker to go back to the normal keyboard.
 */
class KeyboardService : InputMethodService() {

    override fun onCreateInputView(): View {
        val d = resources.displayMetrics.density
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#1C1C1E"))
            setPadding((16 * d).toInt(), (16 * d).toInt(), (16 * d).toInt(), (16 * d).toInt())
            addView(TextView(context).apply {
                text = "Control Center keeper. Switch to your normal keyboard to type."
                setTextColor(Color.WHITE)
                textSize = 14f
                gravity = Gravity.CENTER
            })
            addView(Button(context).apply {
                text = "Switch keyboard"
                setOnClickListener {
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                }
            })
        }
    }

    companion object {
        fun component(ctx: Context) = ComponentName(ctx, KeyboardService::class.java)

        /** true once the user has switched this keyboard on in the system settings */
        fun isEnabled(ctx: Context): Boolean = try {
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.any { it.packageName == ctx.packageName }
        } catch (_: Exception) {
            false
        }
    }
}
