package com.aerocontrolcenter.app

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.util.concurrent.Executors

/**
 * The one door to AeroHUB (adb-shell level access). Every toggle in the app calls [exec]; the pull-down lock calls
 * [setStatusBarLocked]. Compose can observe [state].
 */
object Shell {

    enum class State { NotRunning, NoPermission, Connecting, Ready }

    var state by mutableStateOf(State.NotRunning)
        private set

    /** True when AeroHUB refuses this app (App access is off or the app was removed there): it must be allowed inside AeroHUB. */
    var deniedForever by mutableStateOf(false)
        private set

    /** True when the AeroHUB app is not installed. */
    var notInstalled by mutableStateOf(false)
        private set

    /** True when the AeroHUB server is too old: open AeroHUB and tap Restart server. */
    var outdated by mutableStateOf(false)
        private set

    val ready: Boolean get() = state == State.Ready

    private const val REQ = 4601
    private lateinit var app: Application
    private val main = Handler(Looper.getMainLooper())
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun token(): String? = app.getSharedPreferences("aerohub", Context.MODE_PRIVATE).getString("token", null)

    fun init(a: Application) {
        app = a
        // AeroHUB can stop at any time (no binder-death signal like before): look again every few seconds
        Thread {
            while (true) {
                try { Thread.sleep(4000) } catch (_: InterruptedException) { return@Thread }
                evaluate()
            }
        }.apply { isDaemon = true; name = "aerohub-poll"; start() }
        evaluate()
    }

    private fun installed(): Boolean = try {
        app.packageManager.getPackageInfo(AeroHub.PKG, 0); true
    } catch (_: Throwable) { false }

    /** Re-checks AeroHUB (installed? running? allowed?). Cheap, call it on resume. */
    fun evaluate() {
        Thread {
            val inst = installed()
            val tk = token()
            val st = if (inst && tk != null) AeroHub.status(tk) else null
            main.post { apply(inst, tk, st) }
        }.start()
    }

    private fun apply(inst: Boolean, tk: String?, st: AeroHub.Status?) {
        notInstalled = !inst
        val was = state
        val code = st?.code ?: -1
        val ver = st?.version ?: 0
        when {
            !inst -> { outdated = false; down(State.NotRunning) }
            tk == null -> { outdated = false; deniedForever = false; down(State.NoPermission) }
            code < 0 -> { outdated = false; down(State.NotRunning) }
            code == 0 -> { outdated = false; deniedForever = true; down(State.NoPermission) }
            ver < AeroHub.MIN_SERVER_VERSION -> { outdated = true; down(State.NotRunning) }
            else -> {
                outdated = false; deniedForever = false
                state = State.Ready
                if (was != State.Ready) onReady()
            }
        }
    }

    private fun down(s: State) {
        if (state == State.Ready) pullWatching = false
        state = s
    }

    /** Opens AeroHUB's permission dialog. The answer comes back through [onActivityResult]. */
    fun requestPermission(ctx: Context) {
        var c: Context? = ctx
        while (c is ContextWrapper && c !is Activity) c = c.baseContext
        val act = c as? Activity ?: return
        try {
            @Suppress("DEPRECATION")
            act.startActivityForResult(Intent(AeroHub.ACTION_REQUEST).setPackage(AeroHub.PKG), REQ)
        } catch (_: Throwable) {
            notInstalled = true
        }
    }

    /** Call from the activity's onActivityResult. */
    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQ) return
        val t = data?.getStringExtra("token")
        if (resultCode == Activity.RESULT_OK && t != null) {
            app.getSharedPreferences("aerohub", Context.MODE_PRIVATE).edit().putString("token", t).apply()
        }
        evaluate()
    }

    fun launchAeroHUBApp(ctx: Context): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(AeroHub.PKG) ?: return false
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    /** Once connected, put back the pull-down lock and the touch watcher the user had switched on. */
    private fun onReady() {
        val p = app.getSharedPreferences("cc", Context.MODE_PRIVATE)
        // split mode never keeps the phone's own pull-down locked: the watcher holds it back only while a finger is on the top edge
        val split = p.getBoolean("split", true)
        if (!split && p.getBoolean("lock_stock", false) && p.getBoolean("overlay_on", false)) {
            io.launch { setStatusBarLocked(true) }
        }
        pullCfg?.let { c -> watchIo.launch { startWatch(c) } }
        // custom status bar: hide the phone's own bar again; when it is off, clear anything left over from an earlier run
        if (p.getBoolean("cs_on", false)) StatusBarService.onAeroHUBReady()
        else io.launch { setStatusBarHidden(false) }
    }

    /* ---------- pull-down touch watcher (reads `getevent` through an AeroHUB stream) ---------- */

    class PullCfg(
        val w: Int, val h: Int, val rotation: Int, val topPx: Int, val dragPx: Int, val side: Int,
        val autoLock: Boolean = false
    )

    // start / stop of the watcher must run one after the other, in the order they were asked for
    private val watchIo = CoroutineScope(SupervisorJob() + Executors.newSingleThreadExecutor().asCoroutineDispatcher())

    @Volatile private var pullCfg: PullCfg? = null
    @Volatile private var pullCb: ((Int) -> Unit)? = null
    @Volatile private var pullWatching = false
    val pulling: Boolean get() = pullWatching

    @Volatile private var watchGen = 0
    @Volatile private var watchStream: Closeable? = null
    @Volatile private var rotation = 0
    @Volatile private var watchLocked = false

    @Volatile private var edgeOn = false
    @Volatile private var edgeMargin = 0
    @Volatile private var edgeDrag = 1
    @Volatile private var navL = 0
    @Volatile private var navR = 0
    @Volatile private var navB = 0
    @Volatile private var edgeCb: (() -> Unit)? = null
    @Volatile private var navCb: (() -> Unit)? = null

    /** Landscape auto-hide: [onEdge] runs (main thread) when a finger starts at a screen edge and moves inward. */
    fun setEdgeReveal(on: Boolean, marginPx: Int, dragPx: Int, onEdge: (() -> Unit)?) {
        edgeCb = if (on) onEdge else null
        edgeMargin = marginPx
        edgeDrag = dragPx.coerceAtLeast(1)
        edgeOn = on
    }

    /** Navigation bar area while a panel is open: [onTap] runs (main thread) when a touch starts inside it. Zeros = off. */
    fun setNavZone(left: Int, right: Int, bottom: Int, onTap: (() -> Unit)?) {
        navCb = if (left > 0 || right > 0 || bottom > 0) onTap else null
        navL = left; navR = right; navB = bottom
    }

    /** Tells AeroHUB the app is alive (it gives the navigation buttons back if the beats stop). */
    fun heartbeat() {
        val tk = token() ?: return
        if (!ready) return
        watchIo.launch { try { AeroHub.beat(tk) } catch (_: Throwable) {} }
    }

    /** Hides / shows the status bar content and the navigation buttons of the phone. */
    suspend fun setSystemBars(statusHidden: Boolean, navHidden: Boolean): Boolean = withContext(Dispatchers.IO) {
        val oldBar = barHidden
        val oldNav = this@Shell.navHidden
        barHidden = statusHidden
        this@Shell.navHidden = navHidden
        val ok = applyDisable()
        if (!ok) {
            barHidden = oldBar
            this@Shell.navHidden = oldNav
        }
        ok
    }

    private class Touch(val path: String, val maxX: Int, val maxY: Int)

    private val WS = Regex("\\s+")
    private val PATH_OK = Regex("[A-Za-z0-9/_.-]+")

    /** Finds the touch screen with `getevent -pl` (the device with multi-touch X/Y axes and INPUT_PROP_DIRECT). */
    private fun findTouch(tk: String): Touch? {
        val out = try { AeroHub.exec(tk, "getevent -pl").second } catch (_: Throwable) { return null }
        val maxRe = Regex("max\\s+(-?\\d+)")
        var best: Touch? = null
        var bestDirect = false
        var path: String? = null
        var mx = 0
        var my = 0
        var direct = false
        fun flush() {
            val pth = path ?: return
            if (mx <= 0 || my <= 0 || !PATH_OK.matches(pth)) return
            val cand = Touch(pth, mx, my)
            val b = best
            val better = b == null ||
                (direct && !bestDirect) ||
                (direct == bestDirect && mx.toLong() * my > b.maxX.toLong() * b.maxY)
            if (better) {
                best = cand
                bestDirect = direct
            }
        }
        for (raw in out.lineSequence()) {
            val t = raw.trim()
            if (t.startsWith("add device")) {
                flush()
                path = t.substringAfter(':', "").trim().ifEmpty { null }
                mx = 0; my = 0; direct = false
            } else if (t.contains("ABS_MT_POSITION_X")) {
                mx = maxRe.find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            } else if (t.contains("ABS_MT_POSITION_Y")) {
                my = maxRe.find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            } else if (t.contains("INPUT_PROP_DIRECT")) {
                direct = true
            }
        }
        flush()
        return best
    }

    private fun startWatch(c: PullCfg) {
        stopWatch()
        val tk = token() ?: return
        val touch = findTouch(tk) ?: return
        rotation = c.rotation
        val gen = ++watchGen
        val wt = Watcher(touch, c.w, c.h, c.topPx, c.dragPx, c.side, c.autoLock)
        pullWatching = true
        Thread {
            try {
                AeroHub.stream(tk, "exec getevent -l ${touch.path}", { watchStream = it }) { line -> gen == watchGen && wt.feed(line) }
            } catch (_: Throwable) {
            } finally {
                // the stream ended by itself (not by stopWatch): never leave the phone's pull-down locked
                if (gen == watchGen) {
                    releaseWatchLock()
                    pullWatching = false
                }
            }
        }.apply { isDaemon = true; name = "pull-watch"; start() }
    }

    private fun stopWatch() {
        watchGen++
        try { watchStream?.close() } catch (_: Throwable) {}
        watchStream = null
        pullWatching = false
        releaseWatchLock()
    }

    /** Gives the phone's own pull-down back if (and only if) the touch watcher was the one holding it. */
    private fun releaseWatchLock() {
        if (watchLocked) {
            watchLocked = false
            expandLocked = false
            applyDisable()
        }
    }

    /** Starts watching for the swipe-down gesture. Safe to call before AeroHUB is ready: it starts when it connects. */
    fun watchPull(cfg: PullCfg, onPull: (Int) -> Unit) {
        pullCfg = cfg
        pullCb = onPull
        if (ready) watchIo.launch { startWatch(cfg) }
    }

    fun setPullRotation(r: Int) {
        val c = pullCfg ?: return
        pullCfg = PullCfg(c.w, c.h, r, c.topPx, c.dragPx, c.side, c.autoLock)
        rotation = r
    }

    fun unwatchPull() {
        pullCfg = null
        pullCb = null
        watchIo.launch { stopWatch() }
    }

    /** Reads one finger-touch stream line by line and calls back when a pull-down, an edge swipe or a navigation tap is seen. */
    private class Watcher(
        val touch: Touch, val w: Int, val h: Int, val topPx: Int, val dragPx: Int, val side: Int, val autoLock: Boolean
    ) {
        private val n = 10
        private val trackId = LongArray(n) { -1L }       // -1 = finger up
        private val rawX = FloatArray(n) { -1f }
        private val rawY = FloatArray(n) { -1f }
        private val fresh = BooleanArray(n)
        private val armed = BooleanArray(n)
        private val armHalf = IntArray(n)                 // 1 = the finger started on the left half, 2 = on the right half
        private val fired = BooleanArray(n)
        private val lockArm = BooleanArray(n)             // started in a slightly larger area: the phone's own pull-down is held back
        private var reassert = false
        private val startX = FloatArray(n)
        private val startY = FloatArray(n)
        private val edgeArm = BooleanArray(n)
        private val edgeDone = BooleanArray(n)
        private var edgeHit = false
        private var navHit = false
        private var slot = 0

        private fun reset(i: Int) {
            trackId[i] = -1L; rawX[i] = -1f; rawY[i] = -1f
            fresh[i] = false; armed[i] = false; fired[i] = false; armHalf[i] = 0; lockArm[i] = false
            edgeArm[i] = false; edgeDone[i] = false
        }

        /** Returns 0 = nothing, otherwise the half (1 left, 2 right) where the pull-down started. */
        private fun evaluate(i: Int): Int {
            if (trackId[i] < 0 || rawX[i] < 0 || rawY[i] < 0) return 0
            val px = rawX[i] / touch.maxX * w
            val py = rawY[i] / touch.maxY * h
            val sx: Float
            val sy: Float
            val sw: Float
            val sh: Float
            when (rotation) {
                1 -> { sx = py; sy = w - px; sw = h.toFloat(); sh = w.toFloat() }
                2 -> { sx = w - px; sy = h - py; sw = w.toFloat(); sh = h.toFloat() }
                3 -> { sx = h - py; sy = px; sw = h.toFloat(); sh = w.toFloat() }
                else -> { sx = px; sy = py; sw = w.toFloat(); sh = h.toFloat() }
            }
            if (!fresh[i] && edgeOn && edgeArm[i] && !edgeDone[i]) {
                val ddx = sx - startX[i]
                val ddy = sy - startY[i]
                val drag = edgeDrag.toFloat()
                if (ddx * ddx + ddy * ddy >= drag * drag) {
                    edgeDone[i] = true
                    edgeHit = true
                }
            }
            if (fresh[i]) {
                fresh[i] = false
                startX[i] = sx
                startY[i] = sy
                val m = edgeMargin
                edgeArm[i] = edgeOn && (sx <= m || sx >= sw - m || sy <= m || sy >= sh - m)
                if ((navL > 0 || navR > 0 || navB > 0) && (sx < navL || sx > sw - navR || sy > sh - navB)) navHit = true
                val inSide = when (side) { 1 -> sx < sw / 2f; 2 -> sx >= sw / 2f; else -> true }
                armed[i] = sy <= topPx && inSide
                // the phone's own panel reacts a little lower than our trigger: hold it back for that zone too
                lockArm[i] = sy <= topPx * 1.6f && inSide
                if (lockArm[i]) reassert = true
                armHalf[i] = if (sx < sw / 2f) 1 else 2
                return 0
            }
            if (armed[i] && !fired[i]) {
                val dy = sy - startY[i]
                val dx = Math.abs(sx - startX[i])
                if (dy >= dragPx && dy > dx) {
                    fired[i] = true
                    return armHalf[i]
                }
            }
            return 0
        }

        /*
         * Split mode: while a finger that started in the trigger area is down, the phone's own pull-down is
         * locked, so only this Control Center reacts to that swipe. As soon as the finger is up it is released again.
         */
        private fun applyLock() {
            if (!autoLock) return
            var want = false
            for (i in 0 until n) if ((armed[i] || lockArm[i]) && trackId[i] >= 0) { want = true; break }
            if (want != watchLocked || (want && reassert)) {
                watchLocked = want
                expandLocked = want
                applyDisable()
            }
            reassert = false
        }

        /** Returns false to stop reading. */
        fun feed(line: String): Boolean {
            val tok = line.trim().split(WS)
            val k = tok.indexOfFirst { it.startsWith("EV_") }
            if (k < 0 || tok.size < k + 3) return true
            val type = tok[k]
            val code = tok[k + 1]
            val value = tok[k + 2]
            when (type) {
                "EV_ABS" -> when (code) {
                    "ABS_MT_SLOT" -> slot = (value.toIntOrNull(16) ?: 0).coerceIn(0, n - 1)
                    "ABS_MT_TRACKING_ID" -> {
                        val id = value.toLongOrNull(16) ?: -1L
                        if (id == 0xFFFFFFFFL) reset(slot)
                        else if (id != trackId[slot]) {
                            reset(slot)
                            trackId[slot] = id
                            fresh[slot] = true
                        }
                    }
                    "ABS_MT_POSITION_X" -> rawX[slot] = (value.toLongOrNull(16) ?: -1L).toFloat()
                    "ABS_MT_POSITION_Y" -> rawY[slot] = (value.toLongOrNull(16) ?: -1L).toFloat()
                }
                "EV_KEY" -> if (code == "BTN_TOUCH" && value == "UP") for (i in 0 until n) reset(i)
                "EV_SYN" -> if (code == "SYN_REPORT") {
                    var hit = 0
                    for (i in 0 until n) {
                        val r = evaluate(i)
                        if (r != 0) hit = r
                    }
                    applyLock()
                    if (edgeHit) {
                        edgeHit = false
                        main.post { edgeCb?.invoke() }
                    }
                    if (navHit) {
                        navHit = false
                        main.post { navCb?.invoke() }
                    }
                    if (hit != 0) main.post { pullCb?.invoke(hit) }
                }
            }
            return true
        }
    }

    /* ---------- running commands ---------- */

    /** Runs a shell command as the shell user. Returns exit code and output. */
    suspend fun exec(cmd: String): Pair<Int, String> = withContext(Dispatchers.IO) {
        val tk = token() ?: return@withContext -1 to "AeroHUB not ready"
        if (state != State.Ready) return@withContext -1 to "AeroHUB not ready"
        try {
            AeroHub.exec(tk, cmd)
        } catch (t: Throwable) {
            // AeroHUB stopped or refused this app: look again right away
            main.post { evaluate() }
            -1 to (t.message ?: "error")
        }
    }

    /*
     * The status bar "disable" flags are sent together, so the pull-down lock, the hidden bar and the hidden
     * navigation buttons are kept as three booleans.
     */
    @Volatile private var expandLocked = false
    @Volatile private var barHidden = false
    @Volatile private var navHidden = false

    @Synchronized
    private fun applyDisable(): Boolean {
        val tk = token() ?: return false
        // DISABLE_EXPAND 0x10000; hidden bar: notification icons 0x20000, system info 0x100000, clock 0x800000;
        // navigation buttons: home 0x200000, back 0x400000, recents 0x1000000
        val what = (if (expandLocked) 0x00010000 else 0) or
            (if (barHidden) (0x00020000 or 0x00100000 or 0x00800000) else 0) or
            (if (navHidden) (0x00200000 or 0x00400000 or 0x01000000) else 0)
        // DISABLE2_QUICK_SETTINGS = 1, DISABLE2_NOTIFICATION_SHADE = 4
        val what2 = if (expandLocked) (1 or 4) else 0
        return try { AeroHub.statusFlags(tk, what, what2) } catch (_: Throwable) { false }
    }

    /** Locks / unlocks the phone's own notification panel and quick settings. */
    suspend fun setStatusBarLocked(locked: Boolean): Boolean = withContext(Dispatchers.IO) {
        expandLocked = locked
        applyDisable()
    }

    /** Hides / shows the clock and icons of the phone's own status bar (the custom status bar is drawn instead). */
    suspend fun setStatusBarHidden(hidden: Boolean): Boolean = setSystemBars(hidden, false)

    /** Median brightness 0..255 of the top [rows] pixel rows of the screen, or -1 when it could not be read. */
    suspend fun barLuma(rows: Int): Int = withContext(Dispatchers.IO) {
        val tk = token() ?: return@withContext -1
        if (state != State.Ready) return@withContext -1
        try {
            // AeroHUB returns at most 512 KB, so only the start of the raw screenshot is taken
            val (code, px0) = AeroHub.execBytes(tk, "screencap | head -c 500000")
            if (code != 0) return@withContext -1
            val hdrLen = if (android.os.Build.VERSION.SDK_INT >= 29) 16 else 12
            if (px0.size <= hdrLen) return@withContext -1
            val bb = java.nio.ByteBuffer.wrap(px0, 0, hdrLen).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            val w = bb.getInt(0)
            val fmt = bb.getInt(8)
            if (w <= 0 || w > 10_000) return@withContext -1
            val bpp = when (fmt) {
                1, 2, 5, 43 -> 4      // RGBA_8888, RGBX_8888, BGRA_8888, RGBA_1010102
                22 -> 8               // RGBA_FP16
                3 -> 3                // RGB_888
                4 -> 2                // RGB_565
                else -> return@withContext -1
            }
            val avail = (px0.size - hdrLen) / (w * bpp)
            val useRows = minOf(rows.coerceIn(1, 400), avail)
            if (useRows < 1) return@withContext -1
            val px = px0
            val base = hdrLen
            val total = w * useRows * bpp
            val hist = IntArray(256)
            var count = 0
            var i = 0
            val step = bpp * 3   // every third pixel is enough
            while (i + bpp <= total) {
                val o = base + i
                val r: Int
                val g: Int
                val b: Int
                when (fmt) {
                    1, 2 -> { r = px[o].toInt() and 0xFF; g = px[o + 1].toInt() and 0xFF; b = px[o + 2].toInt() and 0xFF }
                    5 -> { b = px[o].toInt() and 0xFF; g = px[o + 1].toInt() and 0xFF; r = px[o + 2].toInt() and 0xFF }
                    3 -> { r = px[o].toInt() and 0xFF; g = px[o + 1].toInt() and 0xFF; b = px[o + 2].toInt() and 0xFF }
                    4 -> {
                        val v = (px[o].toInt() and 0xFF) or ((px[o + 1].toInt() and 0xFF) shl 8)
                        r = ((v shr 11) and 0x1F) * 255 / 31
                        g = ((v shr 5) and 0x3F) * 255 / 63
                        b = (v and 0x1F) * 255 / 31
                    }
                    43 -> {
                        val v = (px[o].toInt() and 0xFF) or ((px[o + 1].toInt() and 0xFF) shl 8) or
                            ((px[o + 2].toInt() and 0xFF) shl 16) or ((px[o + 3].toInt() and 0xFF) shl 24)
                        r = (v and 0x3FF) shr 2
                        g = ((v shr 10) and 0x3FF) shr 2
                        b = ((v shr 20) and 0x3FF) shr 2
                    }
                    else -> { r = half(px, o); g = half(px, o + 2); b = half(px, o + 4) }
                }
                hist[((r * 299 + g * 587 + b * 114) / 1000).coerceIn(0, 255)]++
                count++
                i += step
            }
            if (count == 0) return@withContext -1
            var acc = 0
            for (v in 0..255) {
                acc += hist[v]
                if (acc * 2 >= count) return@withContext v
            }
            -1
        } catch (_: Throwable) {
            -1
        }
    }

    /** One IEEE half float (little endian) to a 0..255 sRGB-ish value. */
    private fun half(b: ByteArray, o: Int): Int {
        val h = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
        val exp = (h shr 10) and 0x1F
        val man = h and 0x3FF
        val lin = when {
            (h and 0x8000) != 0 -> 0f
            exp == 0 -> man / 1024f * 6.1035156e-5f
            exp == 31 -> 1f
            else -> (1f + man / 1024f) * Math.pow(2.0, (exp - 15).toDouble()).toFloat()
        }.coerceIn(0f, 1f)
        return (Math.pow(lin.toDouble(), 1.0 / 2.2) * 255.0).toInt().coerceIn(0, 255)
    }
}
