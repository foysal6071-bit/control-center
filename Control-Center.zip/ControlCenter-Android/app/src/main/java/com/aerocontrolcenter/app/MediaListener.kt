package com.aerocontrolcenter.app

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap

/**
 * "Notification access". It does two things:
 *  - Android hands the app the active media sessions, so the Now Playing tile can show and control the music
 *    of any app (YouTube, Spotify, ...).
 *  - The notifications are shown in this app's own notification panel (pull down on the left half). They are
 *    only held in memory while the phone runs; nothing is saved or sent anywhere.
 * While it is bound, Android also keeps the app process alive, and the pull-down trigger is put back if it
 * was stopped.
 */
class MediaListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        NotifStore.refresh(this)
        val p = getSharedPreferences("cc", Context.MODE_PRIVATE)
        if (p.getBoolean("overlay_on", false) && !OverlayService.running && Settings.canDrawOverlays(this)) {
            try {
                OverlayService.start(this)
            } catch (_: Exception) {
            }
        }
        if (p.getBoolean("cs_on", false) && !StatusBarService.running && Settings.canDrawOverlays(this)) {
            try {
                StatusBarService.start(this)
            } catch (_: Exception) {
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance === this) instance = null
        NotifStore.clear()
        // the system can drop the listener (low memory, app update): ask for it back, otherwise notifications stay empty
        try {
            if (hasAccess(this)) NotificationListenerService.requestRebind(component(this))
        } catch (_: Throwable) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        NotifStore.refresh(this)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        NotifStore.refresh(this)
    }

    companion object {
        @Volatile
        var instance: MediaListener? = null
            private set

        fun component(ctx: Context) = ComponentName(ctx, MediaListener::class.java)

        fun hasAccess(ctx: Context): Boolean = try {
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        } catch (_: Exception) {
            false
        }

        /** Reads the notifications again (after a setting changed or the panel opened). */
        fun refreshNow() {
            instance?.let { NotifStore.refresh(it) }
        }
    }
}

/**
 * One notification button. When [inputs] is not null it is a "reply" style action (a text box):
 * Wireless debugging "Enter pairing code" (system Settings, Shizuku), chat replies, ...
 */
class NotifAction(
    val title: String,
    val intent: PendingIntent,
    val inputs: Array<RemoteInput>? = null,
    val inputLabel: String = ""
)

class NotifItem(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val ongoing: Boolean,
    val clearable: Boolean,
    val autoCancel: Boolean,
    val icon: ImageBitmap?,
    val content: PendingIntent?,
    val actions: List<NotifAction>
)

/** The notifications shown in the notification panel. Compose reads [items]; only the listener writes it. */
object NotifStore {

    var items by mutableStateOf<List<NotifItem>>(emptyList())
        private set

    private val icons = HashMap<String, ImageBitmap?>()

    /** An app whose notifications are muted for a while (like "Mute for 1 hour" in HyperOS). */
    class Snoozed(val pkg: String, val app: String, val until: Long)

    /** Muted apps, for the "resume" row in the panel. */
    var snoozed by mutableStateOf<List<Snoozed>>(emptyList())
        private set

    private fun readSnooze(ctx: Context): LinkedHashMap<String, Long> {
        val out = LinkedHashMap<String, Long>()
        val now = System.currentTimeMillis()
        val raw = ctx.getSharedPreferences("cc", Context.MODE_PRIVATE).getString("n_snooze", "").orEmpty()
        for (part in raw.split(',')) {
            val i = part.lastIndexOf('|')
            if (i <= 0) continue
            val until = part.substring(i + 1).toLongOrNull() ?: continue
            if (until > now) out[part.substring(0, i)] = until
        }
        return out
    }

    private fun writeSnooze(ctx: Context, m: Map<String, Long>) {
        ctx.getSharedPreferences("cc", Context.MODE_PRIVATE).edit()
            .putString("n_snooze", m.entries.joinToString(",") { it.key + "|" + it.value }).apply()
    }

    /** Hides the notifications of [pkg] (panel and status bar) for [ms] milliseconds. */
    fun snooze(ctx: Context, pkg: String, ms: Long) {
        val m = readSnooze(ctx)
        m[pkg] = System.currentTimeMillis() + ms
        writeSnooze(ctx, m)
        // refresh again when the time is over, so the notifications come back without waiting for a new one
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ MediaListener.refreshNow() }, ms + 500)
        MediaListener.refreshNow()
    }

    fun resume(ctx: Context, pkg: String) {
        val m = readSnooze(ctx)
        m.remove(pkg)
        writeSnooze(ctx, m)
        MediaListener.refreshNow()
    }

    /** Small silhouettes of the apps that have a notification (newest first) for the custom status bar. */
    var statusIcons by mutableStateOf<List<ImageBitmap>>(emptyList())
        private set

    fun clear() {
        items = emptyList()
        statusIcons = emptyList()
    }

    private fun iconFor(ctx: Context, pkg: String): ImageBitmap? {
        if (icons.containsKey(pkg)) return icons[pkg]
        val b = try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (_: Throwable) {
            null
        }
        icons[pkg] = b
        return b
    }

    /**
     * The status bar paints every icon in one colour (tint), so only its shape (the alpha) counts. Some apps ship a
     * small icon that is a solid coloured square: tinted, that turns into a white box. For those, the glyph is cut out
     * by its difference from the background colour; if that does not give a sensible shape, a small dot is used.
     */
    private fun silhouette(src: android.graphics.Bitmap): android.graphics.Bitmap {
        val w = src.width
        val h = src.height
        if (w < 4 || h < 4) return src
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var opaque = 0
        for (c in px) if ((c ushr 24) > 200) opaque++
        if (opaque / (w * h).toFloat() < 0.8f) return src   // normal icon: transparent around the shape
        var r = 0L; var g = 0L; var b = 0L; var n = 0
        fun add(c: Int) { r += android.graphics.Color.red(c); g += android.graphics.Color.green(c); b += android.graphics.Color.blue(c); n++ }
        for (x in 0 until w) { add(px[x]); add(px[(h - 1) * w + x]) }
        for (y in 1 until h - 1) { add(px[y * w]); add(px[y * w + w - 1]) }
        val br = (r / n).toInt(); val bg = (g / n).toInt(); val bb = (b / n).toInt()
        val out = IntArray(w * h)
        var glyph = 0
        for (i in px.indices) {
            val c = px[i]
            val d = Math.abs(android.graphics.Color.red(c) - br) + Math.abs(android.graphics.Color.green(c) - bg) +
                Math.abs(android.graphics.Color.blue(c) - bb)
            val a = ((d * 255) / 150).coerceIn(0, 255) * (c ushr 24) / 255
            out[i] = (a shl 24) or 0x00FFFFFF
            if (a > 128) glyph++
        }
        val frac = glyph / (w * h).toFloat()
        val res = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
        if (frac in 0.03f..0.65f) {
            res.setPixels(out, 0, w, 0, 0, w, h)
        } else {
            val cv = android.graphics.Canvas(res)
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE }
            cv.drawCircle(w / 2f, h / 2f, w * 0.3f, paint)
        }
        return res
    }

    private val labels = HashMap<String, String>()

    /** App name for a notification. Cached: refresh() runs on every notification change and used to ask PackageManager each time. */
    private fun labelFor(ctx: Context, pkg: String): String = labels.getOrPut(pkg) {
        try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Throwable) {
            pkg.substringAfterLast('.')
        }
    }

    fun refresh(s: NotificationListenerService) {
        val prefs = s.getSharedPreferences("cc", Context.MODE_PRIVATE)
        val showOngoing = prefs.getBoolean("n_ongoing", true)
        val showMedia = prefs.getBoolean("n_media", false)
        val arr: Array<StatusBarNotification> = try {
            s.activeNotifications ?: emptyArray()
        } catch (_: Throwable) {
            return
        }
        val muted = readSnooze(s)
        snoozed = muted.map { Snoozed(it.key, labelFor(s, it.key), it.value) }
        val out = ArrayList<NotifItem>()
        // only notifications that the panel really lists may get an icon in the status bar
        val shown = HashSet<String>()
        for (sbn in arr) {
            try {
                val n = sbn.notification ?: continue
                if (sbn.packageName == s.packageName) continue
                if (muted.containsKey(sbn.packageName)) continue
                if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
                val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
                if (ongoing && !showOngoing) continue
                val ex = n.extras
                if (!showMedia && ex.containsKey(Notification.EXTRA_MEDIA_SESSION)) continue
                val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
                    ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: ex.getCharSequence(Notification.EXTRA_SUB_TEXT))?.toString().orEmpty()
                if (title.isBlank() && text.isBlank()) continue
                // plain buttons (max 2) plus text-input actions. The text-input action (pairing code, reply) always
                // gets a place, it used to be dropped, which is why the pairing code could not be typed here.
                val plain = ArrayList<NotifAction>()
                var typed: NotifAction? = null
                n.actions?.forEach { a ->
                    val pi = a.actionIntent ?: return@forEach
                    val ri = a.remoteInputs
                    if (ri != null && ri.isNotEmpty()) {
                        if (typed == null) {
                            val label = ri.firstOrNull { it.label != null }?.label?.toString().orEmpty()
                            typed = NotifAction(a.title?.toString().orEmpty(), pi, ri, label)
                        }
                    } else if (plain.size < 2) {
                        plain.add(NotifAction(a.title?.toString().orEmpty(), pi))
                    }
                }
                val acts = ArrayList<NotifAction>()
                typed?.let { acts.add(it) }
                acts.addAll(plain.take(if (typed != null) 1 else 2))
                shown.add(sbn.key)
                out.add(
                    NotifItem(
                        key = sbn.key,
                        pkg = sbn.packageName,
                        app = labelFor(s, sbn.packageName),
                        title = title,
                        text = text,
                        time = sbn.postTime,
                        ongoing = ongoing,
                        clearable = sbn.isClearable,
                        autoCancel = (n.flags and Notification.FLAG_AUTO_CANCEL) != 0,
                        icon = iconFor(s, sbn.packageName),
                        content = n.contentIntent,
                        actions = acts
                    )
                )
            } catch (_: Throwable) {
            }
        }
        // ongoing ones (timers, recorders, calls) first, then newest first
        out.sortWith(compareByDescending<NotifItem> { it.ongoing }.thenByDescending { it.time })
        items = out

        // one small icon per app for the custom status bar
        val small = LinkedHashMap<String, ImageBitmap>()
        for (sbn in arr.sortedByDescending { it.postTime }) {
            try {
                val n = sbn.notification ?: continue
                if (sbn.key !in shown) continue
                if (small.containsKey(sbn.packageName)) continue
                val d = n.smallIcon?.loadDrawable(s) ?: continue
                small[sbn.packageName] = silhouette(d.toBitmap(64, 64)).asImageBitmap()
                if (small.size >= 6) break
            } catch (_: Throwable) {
            }
        }
        statusIcons = small.values.toList()
    }
}
