package com.aerocontrolcenter.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aerocontrolcenter.app.ui.ControlCenterApp
import com.aerocontrolcenter.app.ui.SettingsScreen

/**
 * Opening the app shows all settings (the home screen). The Control Center itself is one tap
 * away and can also be pulled down over any app once the overlay is switched on.
 */
class MainActivity : ComponentActivity() {

    private var showControlCenter by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            if (showControlCenter) {
                BackHandler { showControlCenter = false }
                ControlCenterApp(onOpenSettings = { showControlCenter = false })
            } else {
                SettingsScreen(onOpenControlCenter = { showControlCenter = true })
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Shell.onActivityResult(requestCode, resultCode, data)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // the pull-down panel's Edit button and the notification both want the settings
        if (intent.getBooleanExtra(EXTRA_SETTINGS, false)) showControlCenter = false
    }

    companion object {
        const val EXTRA_SETTINGS = "open_settings"
    }
}
