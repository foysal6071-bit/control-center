package com.aerocontrolcenter.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Keeps the app running around the clock. Four layers work together:
 *  1. the foreground services are START_STICKY, so the system restarts them after it kills them;
 *  2. swiping the app away from Recents schedules a restart a moment later ([restartSoon]);
 *  3. a periodic job (every 15 minutes, survives reboot) starts any service that should be on but is not;
 *  4. the boot receiver starts them after a reboot or an update.
 * What should be on is read from the user's own switches, so a service the user turned off is never brought back.
 */
object KeepAlive {
    private const val JOB_ID = 7301

    /** Starts every service whose switch is on and that is not running. Safe to call at any time. */
    fun ensureRunning(c: Context) {
        val p = c.getSharedPreferences("cc", Context.MODE_PRIVATE)
        if (!Settings.canDrawOverlays(c)) return
        if (p.getBoolean("overlay_on", false) && !OverlayService.running) {
            try { OverlayService.start(c) } catch (_: Throwable) {}
        }
        if (p.getBoolean("cs_on", false) && !StatusBarService.running) {
            try { StatusBarService.start(c) } catch (_: Throwable) {}
        }
        if (p.getBoolean("isl_on", false) && !IslandService.running) {
            IslandService.start(c)
        }
    }

    /** The periodic safety net. Calling it again just keeps the same job. */
    fun schedule(c: Context) {
        try {
            val js = c.getSystemService(JobScheduler::class.java) ?: return
            if (js.getPendingJob(JOB_ID) != null) return
            val job = JobInfo.Builder(JOB_ID, ComponentName(c, KeepAliveJob::class.java))
                .setPeriodic(15 * 60 * 1000L)
                .setPersisted(true)
                .build()
            js.schedule(job)
        } catch (_: Throwable) {
        }
    }

    /** Called when the app is swiped away: start the services again in about a second. */
    fun restartSoon(c: Context) {
        try {
            val am = c.getSystemService(AlarmManager::class.java) ?: return
            val pi = PendingIntent.getBroadcast(
                c, 7302, Intent(c, KeepAliveReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 1500L, pi)
        } catch (_: Throwable) {
        }
    }
}

class KeepAliveJob : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        KeepAlive.ensureRunning(applicationContext)
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}

class KeepAliveReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        KeepAlive.ensureRunning(c)
    }
}
