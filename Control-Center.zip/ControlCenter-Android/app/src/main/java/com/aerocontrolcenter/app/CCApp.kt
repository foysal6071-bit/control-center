package com.aerocontrolcenter.app

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.os.LocaleList
import java.util.Locale

class CCApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // The whole app is English, whatever language the phone is set to (text, dates, digits).
        Locale.setDefault(Locale.ENGLISH)
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                val lm = getSystemService(android.app.LocaleManager::class.java)
                if (lm != null && lm.applicationLocales.toLanguageTags() != "en") {
                    lm.applicationLocales = LocaleList.forLanguageTags("en")
                }
            } catch (_: Throwable) {
            }
        }
        Shell.init(this)
        KeepAlive.schedule(this)
        watchScreen()
    }

    /**
     * Screen off and on again: bring back whatever the phone stopped while it slept (the services and
     * the touch watcher). Done a few times, because the phone is slow to give the network and background apps back.
     */
    private fun watchScreen() {
        val h = Handler(Looper.getMainLooper())
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i?.action == Intent.ACTION_SCREEN_OFF) return
                for (d in longArrayOf(0L, 1500L, 5000L)) {
                    h.postDelayed({
                        KeepAlive.ensureRunning(applicationContext)
                        Shell.onScreenOn()
                    }, d)
                }
            }
        }
        try {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            androidx.core.content.ContextCompat.registerReceiver(this, r, f, androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (_: Throwable) {
        }
    }
}
