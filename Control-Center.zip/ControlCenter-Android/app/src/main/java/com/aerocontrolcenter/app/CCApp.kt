package com.aerocontrolcenter.app

import android.app.Application
import android.os.Build
import android.os.LocaleList
import java.util.Locale

class CCApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // The whole app is English, whatever language the phone is set to (text, dates, digits).
        Locale.setDefault(Locale.ENGLISH)
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                val lm = getSystemService(android.app.LocaleManager::class.java)
                if (lm != null && lm.applicationLocales.toLanguageTags() != "en") {
                    lm.applicationLocales = LocaleList.forLanguageTags("en")
                }
            } catch (_: Throwable) {
            }
        }
        Shell.init(this)
        KeepAlive.schedule(this)
    }
}
