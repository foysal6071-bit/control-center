package com.aerocontrolcenter.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * A Dynamic Island that only floats: a black pill at the top of the screen. It does nothing, takes no
 * touches (taps go straight through to the app below) and shows no content. Size and position are
 * adjusted in the settings and applied live.
 */
class IslandService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private var pill: PillView? = null

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != null && key.startsWith("isl_")) apply()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("cc", Context.MODE_PRIVATE)
        startInForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val v = PillView(this)
        pill = v
        try {
            wm.addView(v, params())
        } catch (_: Exception) {
            pill = null
            stopSelf()
            return
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        apply()
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("cc_island", "Dynamic Island", NotificationManager.IMPORTANCE_MIN))
        }
        val open = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_SETTINGS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, "cc_island")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Dynamic Island is on")
            .setContentText("Tap for settings")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 3, n, type)
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun params(): WindowManager.LayoutParams {
        val w = prefs.getInt("isl_w", DEF_W)
        val h = prefs.getInt("isl_h", DEF_H)
        val y = prefs.getInt("isl_y", DEF_Y)
        val x = prefs.getInt("isl_x", DEF_X)
        return WindowManager.LayoutParams(
            dp(w.toFloat()), dp(h.toFloat()),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            this.x = dp(x.toFloat())
            this.y = dp(y.toFloat())
            title = "AeroIsland"
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
    }

    /** Settings changed (or the phone was rotated): size, position and visibility are set again. */
    private fun apply() {
        val v = pill ?: return
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        v.visibility = if (land && prefs.getBoolean("isl_hide_land", true)) View.GONE else View.VISIBLE
        v.shine = prefs.getBoolean("isl_lens", true)
        v.invalidate()
        try { wm.updateViewLayout(v, params()) } catch (_: Exception) {}
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        apply()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        try { prefs.unregisterOnSharedPreferenceChangeListener(listener) } catch (_: Exception) {}
        pill?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        pill = null
        super.onDestroy()
    }

    /** Pure AMOLED black pill: every part is #000000 so no grey or faded look is left (the lens dot cannot be seen). */
    private class PillView(ctx: Context) : View(ctx) {
        var shine = true
        private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 0, 0); alpha = 255 }
        private val lens = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 0, 0); alpha = 255 }
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            r.set(0f, 0f, w, h)
            c.drawRoundRect(r, h / 2f, h / 2f, body)
            if (shine) {
                val d = h * 0.36f
                val cx = w - h * 0.5f - h * 0.18f
                c.drawCircle(cx, h / 2f, d / 2f, lens)
            }
        }
    }

    companion object {
        const val DEF_W = 120
        const val DEF_H = 34
        const val DEF_Y = 10
        const val DEF_X = 0

        @Volatile
        var running = false
            private set

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, IslandService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, IslandService::class.java))
        }
    }
}
