# Aero Control Center (Kotlin + Jetpack Compose)

iOS-style Control Center as a native Android app. This is the Kotlin / Jetpack Compose
version of the web project `control-center`. The same 214 x 465 unit layout, the same
colours and the same SVG icon paths are used, but the controls now talk to real Android APIs.

## English

1. Create a repository and upload every file (including the hidden `.github` folder).
2. Push to `main`. The *Build APK* workflow runs `gradle assembleDebug`.
3. Open the run, download the **control-center-apk** artifact, unzip and install `app-debug.apk`.
4. Push a tag like `v1.0` to also publish the APK under **Releases**.

Local build: open the folder in Android Studio (Koala or newer) and press Run.

## AeroHUB (v2)

All toggles now run through **AeroHUB** (adb-shell level privileges). Without AeroHUB the app falls back to opening the matching system screen, as before.

| Control | With AeroHUB |
| --- | --- |
| Airplane | `cmd connectivity airplane-mode enable/disable` |
| Wi-Fi | `svc wifi enable/disable` |
| Mobile data | `svc data enable/disable` |
| Bluetooth | `cmd bluetooth_manager enable/disable` (fallback `svc bluetooth`) |
| Hotspot | `cmd connectivity start-tethering wifi` (ROM dependent, falls back to the tethering screen) |
| Focus | real Do Not Disturb: `cmd notification set_dnd on/off` |
| Orientation lock | real auto-rotate setting |
| Brightness | real system brightness (manual mode) |
| Volume, Flashlight | work without AeroHUB |

Settings (gear icon, top left of the Control Center):

1. **AeroHUB** - status and permission button.
2. **Top-edge pull-down** - starts a small foreground service with an invisible strip at the very top edge. Pull down on it and this Control Center opens over any app. The "display over other apps" permission is granted automatically through AeroHUB.
3. **System pull-down lock** - AeroHUB calls `IStatusBarService.disable` (`DISABLE_EXPAND`, `DISABLE2_QUICK_SETTINGS`, `DISABLE2_NOTIFICATION_SHADE`) so the phone's own notification panel and control center do not open. The lock lives in the AeroHUB server process: it is released when the AeroHUB server stops or the phone restarts, and re-applied when AeroHUB connects again. Switching the overlay off also releases it.

Setup order: install AeroHUB, start its server, open this app, Settings, tap Allow in the AeroHUB page, switch on the overlay, then the lock.

## Settings home (v2.1)

Opening the app shows all settings (the app is in English): AeroHUB status, the pull-down switch (trigger height / area, start after reboot), the stock pull-down lock, tile chooser (up to 16 tiles), preferences (24-hour clock, hint messages, vibrate on tap), a permissions page (overlay, notifications, modify system settings, Do Not Disturb access, battery) and a short setup guide. Tap **Open Control Center** to see the panel.

Without AeroHUB: brightness and rotation lock work with the *Modify system settings* permission, Focus works with *Do Not Disturb access*.

## v2.3: no accessibility service, smoother panel

The pull-down now needs only three things: **Display over other apps**, **Notification access** and **AeroHUB**. The accessibility service is gone.

| What | How it works now |
| --- | --- |
| Pull-down gesture | With AeroHUB, the AeroHUB process reads the touch screen with `getevent` and reports a swipe-down that starts in the top edge. This works even where the phone's status bar is above every overlay. Turn on the lock so the phone's own panel does not open under the same swipe (the app also sends `cmd statusbar collapse`). Without AeroHUB only the thin top strip is used. |
| Notification access | `MediaListener` gives the app the active media sessions: the **Now Playing** tile shows and controls the music of any app (play / pause / next / previous). Notifications are never read or saved. One tap with AeroHUB (`cmd notification allow_listener`). |
| Display over other apps | The panel and the fallback strip. Granted by AeroHUB (`appops set ... SYSTEM_ALERT_WINDOW allow`). |

Smoothness changes:

- Brightness slider writes the system setting directly (the app gives itself *Modify system settings* through AeroHUB) instead of starting a shell process for every move. Only the latest value is written; old ones are skipped.
- Volume only talks to the system when the step changes, and the slider ignores the system's volume broadcast while the finger is on it.
- Sliders are drawn from lambdas, so a drag no longer recomposes the whole panel. The wallpaper is cached in its own layer.
- The panel is built once in the background and only shown / hidden, so the first pull-down is no longer slow. One shared entrance animation replaces 25 separate spring animations.

## v2.4: split pull-down (right = Control Center, left = notification panel)

The top edge is now split in two halves:

| Pull down on | Opens |
| --- | --- |
| **Right half** | this Control Center |
| **Left half** | the phone's own notification panel |

How it works:

- The touch watcher only reacts to swipes that start in the right half.
- While a finger that started in the right half is on the screen, the phone's own pull-down is held back (status bar disable flags, set and released by the AeroHUB process). The moment the finger lifts, it is released again, so the left half always opens the phone's own panel.
- If the phone's own panel still starts to open under a right-half swipe, the app closes it (`cmd statusbar collapse`) and shows the Control Center, as before.
- Without AeroHUB only the right half gets the thin top strip; the left half is left to the phone.
- **Split pull-down** is on by default (Settings, Pull-down card). While it is on, the full lock ("Lock notification panel and stock Control Center") is not used and is switched off, because it would also block the left half. Turn Split pull-down off to get the old behaviour (Trigger area + full lock) back.
- Removed tiles: Internet panel, Camera, Code scanner and Calculator are no longer in the grid or in the tile chooser.
- The version code went up (6) so AeroHUB is asked to run the new code with the new interface. After installing, open the app once with AeroHUB running.

## v2.5: own notification panel, themes, blur, grouped settings

| What | How it works now |
| --- | --- |
| **Notification panel** | Pull down on the **left half** of the top edge: this app's own panel opens (big clock, one rounded card per notification with app icon, title, text and up to two action buttons such as *Stop*). Tap = open, swipe sideways = dismiss, *Clear all*. Needs **Notification access**. Notifications are only held in memory. Turn it off under Settings > Control Center > "Use this app's notification panel" to get the phone's own panel back on the left half. |
| **Settings** | The settings home is a list of groups: AeroHUB, Pull-down, Notification panel, Theme, Blur & background, Tiles, Behavior, Permissions, Help & About. Each opens its own page. |
| **Theme** | Dark / Light / follow system, accent colour for tiles that are on, tile shape. |
| **Blur & background** | Blurred screen (real window blur on Android 12+, falls back to the gradient if the phone does not allow it) or gradient, blur strength, tint. Same look for the Control Center and the notification panel. |
| **Mobile data** | Fixed the button jumping back to *On*: the state is now read from the data SIM's own switch (`mobile_data<subId>`), the system's answer is ignored while the change is on its way, and the switch tries `svc data`, `cmd phone data` and `settings put global mobile_data` one after the other. |
| **Tap and hold Wi-Fi / Mobile data** | Opens the floating *Internet* panel of Android (`Settings.Panel.ACTION_INTERNET_CONNECTIVITY`) over the current app, not the full Settings. Settings > Behavior can change it to the full screen. |
| More | 24-hour clock, date under the clock, hide notification content, show / hide ongoing and music notifications, "Test notification panel" button. |

Notes: the version code is 7, so AeroHUB is asked to run the new code with the new listener interface: open the app once with the AeroHUB server running after installing. The swipe listener now reports which half the swipe started on. `QUERY_ALL_PACKAGES` is used only to read the name and icon of the apps that post notifications.

## Other controls

| Control | Behaviour |
| --- | --- |
| Status bar battery, Wi-Fi, mobile data, airplane | Live state |
| Share | System share sheet |
| Mirror, Output | Open the matching Android settings screen |
| Timer | Countdown with beep and vibration |
| Now Playing | Music of any app (needs Notification access). Without it: tap play to pick audio files inside the app |

## Files

```
app/src/main/java/com/aerocontrolcenter/app/
  MainActivity.kt          entry point
  Controller.kt            all device logic and state
  Shell.kt / AeroHub.kt  AeroHUB bridge (commands, streams, status bar flags)
  OverlayService.kt        overlay panel (built once, shown / hidden) + fallback strip
  MediaListener.kt         Notification access (media sessions + the notifications for the panel)
  BootReceiver.kt          restarts the overlay after reboot
  ui/SettingsScreen.kt     Settings (home list + one page per group)
  ui/NotificationPanel.kt  the app's own notification panel
  ui/Look.kt               theme, blur tint, wallpaper, tap / hold helper
  ui/ControlCenterScreen.kt  layout (grid of 214 x 465 units), sheets
  ui/Icons.kt              SVG path icons drawn with Compose Canvas
  ui/Calc.kt               calculator logic
.github/workflows/build-apk.yml   APK build
```

## License

MIT


## v2.6 changes

- **Tiles of other apps (v7.1)**: Settings > Tiles (and the plus list in Edit) now also list the Quick Settings tiles of installed apps, for example Cloudflare 1.1.1.1. A tap presses the tile through AeroHUB (`cmd statusbar add-tile` + `click-tile`). Their on/off state cannot be read, so they always look "off".
- **Edit inside the panel**: tap **Edit** in the Control Center (no need to open the app). Every tile gets a small minus at its top right to remove it, hold a tile and drag it to move it, and the tiles that are off are listed below with a plus to add them back. **Settings** and **Done** buttons are shown in edit mode.
- The tile order is saved (`tile_order`); Settings > Tiles still works and keeps the order.
- The navigation bar is no longer a solid black bar while the panel is open.

- **Developer card** (Foysal) in Settings > Help & About; tap the e-mail to write to the developer.
- **Release build**: the workflow now builds a signed release APK when the signing secrets exist (see "Making a release" below); a running timer is set again after a reboot; app data is no longer copied by Android backup.

## Making a release

1. Make a keystore once (keep it safe, never commit it):
   `keytool -genkeypair -v -keystore release.jks -alias cc -keyalg RSA -keysize 2048 -validity 10000`
2. In the GitHub repo, Settings > Secrets and variables > Actions, add: `KEYSTORE_BASE64` (output of `base64 -w0 release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
3. Raise `versionCode` / `versionName` in `app/build.gradle.kts`, then push a tag: `git tag v2.6 && git push origin v2.6`.
4. The signed APK appears under the repo's Releases. Always sign updates with the same keystore, or Android will refuse to update the installed app.

Local build: put `storeFile`, `storePassword`, `keyAlias`, `keyPassword` into `keystore.properties` and run `gradle assembleRelease`.

## v2.7 changes

- **Two new Control Center styles** (Settings > Theme > Style): **MIUI** (title with settings and edit buttons, wide tiles, round buttons, wide brightness / volume sliders) and **HyperOS** (glass look, pill Wi-Fi / Mobile data, music tile, round sliders, round buttons with names, date). The iOS style stays the default. Tile editing (minus, hold and drag, add) works in all three.
- **Transparent navigation bar**: the panels now live in a real window (Dialog) with a transparent navigation bar and no contrast scrim, instead of a bare overlay view that left a black bar.
- Default tile order starts with Bluetooth and Flashlight (they are the two wide tiles in the MIUI style). Saved orders are kept.

## Custom status bar (v2.8)

Settings → **Status bar**: draws a custom status bar (time, notification icons, network speed, alarm, VoLTE, Wi-Fi, mobile signal, battery pill) and hides the phone's own one through AeroHUB. It is **off by default**.

- The button at the very top of Settings, **Restore phone's status bar & Control Center**, switches the custom bar and the pull-down off and gives the phone's own status bar and Control Center back.
- The phone's own bar is also given back on the lock screen, while the screen is off, and when AeroHUB stops.

## v7.5: Dynamic Island, keyboard step
- **Dynamic Island** (Settings > Dynamic Island): a black pill that only floats at the top of the screen. It takes no touches and does nothing. Width, height, distance from top and left / right are adjusted live; optional camera dot; hidden in landscape by default. Needs "Display over other apps".
- **Keyboard** step in Setup: switch on the app's tiny keyboard so the system keeps the app alive.

## v2.9.1: bug-fix pass

- **Timer notification no longer removes a service notification**: it used id 2, the same as the custom status bar's foreground notification. Dismissing "Timer finished" could drop that notification (and with it the service's foreground state). It now uses its own id.
- **AeroHUB**: an unusable binder or a service that never answers no longer leaves the state on "Connecting" for ever. After a reconnect the landscape edge-reveal and navigation-bar zones are sent again.
- **Touch watcher** (runs in the AeroHUB process): no new `Regex` for every getevent line.
- **Notification access** is requested back (`requestRebind`) when the system drops the listener. App names are cached.
- **Memory**: the panels built at start-up are freed after 2 minutes without use, like they already were after every use. The Quick Settings tile scan (PackageManager) is cached for 30 s.
- **Tiles**: tiles of an uninstalled app no longer stay on the grid as empty squares. Settings > Tiles counts tiles of other apps from the start and shows what was really saved.
- `BootReceiver` is not exported. `versionCode` 12 so AeroHUB is asked to run the new code with the new code: open the app once with the AeroHUB server running after installing.



## Changed in 3.0.0: AeroHUB instead of Shizuku
- The Shizuku permission, provider and libraries are removed. The app now asks **AeroHUB** (package `com.example.mykuzu`, server version 4 or newer) for access: Settings > AeroHUB > Allow opens AeroHUB's permission dialog.
- Commands run through AeroHUB's `EXEC`; the touch watcher reads `getevent` through AeroHUB's `STREAM`; the status bar / navigation locks use AeroHUB's `SBFLAGS` (AeroHUB hands the navigation buttons back if the heartbeats stop).
- After installing both apps: start the AeroHUB server (Restart server if it says outdated), open this app and tap Allow.
