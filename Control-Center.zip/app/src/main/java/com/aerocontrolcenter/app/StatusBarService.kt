package com.aerocontrolcenter.app

import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.location.LocationManager
import android.telephony.SubscriptionManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.telephony.TelephonyManager
import android.view.ContextThemeWrapper
import android.view.Display
import android.view.Gravity
import android.view.Surface
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.aerocontrolcenter.app.ui.StatusBarContent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

/** Everything the custom status bar shows. Compose reads it; only [StatusBarService] writes it (main thread). */
/** One SIM card on the bar: slot 0/1, signal bars 0..4, network label ("5G", "4G", ...), and whether it has service. */
data class SimInfo(val slot: Int, val level: Int, val net: String, val noService: Boolean)

class StatusData {
    /** False until the phone's own status bar is really hidden: nothing is drawn before that (no double bar). */
    var active by mutableStateOf(false)

    var time by mutableStateOf("")
    var speed by mutableStateOf("0.00")
    var speedUnit by mutableStateOf("KB/s")
    var down by mutableStateOf(false)
    var up by mutableStateOf(false)
    var alarm by mutableStateOf(false)
    var volte by mutableStateOf(false)
    var netType by mutableStateOf("")
    var signal by mutableIntStateOf(0)        // 0..4
    /** Every active SIM (dual SIM shows both). Empty in airplane mode or when there is no SIM. */
    var sims by mutableStateOf<List<SimInfo>>(emptyList())
    var airplane by mutableStateOf(false)
    var bluetooth by mutableStateOf(false)
    var hotspot by mutableStateOf(false)
    var vpn by mutableStateOf(false)
    var location by mutableStateOf(false)
    var wifiLevel by mutableIntStateOf(-1)    // -1 = not on Wi-Fi, otherwise 0..4
    var battery by mutableIntStateOf(100)
    var charging by mutableStateOf(false)
    var saver by mutableStateOf(false)

    var showSpeed by mutableStateOf(true)
    var showNotif by mutableStateOf(true)
    var showVolte by mutableStateOf(true)
    var black by mutableStateOf(false)

    /** Look of the bar: 0 = iOS, 1 = MIUI, 2 = HyperOS (follows the Control Center style unless chosen by hand). */
    var style by mutableIntStateOf(2)

    /** Size of the whole bar (text, icons and height): 0.7 .. 1.5, 1 = normal. */
    var scale by mutableFloatStateOf(1f)

    /** True while the app behind the bar is light: icons and text turn dark so they stay readable. */
    var dark by mutableStateOf(false)

    /** True while the Control Center / notification panel is open: the bar is not drawn over it. */
    var panel by mutableStateOf(false)

    /** Left / right space in dp (round corners and side camera cut-outs). */
    var padStart by mutableFloatStateOf(16f)
    var padEnd by mutableFloatStateOf(16f)
}

/**
 * Custom status bar. The phone's own status bar is hidden through Shizuku (clock, notification icons and
 * system icons are switched off) and this bar is drawn in its place as an overlay.
 *
 * Landscape: the phone's own bar is shown; turning the phone back to portrait brings this bar back.
 *
 * Safety: the phone's own bar is given back while the screen is off / the phone is locked, when Shizuku stops,
 * when this service stops, and by the "Restore phone's status bar" button at the top of the app settings.
 */
class StatusBarService : Service() {

    private lateinit var wm: WindowManager
    private val owner = BarOwner()
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val data = StatusData()
    private var bar: ComposeView? = null

    private var lastRotation = 0
    private var screenOn = true

    /** Landscape auto-hide: the phone's bars are hidden until an edge swipe shows them for [REVEAL_MS]. */
    private var landAuto = true
    private var revealed = false
    private var lastAuto = false
    private var builtScale = 1f
    private val hideAgain = Runnable {
        revealed = false
        syncStock()
    }
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L
    /** One telephony callback per active SIM: subscription id -> (its TelephonyManager, callback or listener). */
    private val subCallbacks = HashMap<Int, Pair<TelephonyManager, Any>>()
    private var subsListener: SubscriptionManager.OnSubscriptionsChangedListener? = null
    /** 5G NSA shows up as LTE in dataNetworkType; the display info tells the real label (per SIM). */
    private val overrideNet = HashMap<Int, Int>()

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            main.postDelayed(this, 1000L)
        }
    }

    /** Status bar text colour: looked at 5 times a second (every 200 ms) and applied at once. */
    private val inkTicker = object : Runnable {
        override fun run() {
            if (screenOn) readBackground()
            main.postDelayed(this, INK_INTERVAL_MS)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val intent = i ?: return
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> readBattery(intent)
                PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> readSaver()
                Intent.ACTION_SCREEN_OFF -> onScreen(false)
                Intent.ACTION_SCREEN_ON -> onScreen(true)
                Intent.ACTION_USER_PRESENT -> syncStock()
                WifiManager.RSSI_CHANGED_ACTION, WifiManager.NETWORK_STATE_CHANGED_ACTION -> if (screenOn) readNetwork()
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> readNetwork()
                BluetoothAdapter.ACTION_STATE_CHANGED -> readExtras()
                ACTION_AP_STATE, ACTION_TETHER_STATE, ACTION_LOC_MODE, ACTION_LOC_PROVIDERS -> readExtras()
                // clock, time zone and alarm changes
                else -> if (screenOn) tick()
            }
        }
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val r = rotation()
            if (r == lastRotation) return
            lastRotation = r
            addBar()
            // landscape: the phone's own bar comes back; portrait: this bar comes back
            syncStock()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WindowManager::class.java)
        owner.resume()
        instance = this
        running = true
        loadPrefs()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_TIME_TICK)
            addAction(WifiManager.RSSI_CHANGED_ACTION)
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(ACTION_AP_STATE)
            addAction(ACTION_TETHER_STATE)
            addAction(ACTION_LOC_MODE)
            addAction(ACTION_LOC_PROVIDERS)
        }
        try {
            ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        } catch (_: Exception) {
        }
        try {
            registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { readBattery(it) }
        } catch (_: Exception) {
        }
        readSaver()
        startTelephony()
        readExtras()

        lastRotation = rotation()
        try {
            getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, main)
        } catch (_: Exception) {
        }

        screenOn = try { getSystemService(PowerManager::class.java).isInteractive } catch (_: Exception) { true }
        addBar()
        if (screenOn) { main.post(ticker); main.post(inkTicker) }
        main.postDelayed({ syncStock() }, 300)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    /** The app was swiped away from Recents: some phones stop the services with it, so ask for a restart. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        KeepAlive.restartSoon(applicationContext)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        if (instance === this) instance = null
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        stopTelephony()
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener) } catch (_: Exception) {}
        if (::wm.isInitialized) removeBar()
        Shell.setEdgeReveal(false, 0, 0, null)
        owner.destroy()
        // never leave the phone without a status bar: give the phone's own one back
        scope.launch { Shell.setStatusBarHidden(false) }
        super.onDestroy()
    }

    /* ---------- foreground notification ---------- */

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("cc_statusbar", "Status bar", NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_SETTINGS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, "cc_statusbar")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Custom status bar is on")
            .setContentText("Tap for settings")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        // Works even when the user turned this app's notifications off (the system just hides the notification).
        // Never let a refused notification crash the service: try again with the plain type, then keep running.
        try {
            ServiceCompat.startForeground(this, 2, n, type)
        } catch (_: Throwable) {
            try {
                startForeground(2, n)
            } catch (_: Throwable) {
            }
        }
    }

    /* ---------- settings ---------- */

    private fun loadPrefs() {
        val p = getSharedPreferences("cc", Context.MODE_PRIVATE)
        data.showSpeed = p.getBoolean("cs_speed", true)
        data.showNotif = p.getBoolean("cs_notif", true)
        data.showVolte = p.getBoolean("cs_volte", true)
        data.black = false   // always fully transparent: no dark background or shadow
        // "cs_style": 0 = same style as the Control Center, 1 = iOS, 2 = MIUI, 3 = HyperOS
        val own = p.getInt("cs_style", 0)
        data.style = (if (own == 0) p.getInt("ui_style", 2) else own - 1).coerceIn(0, 2)
        data.scale = p.getInt("cs_scale", 100).coerceIn(70, 150) / 100f
        landAuto = p.getBoolean("cs_land_auto", true)
        autoInk = p.getBoolean("cs_autoink", true)
        manualDark = p.getBoolean("cs_darkink", false)
        if (!autoInk) data.dark = manualDark
        lastT = 0L
    }

    /* ---------- the phone's own status bar ---------- */

    /**
     * Hides the phone's own bar (and shows this one) while the screen is on and the phone is unlocked.
     * On the lock screen and while the screen is off the phone's own bar is given back.
     */
    private fun syncStock(retry: Int = 0) {
        if (instance !== this) return
        val kg = getSystemService(KeyguardManager::class.java)
        val locked = try { kg?.isKeyguardLocked == true } catch (_: Exception) { false }
        val land = isLandscape()
        // Landscape auto-hide needs the touch watcher (it sees the edge swipe); without it the bars stay as they are,
        // so the phone is never left without navigation buttons.
        val auto = land && landAuto && Shell.pulling
        lastAuto = auto
        val usable = screenOn && !locked
        val showCustom = usable && !land
        val hideStatus = usable && (!land || (auto && !revealed))
        val hideNav = usable && auto && !revealed
        if (!showCustom) data.active = false
        if (!(usable && auto)) { revealed = false; main.removeCallbacks(hideAgain) }
        val density = resources.displayMetrics.density
        Shell.setEdgeReveal(usable && auto, (24 * density).toInt(), (28 * density).toInt()) {
            instance?.onEdgeSwipe()
        }
        scope.launch {
            val ok = Shell.setSystemBars(hideStatus, hideNav)
            main.post {
                if (instance !== this@StatusBarService) return@post
                data.active = showCustom && ok
                // Shizuku may need a moment after the screen was off: try again instead of leaving the bar hidden
                if (!ok && usable && retry < 8) {
                    main.postDelayed({ if (instance === this@StatusBarService && screenOn) syncStock(retry + 1) }, 1200L * (retry + 1))
                }
            }
        }
    }

    /** Edge swipe in landscape: show the phone's status bar and navigation bar for 2 seconds, then hide them again. */
    private fun onEdgeSwipe() {
        if (!lastAuto || !screenOn) return
        revealed = true
        main.removeCallbacks(hideAgain)
        syncStock()
        main.postDelayed(hideAgain, REVEAL_MS)
    }

    private fun onScreen(on: Boolean) {
        screenOn = on
        main.removeCallbacks(ticker)
        main.removeCallbacks(inkTicker)
        revealed = false
        main.removeCallbacks(hideAgain)
        if (on) {
            lastT = 0L
            // the bar window can be gone after the screen was off (the system or a cleaner removed it): put it back
            if (bar?.isAttachedToWindow != true) addBar()
            main.post(ticker)
            main.post(inkTicker)
            main.postDelayed({ syncStock() }, 600)
        } else {
            data.active = false
            scope.launch { Shell.setStatusBarHidden(false) }
        }
    }

    /* ---------- the bar window ---------- */

    private fun rotation(): Int = try {
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
    } catch (_: Exception) {
        Surface.ROTATION_0
    }

    /** True while the screen is wider than it is tall (phone turned sideways). */
    @Suppress("DEPRECATION")
    private fun isLandscape(): Boolean = try {
        val dm = android.util.DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.getRealMetrics(dm)
        dm.widthPixels > dm.heightPixels
    } catch (_: Exception) {
        false
    }

    private fun statusHeight(): Int {
        val land = rotation() == Surface.ROTATION_90 || rotation() == Surface.ROTATION_270
        var id = resources.getIdentifier(if (land) "status_bar_height_landscape" else "status_bar_height_portrait", "dimen", "android")
        if (id <= 0) id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else (24 * resources.displayMetrics.density).toInt()
    }

    private fun updatePads() {
        val density = resources.displayMetrics.density
        var l = 0
        var r = 0
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val c = wm.currentWindowMetrics.windowInsets.displayCutout
                l = c?.safeInsetLeft ?: 0
                r = c?.safeInsetRight ?: 0
            } catch (_: Throwable) {
            }
        }
        data.padStart = maxOf(16f, l / density + 6f)
        data.padEnd = maxOf(16f, r / density + 6f)
    }

    private fun removeBar() {
        val v = bar ?: return
        bar = null
        try { v.disposeComposition() } catch (_: Exception) {}
        try { wm.removeViewImmediate(v) } catch (_: Exception) {}
    }

    /**
     * [seamless] = put the new bar window on top first and remove the old one a moment later, so the bar never
     * disappears for a frame (used when the panel opens; removing first makes the bar blink / shake).
     */
    private fun addBar(seamless: Boolean = false) {
        val old = if (seamless) bar else null
        if (!seamless) removeBar()
        updatePads()
        val cv = ComposeView(ContextThemeWrapper(this, R.style.Theme_ControlCenter))
        cv.setViewTreeLifecycleOwner(owner)
        cv.setViewTreeSavedStateRegistryOwner(owner)
        cv.setViewTreeViewModelStoreOwner(owner)
        cv.setContent { StatusBarContent(data) }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, (statusHeight() * data.scale).toInt().coerceAtLeast(1),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            wm.addView(cv, lp)
            bar = cv
            builtScale = data.scale
        } catch (_: Exception) {
        }
        if (old != null) {
            main.postDelayed({
                try { old.disposeComposition() } catch (_: Exception) {}
                try { wm.removeViewImmediate(old) } catch (_: Exception) {}
            }, 150L)
        }
    }

    /* ---------- live values ---------- */

    private fun tick() {
        // Shizuku went away: the phone's own bar is back by itself, so this one must not be drawn as well
        if (data.active && !Shell.ready) data.active = false
        Shell.heartbeat()
        // the touch watcher started / stopped: landscape auto-hide follows it (buttons come back when it stops)
        if ((isLandscape() && landAuto && Shell.pulling) != lastAuto) syncStock()
        readClock()
        readAlarm()
        readNetwork()
        readExtras()
        readSpeed()
    }

    private var lumaBusy = false
    private var autoInk = true
    private var manualDark = false

    /** Debounce for the auto colour: the opposite reading must be seen twice in a row before the colour flips. */
    private var pendingDark = false
    private var pendingCount = 0
    private var lastDbg = ""
    private var lastDump = 0L

    /**
     * Looks at the strip of the screen behind the bar: on a light app the bar turns dark, on a dark app it
     * stays white. The switch point is where dark ink and white ink are equally readable, with a narrow dead
     * zone (hysteresis) so it does not flicker on mid-grey backgrounds.
     */
    private fun readBackground() {
        if (!autoInk) { data.dark = manualDark; return }
        if (lumaBusy || !data.active || !screenOn || data.panel) return
        lumaBusy = true
        // sample exactly the strip the bar covers (it is statusHeight * scale tall), not more
        val rows = (statusHeight() * data.scale).roundToInt().coerceAtLeast(1)
        scope.launch {
            var l = -1
            var light = -1
            var dbg = ""
            try {
                l = Shell.barLuma(rows)
                dbg = "screencap luma=$l rows=$rows"
                if (l < 0) {
                    // screencap is blocked on some phones: ask the system whether the app asked for dark icons
                    // (APPEARANCE_LIGHT_STATUS_BARS = 0x8), which light apps set themselves.
                    // dumpsys is slow, so it is asked at most once a second.
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastDump >= 1000L) {
                        lastDump = now
                        val (_, out) = Shell.exec("dumpsys window | grep -i -E 'appearance|lightstatus' | head -8")
                        val m = Regex("(?i)appearance\\w*\\s*[=:]\\s*(?:0x)?([0-9a-f]+)").find(out)
                        if (m != null) {
                            val v = m.groupValues[1].toLongOrNull(16) ?: -1L
                            if (v >= 0) light = if ((v and 0x8L) != 0L) 1 else 0
                        }
                        dbg = "screencap failed; dumpsys=" + out.trim().replace('\n', ' ').take(160)
                    }
                }
            } catch (_: Throwable) {
            }
            // only write the debug line when it changed (it used to be written 5 times a second)
            if (dbg.isNotEmpty() && dbg != lastDbg) {
                lastDbg = dbg
                try { getSharedPreferences("cc", Context.MODE_PRIVATE).edit().putString("cs_dbg", dbg).apply() } catch (_: Throwable) {}
            }
            main.post {
                // always released, so one failed reading can never stop the auto colour for good
                lumaBusy = false
                if (!autoInk) return@post
                if (l >= 0) {
                    val want: Boolean? = when {
                        l >= DARK_ON -> true
                        l <= DARK_OFF -> false
                        else -> null            // dead zone: keep the current colour
                    }
                    if (want == null || want == data.dark) {
                        pendingCount = 0
                    } else {
                        // far from the switch point: flip at once; close to it: confirm with a second reading
                        val far = l >= DARK_ON + 25 || l <= DARK_OFF - 25
                        if (far) {
                            data.dark = want
                            pendingCount = 0
                        } else {
                            if (pendingDark == want) pendingCount++ else { pendingDark = want; pendingCount = 1 }
                            if (pendingCount >= 2) { data.dark = want; pendingCount = 0 }
                        }
                    }
                } else if (light >= 0) {
                    data.dark = light == 1
                }
            }
        }
    }

    private fun readClock() {
        val p = getSharedPreferences("cc", Context.MODE_PRIVATE)
        val is24 = p.getBoolean("clock24", android.text.format.DateFormat.is24HourFormat(this))
        data.time = java.text.SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.ENGLISH).format(java.util.Date())
    }

    private fun readAlarm() {
        data.alarm = try {
            getSystemService(AlarmManager::class.java).nextAlarmClock != null
        } catch (_: Throwable) {
            false
        }
    }

    private fun readBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (lvl >= 0 && scale > 0) data.battery = (lvl * 100f / scale).roundToInt().coerceIn(0, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        data.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun readSaver() {
        data.saver = try { getSystemService(PowerManager::class.java).isPowerSaveMode } catch (_: Throwable) { false }
    }

    /* ---------- mobile network: every SIM ---------- */

    /** Active SIM cards, slot order. Needs the Phone permission (given through Shizuku); empty without it. */
    private fun activeSubs(): List<android.telephony.SubscriptionInfo> = try {
        (getSystemService(SubscriptionManager::class.java)?.activeSubscriptionInfoList ?: emptyList())
            .sortedBy { it.simSlotIndex }
    } catch (_: Throwable) {
        emptyList()
    }

    /** Signal bars and network type update the moment the modem reports a change, for each SIM separately. */
    @Suppress("DEPRECATION")
    private fun registerSubCallbacks() {
        val tm = getSystemService(TelephonyManager::class.java) ?: return
        for (si in activeSubs()) {
            val id = si.subscriptionId
            if (subCallbacks.containsKey(id)) continue
            try {
                val t = tm.createForSubscriptionId(id)
                if (Build.VERSION.SDK_INT >= 31) {
                    val cb = object : android.telephony.TelephonyCallback(),
                        android.telephony.TelephonyCallback.SignalStrengthsListener,
                        android.telephony.TelephonyCallback.DisplayInfoListener,
                        android.telephony.TelephonyCallback.ServiceStateListener {
                        override fun onSignalStrengthsChanged(signalStrength: android.telephony.SignalStrength) {
                            main.post { readNetwork() }
                        }
                        override fun onDisplayInfoChanged(telephonyDisplayInfo: android.telephony.TelephonyDisplayInfo) {
                            overrideNet[id] = telephonyDisplayInfo.overrideNetworkType
                            main.post { readNetwork() }
                        }
                        override fun onServiceStateChanged(serviceState: android.telephony.ServiceState) {
                            main.post { readNetwork() }
                        }
                    }
                    t.registerTelephonyCallback(ContextCompat.getMainExecutor(this), cb)
                    subCallbacks[id] = t to cb
                } else {
                    val l = object : android.telephony.PhoneStateListener() {
                        override fun onSignalStrengthsChanged(signalStrength: android.telephony.SignalStrength?) {
                            main.post { readNetwork() }
                        }
                        override fun onServiceStateChanged(serviceState: android.telephony.ServiceState?) {
                            main.post { readNetwork() }
                        }
                    }
                    t.listen(l, android.telephony.PhoneStateListener.LISTEN_SIGNAL_STRENGTHS or
                        android.telephony.PhoneStateListener.LISTEN_SERVICE_STATE)
                    subCallbacks[id] = t to l
                }
            } catch (_: Throwable) {
                // needs the Phone permission (given through Shizuku); the 1 s poll still works without it
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun unregisterSubCallbacks() {
        for ((_, pair) in subCallbacks) {
            val (t, cb) = pair
            try {
                if (Build.VERSION.SDK_INT >= 31) (cb as? android.telephony.TelephonyCallback)?.let { t.unregisterTelephonyCallback(it) }
                else (cb as? android.telephony.PhoneStateListener)?.let { t.listen(it, android.telephony.PhoneStateListener.LISTEN_NONE) }
            } catch (_: Throwable) {
            }
        }
        subCallbacks.clear()
    }

    @Suppress("DEPRECATION")
    private fun startTelephony() {
        registerSubCallbacks()
        // SIM inserted / removed / swapped: listen to the new set of SIMs
        try {
            val sm = getSystemService(SubscriptionManager::class.java) ?: return
            val l = object : SubscriptionManager.OnSubscriptionsChangedListener() {
                override fun onSubscriptionsChanged() {
                    main.post {
                        unregisterSubCallbacks()
                        registerSubCallbacks()
                        readNetwork()
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= 29) sm.addOnSubscriptionsChangedListener(ContextCompat.getMainExecutor(this), l)
            else sm.addOnSubscriptionsChangedListener(l)
            subsListener = l
        } catch (_: Throwable) {
        }
    }

    private fun stopTelephony() {
        try {
            subsListener?.let { getSystemService(SubscriptionManager::class.java)?.removeOnSubscriptionsChangedListener(it) }
        } catch (_: Throwable) {
        }
        subsListener = null
        unregisterSubCallbacks()
    }

    @Suppress("DEPRECATION")
    private fun wifiLevel(): Int = try {
        val w = applicationContext.getSystemService(WifiManager::class.java)
        val rssi = w.connectionInfo?.rssi ?: -100
        WifiManager.calculateSignalLevel(rssi, 5).coerceIn(0, 4)
    } catch (_: Throwable) {
        2
    }

    private fun netLabel(t: Int): String = when (t) {
        20 -> "5G"                                  // NETWORK_TYPE_NR
        19 -> "4G+"                                 // NETWORK_TYPE_LTE_CA
        13 -> "4G"                                  // NETWORK_TYPE_LTE
        3, 8, 9, 10, 15, 17 -> "3G"                 // UMTS, HSDPA, HSUPA, HSPA, HSPAP, TD-SCDMA
        5, 6, 12, 14 -> "3G"                        // EVDO 0 / A / B, EHRPD
        1, 2, 4, 7, 11 -> "2G"                      // GPRS, EDGE, CDMA, 1xRTT, IDEN
        else -> ""
    }

    /** Signal level, network label and service state of one SIM (its own TelephonyManager). */
    @Suppress("DEPRECATION")
    private fun readSim(t: TelephonyManager, subId: Int, slot: Int): SimInfo {
        val level = try {
            if (Build.VERSION.SDK_INT >= 28) (t.signalStrength?.level ?: 0) else 0
        } catch (_: Throwable) {
            0
        }
        val noService = try {
            t.serviceState?.let { it.state != android.telephony.ServiceState.STATE_IN_SERVICE } ?: false
        } catch (_: Throwable) {
            false
        }
        var dn = try { t.dataNetworkType } catch (_: Throwable) { 0 }
        if (dn == 0) dn = try { t.voiceNetworkType } catch (_: Throwable) { 0 }
        val ov = overrideNet[subId] ?: 0
        // 3 = NR NSA, 4 = NR advanced (5G shown on top of an LTE anchor)
        val label = if (ov == 3 || ov == 4) "5G" else netLabel(dn)
        return SimInfo(slot, level, if (noService) "" else label, noService || level == 0 && label.isEmpty())
    }

    private fun readNetwork() {
        val cm = getSystemService(ConnectivityManager::class.java)
        // the default network can be a VPN or the mobile network while Wi-Fi is connected: look at every network
        @Suppress("DEPRECATION")
        val onWifi = try {
            cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true ||
                cm.allNetworks.any {
                    val c = cm.getNetworkCapabilities(it)
                    c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                        c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                }
        } catch (_: Throwable) {
            false
        }
        data.wifiLevel = if (onWifi) wifiLevel() else -1

        // airplane mode: no mobile signal at all, the airplane icon is shown instead
        val air = try {
            Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        } catch (_: Throwable) {
            false
        }
        data.airplane = air
        if (air) {
            data.sims = emptyList()
            data.signal = 0
            data.netType = ""
            data.volte = false
            return
        }

        val tm = getSystemService(TelephonyManager::class.java) ?: return
        val subs = activeSubs()
        val list = ArrayList<SimInfo>()
        if (subs.isNotEmpty()) {
            if (subCallbacks.isEmpty()) registerSubCallbacks()
            for (si in subs) {
                try {
                    list.add(readSim(tm.createForSubscriptionId(si.subscriptionId), si.subscriptionId, si.simSlotIndex))
                } catch (_: Throwable) {
                }
            }
        } else {
            // no Phone permission yet (or one SIM only): fall back to the default SIM
            val hasSim = try { tm.simState == TelephonyManager.SIM_STATE_READY } catch (_: Throwable) { false }
            if (hasSim) list.add(readSim(tm, -1, 0))
        }
        data.sims = list
        val first = list.firstOrNull()
        data.signal = first?.level ?: 0
        data.netType = first?.net ?: ""
        data.volte = try {
            val vn = tm.voiceNetworkType
            vn == 13 || vn == 19
        } catch (_: Throwable) {
            false
        }
    }

    /* ---------- Bluetooth, hotspot, VPN, location ---------- */

    @Suppress("DEPRECATION")
    private fun hotspotOn(): Boolean {
        try {
            val w = applicationContext.getSystemService(WifiManager::class.java)
            val m = w?.javaClass?.getMethod("isWifiApEnabled")
            if (m != null && (m.invoke(w) as? Boolean) == true) return true
        } catch (_: Throwable) {
        }
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val a = cm.javaClass.getMethod("getTetheredIfaces").invoke(cm) as? Array<*>
            if (a != null && a.isNotEmpty()) return true
        } catch (_: Throwable) {
        }
        // the phone hides both calls: look for a live hotspot / tethering network interface instead
        return try {
            val re = Regex("^(ap|swlan|softap|wlan[1-9]|rndis|ncm|bt-pan)\\d*$")
            java.net.NetworkInterface.getNetworkInterfaces().asSequence().any { ni ->
                re.matches(ni.name) && ni.isUp &&
                    ni.inetAddresses.asSequence().any { it is java.net.Inet4Address && !it.isLoopbackAddress }
            }
        } catch (_: Throwable) {
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun vpnOn(): Boolean = try {
        val cm = getSystemService(ConnectivityManager::class.java)
        cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
    } catch (_: Throwable) {
        false
    }

    private fun locationOn(): Boolean = try {
        val lm = getSystemService(LocationManager::class.java)
        if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else Settings.Secure.getInt(contentResolver, Settings.Secure.LOCATION_MODE, 0) != 0
    } catch (_: Throwable) {
        false
    }

    private fun bluetoothOn(): Boolean = try {
        getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
    } catch (_: Throwable) {
        false
    }

    private fun readExtras() {
        data.bluetooth = bluetoothOn()
        data.hotspot = hotspotOn()
        data.vpn = vpnOn()
        data.location = locationOn()
    }

    private fun formatSpeed(bytesPerSec: Double): Pair<String, String> {
        val kb = bytesPerSec / 1024.0
        if (kb < 1000.0) {
            val f = if (kb < 10.0) "%.2f" else if (kb < 100.0) "%.1f" else "%.0f"
            return f.format(Locale.US, kb) to "KB/s"
        }
        val mb = kb / 1024.0
        return (if (mb < 10.0) "%.2f" else "%.1f").format(Locale.US, mb) to "MB/s"
    }

    private fun readSpeed() {
        if (!data.showSpeed) return
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx < 0 || tx < 0) return
        val now = SystemClock.elapsedRealtime()
        if (lastT != 0L && now > lastT) {
            val secs = (now - lastT) / 1000.0
            val dr = (rx - lastRx).coerceAtLeast(0L) / secs
            val dt = (tx - lastTx).coerceAtLeast(0L) / secs
            val (num, unit) = formatSpeed(dr + dt)
            data.speed = num
            data.speedUnit = unit
            data.down = dr > 512.0
            data.up = dt > 512.0
        }
        lastRx = rx
        lastTx = tx
        lastT = now
    }

    /** Lifecycle / saved state / view model owner that a ComposeView needs outside an Activity. */
    private class BarOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = store

        init {
            controller.performAttach()
            controller.performRestore(null)
            registry.currentState = Lifecycle.State.CREATED
        }

        fun resume() {
            registry.currentState = Lifecycle.State.RESUMED
        }

        fun destroy() {
            registry.currentState = Lifecycle.State.DESTROYED
            store.clear()
        }
    }

    companion object {
        private const val INK_INTERVAL_MS = 200L
        /** Median background brightness (0..255): above this the ink turns dark, below the lower one it turns white. */
        private const val DARK_ON = 138
        private const val DARK_OFF = 118
        private const val REVEAL_MS = 2000L
        private const val ACTION_AP_STATE = "android.net.wifi.WIFI_AP_STATE_CHANGED"
        private const val ACTION_TETHER_STATE = "android.net.conn.TETHER_STATE_CHANGED"
        private const val ACTION_LOC_MODE = "android.location.MODE_CHANGED"
        private const val ACTION_LOC_PROVIDERS = "android.location.PROVIDERS_CHANGED"

        @Volatile
        var running = false
            private set

        @Volatile
        var instance: StatusBarService? = null
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, StatusBarService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, StatusBarService::class.java))
        }

        /** The pull-down panel opened / closed (called by OverlayService, main thread). */
        fun panelOpen(open: Boolean) {
            val s = instance ?: return
            s.data.panel = open
            if (open) {
                // The panel is a later overlay window, so it would cover the bar: put the bar on top of it once.
                // The panel window is already added when this runs (show() calls dialog.show() right after
                // panelOpen), so ONE re-add is enough. Re-adding several times while the panel animates was what
                // made the status bar jump / shake.
                s.main.post {
                    if (instance === s && s.data.panel && s.data.active) s.addBar(seamless = true)
                }
            }
        }

        /** A status bar setting changed: read the settings again and redraw. */
        fun reload() {
            val s = instance ?: return
            s.main.post {
                s.loadPrefs(); s.syncStock(); s.tick()
                // the size changed: the bar window needs its new height
                if (s.data.active && s.bar != null && s.builtScale != s.data.scale) s.addBar(seamless = true)
            }
        }

        /** Shizuku (re)connected: hide the phone's own bar again. */
        fun onShizukuReady() {
            val s = instance ?: return
            s.main.post { s.syncStock() }
        }
    }
}
